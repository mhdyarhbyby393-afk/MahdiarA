(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const STORE_CUSTOM = 'mahdiar-connectivity-custom-sites-v1';
  const STORE_HIDDEN = 'mahdiar-connectivity-hidden-sites-v1';
  const STORE_COUNTRY = 'mahdiar-connectivity-country-v1';
  const CHECK_INTERVAL_MS = 10 * 60 * 1000;
  const results = new Map();
  let countries = [];
  let running = false;
  let currentSites = [];
  let currentLanguage = () => ($('#languageSelect')?.value || document.documentElement.lang || 'fa') === 'en' ? 'en' : 'fa';

  const GLOBAL_SITES = [
    { id: 'google', name: 'Google', url: 'https://www.google.com/generate_204', icon: 'G' },
    { id: 'youtube', name: 'YouTube', url: 'https://www.youtube.com/generate_204', icon: '▶' },
    { id: 'github', name: 'GitHub', url: 'https://github.com/robots.txt', icon: '⌘' },
    // This is a normal website-connectivity target, not the removed Cloudflare/CDN diagnostic tool.
    { id: 'cloudflare-site', name: 'Cloudflare', url: 'https://www.cloudflare.com/', icon: '☁' },
    { id: 'claude', name: 'Claude', url: 'https://claude.ai/', icon: '✷' },
    { id: 'chatgpt', name: 'ChatGPT', url: 'https://chatgpt.com/', icon: '✳' },
    { id: 'wechat', name: 'WeChat', url: 'https://web.wechat.com/', icon: '●' }
  ];

  // A maintained starter catalog of common local services. Users can add their own services with + Add Test.
  const COUNTRY_SITES = {
    IR: [
      { id: 'local-aparat', name: 'Aparat', url: 'https://www.aparat.com/', icon: '▶' },
      { id: 'local-digikala', name: 'Digikala', url: 'https://www.digikala.com/', icon: 'دی' },
      { id: 'local-eitaa', name: 'Eitaa', url: 'https://eitaa.com/', icon: 'ا' }
    ],
    NL: [
      { id: 'local-nos', name: 'NOS', url: 'https://nos.nl/', icon: 'N' },
      { id: 'local-digid', name: 'DigiD', url: 'https://www.digid.nl/', icon: 'D' }
    ],
    TR: [
      { id: 'local-trt', name: 'TRT', url: 'https://www.trt.net.tr/', icon: 'T' },
      { id: 'local-turkiye-gov', name: 'Türkiye.gov.tr', url: 'https://www.turkiye.gov.tr/', icon: '🇹🇷' }
    ],
    US: [
      { id: 'local-usa-gov', name: 'USA.gov', url: 'https://www.usa.gov/', icon: '🇺🇸' },
      { id: 'local-cnn', name: 'CNN', url: 'https://www.cnn.com/', icon: 'C' }
    ],
    DE: [
      { id: 'local-tagesschau', name: 'Tagesschau', url: 'https://www.tagesschau.de/', icon: 'T' },
      { id: 'local-bahn', name: 'Deutsche Bahn', url: 'https://www.bahn.de/', icon: '🚆' }
    ],
    FR: [
      { id: 'local-france24', name: 'France 24', url: 'https://www.france24.com/', icon: 'F' },
      { id: 'local-service-public', name: 'Service-Public', url: 'https://www.service-public.fr/', icon: '🇫🇷' }
    ],
    GB: [
      { id: 'local-bbc', name: 'BBC', url: 'https://www.bbc.co.uk/', icon: 'B' },
      { id: 'local-govuk', name: 'GOV.UK', url: 'https://www.gov.uk/', icon: '🇬🇧' }
    ],
    CH: [
      { id: 'local-srf', name: 'SRF', url: 'https://www.srf.ch/', icon: 'S' },
      { id: 'local-admin-ch', name: 'admin.ch', url: 'https://www.admin.ch/', icon: '🇨🇭' }
    ],
    CA: [
      { id: 'local-canada', name: 'Canada.ca', url: 'https://www.canada.ca/', icon: '🇨🇦' },
      { id: 'local-cbc', name: 'CBC', url: 'https://www.cbc.ca/', icon: 'C' }
    ],
    JP: [
      { id: 'local-nhk', name: 'NHK', url: 'https://www.nhk.or.jp/', icon: 'N' },
      { id: 'local-japan-gov', name: 'JapanGov', url: 'https://www.japan.go.jp/', icon: '🇯🇵' }
    ],
    SG: [
      { id: 'local-gov-sg', name: 'gov.sg', url: 'https://www.gov.sg/', icon: '🇸🇬' },
      { id: 'local-cna', name: 'CNA', url: 'https://www.channelnewsasia.com/', icon: 'C' }
    ],
    AU: [
      { id: 'local-abc-au', name: 'ABC Australia', url: 'https://www.abc.net.au/', icon: 'A' },
      { id: 'local-australia-gov', name: 'Australia.gov.au', url: 'https://www.australia.gov.au/', icon: '🇦🇺' }
    ],
    IN: [
      { id: 'local-india-gov', name: 'India.gov.in', url: 'https://www.india.gov.in/', icon: '🇮🇳' },
      { id: 'local-ndtv', name: 'NDTV', url: 'https://www.ndtv.com/', icon: 'N' }
    ],
    PL: [
      { id: 'local-gov-pl', name: 'Gov.pl', url: 'https://www.gov.pl/', icon: '🇵🇱' },
      { id: 'local-onet', name: 'Onet', url: 'https://www.onet.pl/', icon: 'O' }
    ],
    ES: [
      { id: 'local-rtve', name: 'RTVE', url: 'https://www.rtve.es/', icon: 'R' },
      { id: 'local-gob-es', name: 'Administración', url: 'https://administracion.gob.es/', icon: '🇪🇸' }
    ],
    IT: [
      { id: 'local-rai', name: 'Rai', url: 'https://www.rai.it/', icon: 'R' },
      { id: 'local-italia-gov', name: 'Italia.gov.it', url: 'https://www.italia.it/', icon: '🇮🇹' }
    ],
    SE: [
      { id: 'local-svt', name: 'SVT', url: 'https://www.svt.se/', icon: 'S' },
      { id: 'local-sverige', name: 'Sverige.se', url: 'https://www.sverige.se/', icon: '🇸🇪' }
    ],
    NO: [
      { id: 'local-nrk', name: 'NRK', url: 'https://www.nrk.no/', icon: 'N' },
      { id: 'local-norge', name: 'Norge.no', url: 'https://www.norge.no/', icon: '🇳🇴' }
    ],
    FI: [
      { id: 'local-yle', name: 'Yle', url: 'https://yle.fi/', icon: 'Y' },
      { id: 'local-suomi', name: 'Suomi.fi', url: 'https://www.suomi.fi/', icon: '🇫🇮' }
    ],
    AT: [
      { id: 'local-orf', name: 'ORF', url: 'https://orf.at/', icon: 'O' },
      { id: 'local-oesterreich', name: 'oesterreich.gv.at', url: 'https://www.oesterreich.gv.at/', icon: '🇦🇹' }
    ],
    BE: [
      { id: 'local-vrt', name: 'VRT', url: 'https://www.vrt.be/', icon: 'V' },
      { id: 'local-belgium', name: 'Belgium.be', url: 'https://www.belgium.be/', icon: '🇧🇪' }
    ],
    RU: [
      { id: 'local-yandex', name: 'Yandex', url: 'https://yandex.ru/', icon: 'Я' },
      { id: 'local-gosuslugi', name: 'Gosuslugi', url: 'https://www.gosuslugi.ru/', icon: '🇷🇺' }
    ],
    BR: [
      { id: 'local-gov-br', name: 'Gov.br', url: 'https://www.gov.br/', icon: '🇧🇷' },
      { id: 'local-globo', name: 'Globo', url: 'https://www.globo.com/', icon: 'G' }
    ],
    MX: [
      { id: 'local-gob-mx', name: 'Gob.mx', url: 'https://www.gob.mx/', icon: '🇲🇽' },
      { id: 'local-el-universal', name: 'El Universal', url: 'https://www.eluniversal.com.mx/', icon: 'E' }
    ],
    HK: [
      { id: 'local-gov-hk', name: 'GovHK', url: 'https://www.gov.hk/', icon: '🇭🇰' },
      { id: 'local-rthk', name: 'RTHK', url: 'https://news.rthk.hk/', icon: 'R' }
    ],
    KR: [
      { id: 'local-naver', name: 'Naver', url: 'https://www.naver.com/', icon: 'N' },
      { id: 'local-korea-gov', name: 'Korea.kr', url: 'https://www.korea.kr/', icon: '🇰🇷' }
    ],
    IL: [
      { id: 'local-gov-il', name: 'Gov.il', url: 'https://www.gov.il/', icon: '🇮🇱' },
      { id: 'local-kan', name: 'KAN', url: 'https://www.kan.org.il/', icon: 'K' }
    ],
    SA: [
      { id: 'local-spa', name: 'SPA', url: 'https://www.spa.gov.sa/', icon: '🇸🇦' },
      { id: 'local-absher', name: 'Absher', url: 'https://www.absher.sa/', icon: 'A' }
    ],
    ZA: [
      { id: 'local-gov-za', name: 'Gov.za', url: 'https://www.gov.za/', icon: '🇿🇦' },
      { id: 'local-news24', name: 'News24', url: 'https://www.news24.com/', icon: 'N' }
    ],
    EG: [
      { id: 'local-egypt-gov', name: 'Egypt.gov.eg', url: 'https://www.egypt.gov.eg/', icon: '🇪🇬' },
      { id: 'local-youm7', name: 'Youm7', url: 'https://www.youm7.com/', icon: 'Y' }
    ],
    PT: [
      { id: 'local-portugal-gov', name: 'Portugal.gov.pt', url: 'https://www.portugal.gov.pt/', icon: '🇵🇹' },
      { id: 'local-rtp', name: 'RTP', url: 'https://www.rtp.pt/', icon: 'R' }
    ],
    CZ: [
      { id: 'local-gov-cz', name: 'Gov.cz', url: 'https://www.gov.cz/', icon: '🇨🇿' },
      { id: 'local-seznam', name: 'Seznam', url: 'https://www.seznam.cz/', icon: 'S' }
    ],
    RO: [
      { id: 'local-gov-ro', name: 'Gov.ro', url: 'https://www.gov.ro/', icon: '🇷🇴' },
      { id: 'local-digi24', name: 'Digi24', url: 'https://www.digi24.ro/', icon: 'D' }
    ],
    AE: [
      { id: 'local-u-ae', name: 'U.ae', url: 'https://u.ae/', icon: '🇦🇪' },
      { id: 'local-khaleej', name: 'Khaleej Times', url: 'https://www.khaleejtimes.com/', icon: 'K' }
    ]
  };

  const messages = {
    fa: { waiting: 'در انتظار تست', checking: 'در حال بررسی از Globalping…', online: 'OK', degraded: 'پاسخ با خطای سرور', unknown: 'نتیجه نامشخص', http: 'کد HTTP', probe: 'پروب', refresh: 'تست دوباره', remove: 'حذف از فهرست', removeConfirm: 'این سایت از فهرست شما مخفی شود؟', noSites: 'سایتی برای نمایش باقی نمانده؛ از + افزودن تست استفاده کن.', allChecking: 'در حال اجرای بررسی‌های Globalping…', addRequired: 'نام و آدرس سایت را وارد کن.', invalidUrl: 'آدرس معتبر HTTP یا HTTPS وارد کن.', added: 'سایت اضافه شد؛ بررسی زنده شروع می‌شود.', removed: 'سایت از فهرست مخفی شد.', cache: 'نتیجه ذخیره موقت', live: 'تست تازه', errors: 'برخی بررسی‌ها نتیجه ندادند؛ ممکن است پروب در آن کشور موجود نباشد.', finish: 'بررسی‌ها تمام شد', country: 'کشور پروب', last: 'آخرین بررسی', custom: 'سایت دلخواه' },
    en: { waiting: 'Waiting for test', checking: 'Testing via Globalping…', online: 'OK', degraded: 'Server error response', unknown: 'Unknown result', http: 'HTTP status', probe: 'Probe', refresh: 'Test again', remove: 'Remove from list', removeConfirm: 'Hide this site from your list?', noSites: 'No sites are visible. Use + Add Test to add one.', allChecking: 'Running Globalping checks…', addRequired: 'Enter a site name and URL.', invalidUrl: 'Enter a valid HTTP or HTTPS URL.', added: 'Site added; live check will start.', removed: 'Site hidden from the list.', cache: 'Cached result', live: 'Fresh test', errors: 'Some checks returned no result; a probe may not be available in that country.', finish: 'Checks finished', country: 'Probe country', last: 'Last check', custom: 'Custom site' }
  };

  function t(key) { return (messages[currentLanguage()] || messages.fa)[key] || key; }
  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  }
  function readJson(key, fallback) {
    try { const value = JSON.parse(localStorage.getItem(key) || 'null'); return value == null ? fallback : value; } catch (_) { return fallback; }
  }
  function writeJson(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {} }
  function getCustomSites() { const list = readJson(STORE_CUSTOM, []); return Array.isArray(list) ? list.filter(x => x && typeof x.id === 'string' && typeof x.url === 'string') : []; }
  function getHiddenIds() { const list = readJson(STORE_HIDDEN, []); return new Set(Array.isArray(list) ? list.map(String) : []); }
  function selectedCountry() { return ($('#connectivityCountry')?.value || localStorage.getItem(STORE_COUNTRY) || 'DE').toUpperCase(); }
  function resultKey(site) { return `${selectedCountry()}|${site.id}`; }
  function uniqueSites(list) {
    const urls = new Set(); const ids = new Set();
    return list.filter(site => {
      if (!site || !site.id || !site.url || getHiddenIds().has(site.id) || ids.has(site.id)) return false;
      let normal;
      try { normal = new URL(site.url).href.toLowerCase(); } catch (_) { return false; }
      if (urls.has(normal)) return false;
      ids.add(site.id); urls.add(normal); return true;
    });
  }
  function getSites() {
    const cc = selectedCountry();
    return uniqueSites([...GLOBAL_SITES, ...(COUNTRY_SITES[cc] || []), ...getCustomSites()]);
  }
  function stateLabel(result) {
    if (!result || result.state === 'pending') return t('waiting');
    if (result.state === 'online') return t('online');
    if (result.state === 'degraded') return t('degraded');
    return t('unknown');
  }
  function classFor(result) {
    if (!result || result.state === 'pending') return 'pending';
    if (result.state === 'online') return 'is-online';
    if (result.state === 'degraded') return 'is-degraded';
    return 'is-unknown';
  }
  function latencyText(result) {
    return Number.isFinite(Number(result?.latencyMs)) ? `${Math.round(Number(result.latencyMs))} ms` : '—';
  }
  function miniBars(result) {
    const heights = [25, 42, 30, 58, 38, 70, 46, 60, 34, 52];
    const state = result?.state === 'online' ? 'good' : result?.state === 'degraded' ? 'warn' : result?.state === 'unknown' ? 'bad' : 'waiting';
    return `<div class="connectivity-mini-bars ${state}" aria-hidden="true">${heights.map(h => `<i style="height:${h}%"></i>`).join('')}</div>`;
  }
  function cardHtml(site) {
    const result = results.get(resultKey(site)) || { state: 'pending' };
    let domain = site.url;
    try { domain = new URL(site.url).hostname; } catch (_) {}
    const code = result.statusCode ? `HTTP ${escapeHtml(result.statusCode)}` : '';
    const probe = result.probe ? [result.probe.city, result.probe.country].filter(Boolean).join(', ') : '';
    const freshness = result.cached ? t('cache') : result.checkedAt ? t('live') : '';
    const issue = result.state === 'unknown' && result.error ? String(result.error).slice(0, 180) : '';
    const metaBits = [issue, code, probe, freshness].filter(Boolean);
    return `<article class="connectivity-card ${classFor(result)}" data-site-id="${escapeHtml(site.id)}">
      <div class="connectivity-card-head">
        <div class="connectivity-brand"><span class="connectivity-icon" aria-hidden="true">${escapeHtml(site.icon || '↗')}</span><div class="connectivity-brand-copy"><b>${escapeHtml(site.name || domain)}</b><small>${escapeHtml(domain)}</small></div></div>
        <div class="connectivity-actions"><button class="connectivity-action" type="button" data-connectivity-refresh="${escapeHtml(site.id)}" aria-label="${escapeHtml(t('refresh'))}" title="${escapeHtml(t('refresh'))}">⟳</button><button class="connectivity-action remove" type="button" data-connectivity-remove="${escapeHtml(site.id)}" aria-label="${escapeHtml(t('remove'))}" title="${escapeHtml(t('remove'))}">×</button></div>
      </div>
      <div class="connectivity-card-result"><span class="connectivity-state"><i></i>${escapeHtml(stateLabel(result))}</span><code>${latencyText(result)}</code></div>
      ${miniBars(result)}
      <div class="connectivity-card-meta">${metaBits.length ? metaBits.map(escapeHtml).join(' · ') : escapeHtml(result.error || (result.state === 'pending' ? t('checking') : '—'))}</div>
    </article>`;
  }
  function addTileHtml() {
    return `<button type="button" class="connectivity-add-card" data-connectivity-add><span class="connectivity-add-plus">+</span><b>${currentLanguage() === 'en' ? '+ Add Test' : '+ افزودن تست'}</b><small>${currentLanguage() === 'en' ? 'Add a website' : 'افزودن سایت دلخواه'}</small></button>`;
  }
  function render() {
    const grid = $('#connectivityGrid'); if (!grid) return;
    currentSites = getSites();
    const html = currentSites.map(cardHtml).join('') + addTileHtml();
    grid.innerHTML = currentSites.length ? html : `<div class="connectivity-empty">${escapeHtml(t('noSites'))}</div>${addTileHtml()}`;
  }
  function updateCard(site, result) {
    results.set(resultKey(site), result);
    const grid = $('#connectivityGrid'); const old = grid?.querySelector(`[data-site-id="${CSS.escape(site.id)}"]`);
    if (!old) { render(); return; }
    old.outerHTML = cardHtml(site);
  }
  async function doCheck(site) {
    const key = resultKey(site);
    results.set(key, { state: 'pending' });
    const old = $('#connectivityGrid')?.querySelector(`[data-site-id="${CSS.escape(site.id)}"]`);
    if (old) old.outerHTML = cardHtml(site);
    try {
      const response = await fetch('/api/connectivity/check', {
        method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json' },
        body: JSON.stringify({ url: site.url, country: selectedCountry() }), cache: 'no-store'
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || data.ok === false && data.state == null) throw new Error(data.error || `HTTP ${response.status}`);
      updateCard(site, data);
      return data;
    } catch (error) {
      const data = { state: 'unknown', error: String(error?.message || error).slice(0, 300), source: 'Globalping', checkedAt: new Date().toISOString() };
      updateCard(site, data);
      return data;
    }
  }
  async function runAllChecks() {
    if (running) return;
    const grid = $('#connectivityGrid'); const button = $('#connectivityRefreshBtn'); const summary = $('#connectivitySummary');
    if (!grid) return;
    const cc = selectedCountry();
    const sites = getSites();
    if (!sites.length) { render(); return; }
    running = true;
    if (button) button.disabled = true;
    if (summary) summary.textContent = `${t('allChecking')} (${sites.length})`;
    render();
    let cursor = 0, finished = 0, ok = 0, failed = 0, cached = 0;
    const worker = async () => {
      while (cursor < sites.length) {
        const site = sites[cursor++];
        const result = await doCheck(site);
        finished++;
        if (result.state === 'online') ok++;
        else if (result.state === 'unknown') failed++;
        if (result.cached) cached++;
        if (summary) summary.textContent = `${finished}/${sites.length} · ${currentLanguage() === 'en' ? 'Online' : 'قابل دسترس'} ${ok} · ${currentLanguage() === 'en' ? 'Unknown' : 'نامشخص'} ${failed}`;
      }
    };
    try {
      await Promise.all(Array.from({ length: Math.min(3, sites.length) }, worker));
      const now = new Date();
      const fmt = now.toLocaleTimeString(currentLanguage() === 'en' ? 'en-GB' : 'fa-IR', { hour: '2-digit', minute: '2-digit' });
      const label = `${t('last')}: ${fmt} · ${t('country')}: ${cc}${cached ? ` · ${cached} ${currentLanguage() === 'en' ? 'cached' : 'نتیجه کش‌شده'}` : ''}`;
      const last = $('#connectivityLastUpdated'); if (last) last.textContent = label;
      if (summary) summary.textContent = `${t('finish')} · ${ok} / ${sites.length} ${currentLanguage() === 'en' ? 'responded' : 'پاسخ‌گو'}${failed ? ` · ${failed} ${currentLanguage() === 'en' ? 'unknown' : 'نامشخص'}` : ''}`;
    } finally {
      running = false;
      if (button) button.disabled = false;
    }
  }
  async function runOne(siteId) {
    if (running) return;
    const site = getSites().find(item => item.id === siteId);
    if (!site) return;
    const button = $('#connectivityGrid')?.querySelector(`[data-connectivity-refresh="${CSS.escape(siteId)}"]`);
    if (button) button.disabled = true;
    const summary = $('#connectivitySummary'); if (summary) summary.textContent = `${site.name}: ${t('checking')}`;
    await doCheck(site);
    const last = $('#connectivityLastUpdated'); if (last) last.textContent = `${t('last')}: ${new Date().toLocaleTimeString(currentLanguage() === 'en' ? 'en-GB' : 'fa-IR')} · ${t('country')}: ${selectedCountry()}`;
    if (summary) summary.textContent = t('finish');
    if (button) button.disabled = false;
  }
  function normalizeUrl(raw) {
    let value = String(raw || '').trim();
    if (!value) throw new Error(t('invalidUrl'));
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(value)) value = `https://${value}`;
    const parsed = new URL(value);
    if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.href.length > 500) throw new Error(t('invalidUrl'));
    if (parsed.hostname === 'localhost' || parsed.hostname.endsWith('.localhost') || parsed.hostname.endsWith('.local')) throw new Error(t('invalidUrl'));
    return parsed.href;
  }
  function showAddForm() {
    const form = $('#connectivityAddForm'); if (!form) return;
    form.classList.remove('hidden');
    $('#connectivitySiteName')?.focus();
  }
  function hideAddForm() {
    const form = $('#connectivityAddForm'); if (form) form.classList.add('hidden');
    if ($('#connectivitySiteName')) $('#connectivitySiteName').value = '';
    if ($('#connectivitySiteUrl')) $('#connectivitySiteUrl').value = '';
  }
  function removeSite(id) {
    if (String(id).startsWith('custom-')) {
      writeJson(STORE_CUSTOM, getCustomSites().filter(site => site.id !== id));
    } else {
      const hidden = getHiddenIds(); hidden.add(id); writeJson(STORE_HIDDEN, [...hidden]);
    }
    render();
    if (!currentSites.length) $('#connectivitySummary').textContent = t('noSites');
  }
  function populateCountries() {
    const select = $('#connectivityCountry'); if (!select) return;
    const current = localStorage.getItem(STORE_COUNTRY) || 'DE';
    const names = countries.length ? countries : [
      { code: 'TR', name: 'Turkey', fa: 'ترکیه' }, { code: 'FR', name: 'France', fa: 'فرانسه' }, { code: 'DE', name: 'Germany', fa: 'آلمان' }, { code: 'US', name: 'United States', fa: 'آمریکا' },
      { code: 'NL', name: 'Netherlands', fa: 'هلند' }, { code: 'GB', name: 'United Kingdom', fa: 'انگلستان' }, { code: 'AE', name: 'United Arab Emirates', fa: 'امارات' }, { code: 'CH', name: 'Switzerland', fa: 'سوئیس' },
      { code: 'CA', name: 'Canada', fa: 'کانادا' }, { code: 'IR', name: 'Iran', fa: 'ایران' }, { code: 'JP', name: 'Japan', fa: 'ژاپن' }, { code: 'SG', name: 'Singapore', fa: 'سنگاپور' },
      { code: 'AU', name: 'Australia', fa: 'استرالیا' }, { code: 'IN', name: 'India', fa: 'هند' }, { code: 'PL', name: 'Poland', fa: 'لهستان' }, { code: 'ES', name: 'Spain', fa: 'اسپانیا' },
      { code: 'IT', name: 'Italy', fa: 'ایتالیا' }, { code: 'SE', name: 'Sweden', fa: 'سوئد' }, { code: 'NO', name: 'Norway', fa: 'نروژ' }, { code: 'FI', name: 'Finland', fa: 'فنلاند' },
      { code: 'AT', name: 'Austria', fa: 'اتریش' }, { code: 'BE', name: 'Belgium', fa: 'بلژیک' }, { code: 'RU', name: 'Russia', fa: 'روسیه' }, { code: 'BR', name: 'Brazil', fa: 'برزیل' },
      { code: 'MX', name: 'Mexico', fa: 'مکزیک' }, { code: 'HK', name: 'Hong Kong', fa: 'هنگ‌کنگ' }, { code: 'KR', name: 'South Korea', fa: 'کره جنوبی' }, { code: 'IL', name: 'Israel', fa: 'اسرائیل' },
      { code: 'SA', name: 'Saudi Arabia', fa: 'عربستان سعودی' }, { code: 'ZA', name: 'South Africa', fa: 'آفریقای جنوبی' }, { code: 'EG', name: 'Egypt', fa: 'مصر' }, { code: 'PT', name: 'Portugal', fa: 'پرتغال' },
      { code: 'CZ', name: 'Czechia', fa: 'جمهوری چک' }, { code: 'RO', name: 'Romania', fa: 'رومانی' }
    ];
    select.innerHTML = names.map(item => `<option value="${escapeHtml(item.code)}">${escapeHtml(currentLanguage() === 'en' ? item.name : item.fa)} (${escapeHtml(item.code)})</option>`).join('');
    select.value = names.some(item => item.code === current) ? current : 'DE';
    localStorage.setItem(STORE_COUNTRY, select.value);
  }
  async function init() {
    const grid = $('#connectivityGrid'); if (!grid) return;
    try {
      const response = await fetch('/api/world/countries', { cache: 'no-store' });
      const data = await response.json();
      if (response.ok && Array.isArray(data.countries)) countries = data.countries;
    } catch (_) {}
    populateCountries();
    render();
    $('#connectivityRefreshBtn')?.addEventListener('click', runAllChecks);
    $('#connectivityCountry')?.addEventListener('change', () => {
      localStorage.setItem(STORE_COUNTRY, selectedCountry());
      render(); runAllChecks();
    });
    grid.addEventListener('click', event => {
      const add = event.target.closest('[data-connectivity-add]');
      if (add) { showAddForm(); return; }
      const refresh = event.target.closest('[data-connectivity-refresh]');
      if (refresh) { runOne(refresh.dataset.connectivityRefresh); return; }
      const remove = event.target.closest('[data-connectivity-remove]');
      if (remove) { removeSite(remove.dataset.connectivityRemove); return; }
    });
    $('#connectivityCancelAdd')?.addEventListener('click', hideAddForm);
    $('#connectivityAddForm')?.addEventListener('submit', event => {
      event.preventDefault();
      const nameInput = $('#connectivitySiteName'), urlInput = $('#connectivitySiteUrl');
      const name = String(nameInput?.value || '').trim();
      let url;
      try { url = normalizeUrl(urlInput?.value); } catch (_) { if (typeof window.toast === 'function') window.toast(t('invalidUrl')); else alert(t('invalidUrl')); return; }
      if (!name) { if (typeof window.toast === 'function') window.toast(t('addRequired')); return; }
      const existing = [...GLOBAL_SITES, ...(COUNTRY_SITES[selectedCountry()] || []), ...getCustomSites()].some(site => {
        try { return new URL(site.url).href.toLowerCase() === url.toLowerCase(); } catch (_) { return false; }
      });
      if (existing) { if (typeof window.toast === 'function') window.toast(currentLanguage() === 'en' ? 'This URL is already in the list.' : 'این آدرس از قبل در فهرست وجود دارد.'); return; }
      const custom = getCustomSites();
      const id = `custom-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
      custom.push({ id, name: name.slice(0, 50), url, icon: '↗' });
      writeJson(STORE_CUSTOM, custom);
      hideAddForm(); render();
      if (typeof window.toast === 'function') window.toast(t('added'));
      runOne(id);
    });
    const lang = $('#languageSelect'); lang?.addEventListener('change', () => { populateCountries(); render(); });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && !running) runAllChecks();
    });
    await runAllChecks();
    setInterval(() => { if (document.visibilityState === 'visible' && !running) runAllChecks(); }, CHECK_INTERVAL_MS);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
