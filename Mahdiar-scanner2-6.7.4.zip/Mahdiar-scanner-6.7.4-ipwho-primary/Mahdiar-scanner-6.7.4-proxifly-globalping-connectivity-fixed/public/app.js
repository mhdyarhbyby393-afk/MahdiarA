const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

let currentScan = null;
let scanTimer = null;
let currentRows = [];
let currentCountryRows = [];
let worldRows = [];
let worldData = null;
const WORLD_SELECTION_KEY='mahdiar-world-countries.v9';
const DEFAULT_WORLD_SELECTED_CODES=[];
let currentProxiflyOffset = 0;
let lastProxiflyPagination = null;
function storageGet(key,fallback=''){try{return localStorage.getItem(key) ?? fallback}catch(_){return fallback}}
function storageSet(key,value){try{localStorage.setItem(key,value);return true}catch(_){return false}}
function storageJsonGet(key,fallback){try{const raw=storageGet(key,'');if(!raw)return fallback;const v=JSON.parse(raw);return v??fallback}catch(_){return fallback}}
let selectedWorldCountries = new Set(Array.isArray(storageJsonGet(WORLD_SELECTION_KEY,[])) ? storageJsonGet(WORLD_SELECTION_KEY,[]).filter(Boolean) : []);
let worldMap = null;
let worldMapLayer = null;
let worldCountryConfig = [];
let currentLanguage = storageGet('mahdiar-language','fa') || 'fa';
let selectedPorts = new Set();
let scanConfig = null;
const SAVED_KEY = 'mahdiar-network-tools.savedTargets.v5';
const RECIPE_KEY = 'mahdiar-network-tools.recipes.v5';

const PORT_NAMES = {
  21:'FTP',22:'SSH',23:'Telnet',25:'SMTP',53:'DNS',80:'HTTP',110:'POP3',111:'RPCbind',135:'MSRPC',139:'NetBIOS',143:'IMAP',443:'HTTPS',445:'SMB',465:'SMTPS',587:'SMTP Submission',853:'DNS-over-TLS',993:'IMAPS',995:'POP3S',1433:'MSSQL',1521:'Oracle',2049:'NFS',2375:'Docker',3000:'HTTP-alt',3306:'MySQL',3389:'RDP',5000:'HTTP-alt',5432:'PostgreSQL',5900:'VNC',6379:'Redis',8000:'HTTP-alt',8080:'HTTP-proxy',8081:'HTTP-alt',8443:'HTTPS-alt',8888:'HTTP-alt',9200:'Elasticsearch',9300:'Elasticsearch transport',11211:'Memcached',27017:'MongoDB'
};

const tools = [
  {id:'ip',icon:'⌁',name:'جستجوی IP',desc:'نمایش IP عمومی خودت و جزئیات شبکه',open:ipTool},
  {id:'geoip',icon:'◉',name:'بررسی IP',desc:'RDAP، شبکه، کشور و محدوده',open:lookupTool},
  {id:'http',icon:'↗',name:'تست اتصال',desc:'HTTP status، latency و headers',open:httpTool},
  {id:'webrtc',icon:'◌',name:'تست WebRTC',desc:'ICE candidates مرورگر',open:webrtcTool},
  {id:'dns',icon:'◇',name:'تست DNS',desc:'رکوردهای DNS با Node resolver',open:dnsTool},
  {id:'speed',icon:'⚡',name:'تست سرعت',desc:'تست سرعت واقعی اینترنت',open:speedTool},
  {id:'global',icon:'◈',name:'پینگ چندنقطه‌ای',desc:'Latency چند endpoint عمومی',open:globalTool},
  {id:'mtr',icon:'〽',name:'MTR / Route',desc:'مسیر شبکه از خود سرور',open:mtrTool},
  {id:'dns-compare',icon:'≋',name:'مقایسه DNS',desc:'مقایسه resolverهای عمومی',open:dnsCompareTool},
  {id:'rules',icon:'▣',name:'تست قوانین',desc:'HTTPS و security headers',open:rulesTool},
  {id:'resolver',icon:'⌂',name:'حل‌کننده DNS',desc:'A/AAAA/MX/NS/TXT و بیشتر',open:resolverTool},
  {id:'blacklist',icon:'⊘',name:'Blacklist',desc:'بررسی DNSBL برای IPv4',open:blacklistTool},
  {id:'whois',icon:'◫',name:'Whois / RDAP',desc:'اطلاعات رجیستری IP',open:lookupTool},
  {id:'mac',icon:'⌬',name:'سازنده MAC',desc:'Vendor برای یک MAC',open:macTool},
  {id:'browser',icon:'▤',name:'اطلاعات مرورگر',desc:'Browser، صفحه و WebGL',open:browserTool},
  {id:'security',icon:'▰',name:'چک‌لیست امنیت',desc:'TLS، HSTS، CSP و headers',open:securityTool},
  {id:'invisible',icon:'◍',name:'تست نامرئی بودن',desc:'چند privacy/fingerprint hint',open:invisibleTool},
  {id:'status',icon:'▥',name:'وضعیت سرور',desc:'CPU، RAM، uptime و interface',open:serverTool},
  {id:'advanced-dns',icon:'◎',name:'DNS پیشرفته',desc:'چند نوع record در یک گزارش',open:advancedDnsTool},
  {id:'port',icon:'⟂',name:'Port Check',desc:'بررسی یک پورت روی یک target عمومی',open:portTool},
  {id:'scanner',icon:'⟐',name:'Mahdiar scanner',desc:'Proxifly proxy inventory + Globalping measurements',open:openScannerView},
  {id:'country-ranges',icon:'◈',name:'IP کشورها',desc:'رنج‌های IPv4 کشورها و CIDR',open:countryRangesTool},
  {id:'ssl',icon:'🔒',name:'SSL Checker',desc:'TLS، cipher و certificate',open:sslTool}
];

function esc(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.remove('hidden');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.add('hidden'),3000)}
function openModal(title,html){$('#modalContent').innerHTML=`<span class="eyebrow">MAHDIAR_SCANNER / TOOL</span><h2>${esc(title)}</h2>${html}`;$('#modal').classList.remove('hidden')}
function closeModal(){ $('#modal').classList.add('hidden') }
function setLoading(el){el.innerHTML='<div class="loading-line"><span></span><span></span><span></span> در حال بررسی…</div>'}
function flag(code){return String(code||'').toUpperCase().replace(/./g,c=>String.fromCodePoint(127397+c.charCodeAt(0)))}
function fmtMs(v){if(v===null||v===undefined||v==='')return '—';const n=Number(v);return Number.isFinite(n)&&n>=0?`${Math.round(n)} ms`:'—'}
function portName(p){return PORT_NAMES[p]||`Port ${p}`}
function k(v){return `<div class="kv"><span>${esc(v[0])}</span><span>${esc(v[1])}</span></div>`}
async function j(url,opts={}){const r=await fetch(url,opts);const d=await r.json().catch(()=>({error:'Invalid server response'}));if(!r.ok)throw new Error(d.error||`HTTP ${r.status}`);return d}

$$('[data-close]').forEach(e=>e.onclick=closeModal);
$('#modal')?.addEventListener('click',e=>{if(e.target.dataset.close!==undefined)closeModal()});
$('#menuBtn')?.addEventListener('click',()=>$('#sidebar')?.classList.add('open'));
$('#closeMenu')?.addEventListener('click',()=>$('#sidebar')?.classList.remove('open'));
$$('.nav').forEach(b=>b.onclick=()=>switchView(b.dataset.view));
function switchView(view){$$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.view===view));$$('.view').forEach(v=>v.classList.remove('active'));$('#'+view).classList.add('active');$('#sidebar').classList.remove('open');if(view==='history')loadHistory();if(view==='server')loadServer();if(view==='scanner'){loadScanConfig();}if(view==='countries')loadCountries()}

function renderToolGrid(id){const box=$(id);if(!box)return;box.innerHTML=tools.map(t=>`<button class="tool-card" data-tool="${t.id}"><div class="tool-icon">${t.icon}</div><b>${esc(t.name)}</b><p>${esc(t.desc)}</p></button>`).join('');box.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>tools.find(t=>t.id===b.dataset.tool)?.open())}
renderToolGrid('#toolGrid');renderToolGrid('#toolGrid2');
$$('[data-open]').forEach(b=>b.onclick=()=>tools.find(t=>t.id===b.dataset.open)?.open());

function inputTool(title,fields,handler){
  openModal(title,`<div class="form-grid">${fields.map(f=>f.type==='select'?`<label class="modal-label">${esc(f.label||f.ph)}<select id="${f.id}" class="field">${(f.options||[]).map(o=>`<option value="${esc(o.value??o)}" ${(o.value??o)===(f.value??'')?'selected':''}>${esc(o.label??o)}</option>`).join('')}</select></label>`:`<label class="modal-label">${esc(f.label||'')}<input id="${f.id}" class="field" placeholder="${esc(f.ph)}" value="${esc(f.value||'')}"></label>`).join('')}<button id="runTool" class="primary">بررسی</button></div><div id="out" class="result">مقدار را وارد کن و بررسی را بزن.</div>`);
  $('#runTool').onclick=async()=>{const out=$('#out');setLoading(out);try{const vals=Object.fromEntries(fields.map(f=>[f.id,$('#'+f.id).value]));out.innerHTML=await handler(vals)}catch(e){out.innerHTML=`<div class="code">${esc(e.message)}</div>`}}
}

function publicIpJsonp(url, timeoutMs=5000){
  return new Promise((resolve, reject)=>{
    const cb='mahdiarIp_'+Date.now()+'_'+Math.random().toString(36).slice(2);
    const script=document.createElement('script'); let timer=null;
    const cleanup=()=>{clearTimeout(timer);try{delete window[cb]}catch(_){};script.remove()};
    window[cb]=(data)=>{cleanup();const ip=String(data?.ip||'').trim();ip&&netLooksPublic(ip)?resolve(ip):reject(new Error('Invalid public IP response.'))};
    script.src=url+(url.includes('?')?'&':'?')+`callback=${encodeURIComponent(cb)}&_=${Date.now()}`;
    script.async=true; script.onerror=()=>{cleanup();reject(new Error('Public IP probe failed.'))};
    timer=setTimeout(()=>{cleanup();reject(new Error('Public IP probe timed out.'))},timeoutMs);
    document.head.appendChild(script);
  });
}
async function directPublicIpJson(url, timeoutMs=4500){
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),timeoutMs);
  try{
    const r=await fetch(url,{cache:'no-store',mode:'cors',headers:{accept:'application/json'},signal:controller.signal});
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const d=await r.json(); const ip=String(d?.ip||d?.query||'').trim();
    if(!netLooksPublic(ip))throw new Error('Invalid public IP response.');
    return ip;
  } finally{clearTimeout(timer)}
}
async function directPublicIpText(url, timeoutMs=4500){
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),timeoutMs);
  try{
    const r=await fetch(url,{cache:'no-store',mode:'cors',signal:controller.signal});
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    const ip=(await r.text()).trim();
    if(!netLooksPublic(ip))throw new Error('Invalid public IP response.');
    return ip;
  } finally{clearTimeout(timer)}
}
let browserPublicIpCache={value:'',at:0,promise:null};
function browserProbeFetch(url, parser, timeoutMs=4500){
  return new Promise((resolve,reject)=>{
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),timeoutMs);
    fetch(url,{cache:'no-store',mode:'cors',headers:{accept:'application/json'},signal:controller.signal})
      .then(async r=>{ if(!r.ok) throw new Error(`HTTP ${r.status}`); const d=await r.json(); const ip=String(parser(d)||'').trim(); if(!netLooksPublic(ip)) throw new Error('Invalid public IP response.'); resolve(ip); })
      .catch(reject)
      .finally(()=>clearTimeout(timer));
  });
}
function browserProbeText(url, timeoutMs=4500){
  return new Promise((resolve,reject)=>{
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),timeoutMs);
    fetch(url,{cache:'no-store',mode:'cors',signal:controller.signal})
      .then(async r=>{ if(!r.ok) throw new Error(`HTTP ${r.status}`); const ip=(await r.text()).trim(); if(!netLooksPublic(ip)) throw new Error('Invalid public IP response.'); resolve(ip); })
      .catch(reject)
      .finally(()=>clearTimeout(timer));
  });
}
async function getBrowserPublicIp(){
  const probes=[
    ()=>directPublicIpJson('https://api64.ipify.org?format=json',4500),
    ()=>directPublicIpJson('https://api.ipify.org?format=json',4500),
    ()=>publicIpJsonp('https://api64.ipify.org',5000),
    ()=>publicIpJsonp('https://api.ipify.org',5000),
    async()=>{const d=await j('/api/ip/me?client=1');const ip=String(d?.clientIp||d?.ip||'').trim();if(!netLooksPublic(ip))throw new Error('Invalid client IP result');return ip;}
  ];
  for(const probe of probes){try{return await Promise.race([probe(),new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')),6500))]);}catch(_){} }
  return '';
}
function ipTool(){
  openModal('جستجوی IP',`<div class="result" id="ipResult">در حال دریافت IPهای قابل مشاهده…</div>`);
  getBrowserPublicIp().then(async browserIp=>{
    let d={};try{d=await j('/api/ip/me')}catch(_){}
    const ips=[browserIp,d.publicIp,d.clientIp,d.detectedByServer].filter(Boolean);
    const unique=[...new Set(ips)];
    const rows=[];
    for(const ip of unique.slice(0,6)){
      try{const x=await j('/api/ip/lookup?ip='+encodeURIComponent(ip));rows.push(`<div class="ip-card"><div class="ip-card-top"><code>${esc(ip)}</code><span class="mini-badge">${esc(x.country||'—')}</span></div>${k(['Network',x.name||'—'])}${k(['Range',`${x.startAddress||'—'} → ${x.endAddress||'—'}`])}</div>`)}catch(_){rows.push(`<div class="ip-card"><code>${esc(ip)}</code>${k(['Lookup','failed'])}</div>`)}}
    const out=$('#ipResult'); if(out)out.innerHTML=rows.join('')||'<div class="notice">IP پیدا نشد.</div>';
  }).catch(e=>{const out=$('#ipResult');if(out)out.innerHTML=`<div class="code">${esc(e.message)}</div>`})
}
function lookupTool(){inputTool('بررسی IP / Whois / RDAP',[{id:'ip',ph:'مثلاً 1.1.1.1'}],async({ip})=>{const d=await j('/api/ip/lookup?ip='+encodeURIComponent(ip));return `${k(['نام شبکه',d.name||'—'])}${k(['کشور',d.country||'—'])}${k(['شروع بازه',d.startAddress||'—'])}${k(['پایان بازه',d.endAddress||'—'])}${k(['نوع',d.type||'—'])}<details><summary>JSON خام</summary><div class="code">${esc(JSON.stringify(d.raw,null,2))}</div></details>`})}
function httpTool(){inputTool('تست اتصال',[{id:'url',ph:'https://example.com'}],async({url})=>{const d=await j('/api/http-check?url='+encodeURIComponent(url));return `${k(['Status',`${d.status} ${d.statusText}`])}${k(['Latency',fmtMs(d.latencyMs)])}${k(['Final URL',d.finalUrl||'—'])}${k(['Server',d.headers?.server||'—'])}<details><summary>Headers</summary><div class="code">${esc(JSON.stringify(d.headers,null,2))}</div></details>`})}
function dnsTool(){inputTool('تست DNS',[{id:'host',ph:'example.com'}],async({host})=>{const d=await j('/api/dns?host='+encodeURIComponent(host)+'&type=A');return `<div class="chip-row">${(d.records||[]).map(x=>`<span class="chip">${esc(x)}</span>`).join('')||'<span class="chip">No A records</span>'}</div>`})}
function resolverTool(){inputTool('حل‌کننده DNS',[{id:'host',ph:'example.com'},{id:'type',label:'Record type',type:'select',value:'A',options:['A','AAAA','MX','NS','TXT','CNAME','SOA','SRV','CAA','PTR']}],async({host,type})=>{const d=await j('/api/dns?host='+encodeURIComponent(host)+'&type='+encodeURIComponent(type));return `<div class="code">${esc(JSON.stringify(d.records,null,2))}</div>`})}
function advancedDnsTool(){inputTool('تست پیشرفته DNS',[{id:'host',ph:'example.com'}],async({host})=>{const types=['A','AAAA','MX','NS','TXT','CNAME','SOA','CAA'];const rows=[];for(const type of types){try{const d=await j('/api/dns?host='+encodeURIComponent(host)+'&type='+type);rows.push(`<div class="result"><b>${type}</b><div class="code">${esc(JSON.stringify(d.records,null,2))}</div></div>`)}catch(e){rows.push(`<div class="result"><b>${type}</b><div class="muted">${esc(e.message)}</div></div>`)}}return rows.join('')})}
function dnsCompareTool(){inputTool('مقایسه DNS',[{id:'host',ph:'example.com'}],async({host})=>{const d=await j('/api/dns-compare?host='+encodeURIComponent(host));return `<div class="code">${esc(JSON.stringify(d.providers,null,2))}</div>`})}
function globalTool(){openModal('پینگ چندنقطه‌ای',`<div class="notice">برای هر کشور چند IP دیتاسنتری/hosting از اطلاعات عمومی انتخاب می‌شود؛ سپس وضعیت پینگ از نودهای ایران، آلمان، فرانسه و آذربایجان و سرویس‌های گزارش‌شده نمایش داده می‌شود.</div><div id="globalOut" class="result">در حال بررسی ایران، آلمان، فرانسه و آذربایجان…</div>`);j('/api/multi-ping?countries=IR,DE,FR,AZ&ports=80,443&limit=3').then(d=>{const groups=d.results||[];$('#globalOut').innerHTML=groups.map(g=>{const rows=(g.candidates||[]).map(r=>{const latency=r.ping?.avgMs!=null?fmtMs(r.ping.avgMs):(r.ping?.ok?'reachable':'—');const services=(r.services||[]).map(s=>{const extra=[s.product,s.version].filter(Boolean).join(' ');return `${s.port} ${s.name||''}${extra?' · '+extra:''}`.trim()}).join(' · ')||'—';const probeRows=(r.ping?.nodes||[]).filter(n=>n.latencyMs!=null).map(n=>`${n.country||''} ${n.city||''}: ${fmtMs(n.latencyMs)}`).join(' · ')||'—';return `<div class="result"><div class="kv"><span>${flag(g.country)} ${esc(g.countryName||g.country)} · <code>${esc(r.ip)}</code></span><span>${r.ping?.ok?`<span class="ok-dot">● ${esc(latency)}</span>`:'<span class="bad-dot">● no ping</span>'}</span></div>${k(['Provider',r.provider||'—'])}${k(['ASN',r.asn?`AS${r.asn}`:'—'])}${k(['Services / ports',services])}${k(['Probe nodes',probeRows])}${r.prefix?k(['Prefix',r.prefix]):''}</div>`}).join('');return rows||`<div class="notice">${esc(g.countryName||g.country)}: مورد دیتاسنتری از منبع عمومی پیدا نشد${g.error?` — ${esc(g.error)}`:''}</div>`}).join('')||'<div class="notice">هیچ نتیجه‌ای از منابع عمومی دریافت نشد.</div>'}).catch(e=>{const out=$('#globalOut');if(out)out.innerHTML=`<div class="code">${esc(e.message)}</div>`})}
function mtrTool(){inputTool('MTR / Route',[{id:'host',ph:'example.com'}],async({host})=>{const d=await j('/api/mtr?host='+encodeURIComponent(host));if(!d.ok)return `<div class="notice">${esc(d.error||'MTR unavailable')}</div>`;return `${k(['Command',d.command])}<div class="table-wrap"><table class="mini-table"><thead><tr><th>Hop</th><th>IP</th><th>Latency</th></tr></thead><tbody>${(d.hops||[]).map(h=>`<tr><td>${h.hop}</td><td><code>${esc(h.ip||'*')}</code></td><td>${fmtMs(h.latencyMs)}</td></tr>`).join('')||'<tr><td colspan="3" class="empty">hop قابل parse پیدا نشد.</td></tr>'}</tbody></table></div><details><summary>Raw</summary><div class="code">${esc(d.raw||'')}</div></details>`})}
function rulesTool(){inputTool('تست قوانین سایت',[{id:'url',ph:'https://example.com'}],async({url})=>{const d=await j('/api/http-check?url='+encodeURIComponent(url));const headers=d.headers||{};return `${k(['HTTPS',/^https:/i.test(d.url||url)?'PASS':'WARN'])}${k(['HSTS',headers['strict-transport-security']?'PASS':'WARN'])}${k(['CSP',headers['content-security-policy']?'PASS':'INFO'])}${k(['X-Content-Type-Options',headers['x-content-type-options']?'PASS':'INFO'])}${k(['X-Frame-Options',headers['x-frame-options']?'PASS':'INFO'])}${k(['Referrer-Policy',headers['referrer-policy']?'PASS':'INFO'])}${k(['Permissions-Policy',headers['permissions-policy']?'PASS':'INFO'])}`})}
function portTool(){inputTool('Port Check',[{id:'host',ph:'example.com'},{id:'port',ph:'443',value:'443'}],async({host,port})=>{const d=await j('/api/port-check?host='+encodeURIComponent(host)+'&port='+encodeURIComponent(port));return `${k(['Host',d.host])}${k(['Resolved',d.resolvedAddress||'—'])}${k(['Port',d.port])}${k(['Service',d.service])}${k(['State',d.open?'OPEN':String(d.state||'CLOSED').toUpperCase()])}${k(['Latency',fmtMs(d.latencyMs)])}`})}
function sslTool(){inputTool('SSL Checker',[{id:'host',ph:'example.com'},{id:'port',ph:'443',value:'443'}],async({host,port})=>{const d=await j('/api/tls?host='+encodeURIComponent(host)+'&port='+encodeURIComponent(port));return `${k(['Connected',d.ok?'Yes':'No'])}${k(['TLS',d.tlsVersion||'—'])}${k(['Cipher',d.cipher||'—'])}${k(['Authorized',d.authorized?'Yes':'No'])}${k(['Days left',d.daysLeft??'—'])}${k(['Issuer',d.issuer?.O||d.issuer?.CN||'—'])}${k(['Subject',d.subject?.CN||'—'])}${k(['Fingerprint',d.fingerprint256||'—'])}`})}
function blacklistTool(){inputTool('Blacklist Check',[{id:'ip',ph:'8.8.8.8'}],async({ip})=>{const d=await j('/api/blacklist?ip='+encodeURIComponent(ip));return d.results.map(x=>`<div class="kv"><span>${esc(x.name)}</span><span class="${x.listed?'bad-dot':x.status==='unavailable'?'bad-dot':'ok-dot'}">${x.listed?'LISTED':x.status==='unavailable'?'UNAVAILABLE':'NOT LISTED'}</span></div>`).join('')+`<p class="muted">${esc(d.note)}</p>`})}
function macTool(){inputTool('جستجوی سازنده MAC',[{id:'mac',ph:'00:11:22:33:44:55'}],async({mac})=>{const d=await j('/api/mac?mac='+encodeURIComponent(mac));return k(['Vendor',d.vendor||'Not found'])})}
function browserTool(){const n=navigator;const c=document.createElement('canvas');let gl=null;try{gl=c.getContext('webgl')||c.getContext('experimental-webgl')}catch(_){}let renderer='';try{const ext=gl?.getExtension('WEBGL_debug_renderer_info');renderer=ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):'hidden'}catch(_){}openModal('اطلاعات مرورگر',`<div class="result">${k(['User Agent',n.userAgent])}${k(['Platform',n.platform])}${k(['Languages',n.languages?.join(', ')||'—'])}${k(['Screen',`${screen.width}×${screen.height}`])}${k(['Timezone',Intl.DateTimeFormat().resolvedOptions().timeZone])}${k(['CPU threads',n.hardwareConcurrency||'—'])}${k(['WebGL renderer',renderer||'hidden'])}</div>`)}
async function webrtcData(){if(!window.RTCPeerConnection)throw new Error('WebRTC is not supported.');const pc=new RTCPeerConnection({iceServers:[]});pc.createDataChannel('probe');const found=new Set();pc.onicecandidate=e=>{if(e.candidate){const m=String(e.candidate.candidate||'').match(/((?:\d{1,3}\.){3}\d{1,3}|[a-f0-9:]{2,})/i);if(m)found.add(m[1])}};const offer=await pc.createOffer();await pc.setLocalDescription(offer);await new Promise(r=>setTimeout(r,1300));pc.close();return [...found]}
function webrtcTool(){openModal('تست WebRTC',`<div id="rtcOut" class="result">در حال جمع‌آوری candidateها…</div>`);webrtcData().then(xs=>{const out=$('#rtcOut');if(!out)return;out.innerHTML=xs.length?xs.map(x=>`<span class="chip">${esc(x)}</span>`).join(' '):'candidate قابل استخراجی یافت نشد.'}).catch(e=>{const out=$('#rtcOut');if(out)out.innerHTML=`<div class="code">${esc(e.message)}</div>`})}
function invisibleTool(){openModal('تست نامرئی بودن',`<div class="result" id="inv">در حال جمع‌آوری نشانه‌ها…</div>`);Promise.all([webrtcData().catch(()=>[]),j('/api/ip/me').catch(()=>({}))]).then(([rtc,ip])=>{const out=$('#inv');if(!out)return;out.innerHTML=`${k(['WebRTC candidates',rtc.length?rtc.length+' مورد':'هیچ موردی'])}${k(['Detected public IP',ip.publicIp||ip.clientIp||'—'])}<p class="muted">این ابزار تضمین ناشناس‌بودن نمی‌دهد؛ فقط چند نشانه قابل مشاهده را گزارش می‌کند.</p>`})}
function securityTool(){inputTool('چک‌لیست امنیت آنلاین',[{id:'url',ph:'https://example.com'}],async({url})=>{const d=await j('/api/http-check?url='+encodeURIComponent(url));const h=d.headers||{};return `${k(['HTTPS',/^https:/i.test(d.url||url)?'PASS':'WARN'])}${k(['HSTS',h['strict-transport-security']?'PASS':'WARN'])}${k(['CSP',h['content-security-policy']?'PASS':'INFO'])}${k(['X-Content-Type-Options',h['x-content-type-options']?'PASS':'INFO'])}${k(['X-Frame-Options',h['x-frame-options']?'PASS':'INFO'])}${k(['Referrer-Policy',h['referrer-policy']?'PASS':'INFO'])}`})}
function speedTool(){openModal('تست سرعت',`<div class="result"><button id="speedGo" class="primary">شروع تست</button><div id="speedOut" class="muted">دانلود از همین سرور.</div></div>`);const go=$('#speedGo');if(!go)return;go.onclick=async()=>{const out=$('#speedOut');if(!out)return;go.disabled=true;out.textContent='در حال آماده‌سازی تست…';try{const session=await j('/api/speed/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({bytes:10000000})});const start=performance.now();const url=session.downloadUrl+(session.downloadUrl.includes('?')?'&':'?')+'cb='+Date.now();const r=await fetch(url,{cache:'no-store',headers:{accept:'application/octet-stream'}});if(!r.ok)throw new Error(`Speed test HTTP ${r.status}`);const b=await r.arrayBuffer();const sec=(performance.now()-start)/1000;const mbps=(b.byteLength*8/sec/1e6);out.innerHTML=`${k(['Payload',`${(b.byteLength/1e6).toFixed(1)} MB`])}${k(['Time',`${sec.toFixed(2)} s`])}${k(['Download',`${mbps.toFixed(2)} Mbps`])}`}catch(e){out.innerHTML=`<div class="code">${esc(e.message)}</div>`}finally{if(go)go.disabled=false}}}
function serverTool(){openModal('وضعیت سرور',`<div id="sv" class="server-panel">در حال دریافت…</div>`);loadServerPanel('#sv')}
async function loadServerPanel(sel){try{const d=await j('/api/server-info');const mem=d.container?.memory||{};const target=$(sel);if(!target)return;const en=currentLanguage==='en';const problems=Array.isArray(d.problems)?d.problems:[];const problemsHtml=problems.length?problems.map(p=>`<div class="notice ${p.severity==='warning'?'warning':''}" style="margin-top:8px"><div class="kv"><b>${esc(p.source||'Provider')}</b><small>${esc(p.at?new Date(p.at).toLocaleString(): '')}</small></div><div>${esc(p.message||'Unknown error')}</div><small>${en?'Occurrences':'تعداد رخداد'}: ${Number(p.occurrences||1)}</small></div>`).join(''):`<div class="notice" style="margin-top:8px">${en?'No outstanding provider/source problems have been recorded.':'در حال حاضر خطای ثبت‌شده‌ای از منابع و سرویس‌ها وجود ندارد.'}</div>`;target.innerHTML=`<div class="server-card card">${k(['Hostname',d.hostname||'—'])}${k(['Platform',d.platform||'—'])}${k(['Node',d.node||'—'])}${k(['PID',d.process?.pid||'—'])}</div><div class="server-card card">${k(['CPU cores',d.cpus||'—'])}${k(['Uptime',Math.round(d.uptimeSeconds||0)+' s'])}${k(['Load',d.load?.map(x=>Number(x).toFixed(2)).join(' / ')||'—'])}${k(['Process RSS',Math.round((d.memory?.rss||0)/1048576)+' MB'])}${k(['Container RAM',mem.currentBytes!=null?`${(mem.currentBytes/1048576).toFixed(0)} MB${mem.limitBytes?` / ${(mem.limitBytes/1048576).toFixed(0)} MB (${mem.percent}%)`:''}`:'—'])}</div><div class="server-card card"><div class="kv"><b>${en?'Problems':'مشکلات'}</b><span class="${problems.length?'bad-dot':'ok-dot'}">${problems.length?`${problems.length} ${en?'active':'مورد'}`:(en?'Clear':'بدون خطا')}</span></div>${problemsHtml}<small class="subtle">${en?'Provider errors appear here after their first occurrence.':'خطاهای منابع پس از اولین رخداد در این بخش ثبت می‌شوند.'}</small></div><div class="server-card card"><b>${en?'Network interfaces':'رابط‌های شبکه'}</b><div class="code">${esc(JSON.stringify(d.interfaces||[],null,2))}</div></div>`}catch(e){$(sel).innerHTML=`<div class="code">${esc(e.message)}</div>`}}
async function loadServer(){loadServerPanel('#serverPanel')}
async function loadHistory(){try{const d=await j('/api/history?limit=100');$('#historyList').innerHTML=d.items.length?d.items.map(x=>`<div class="history-item"><div><div class="target">${esc(x.target||'—')}</div><div class="meta">${esc(x.type)} · ${new Date(x.at).toLocaleString('fa-IR')} · ${esc(x.summary||'')}</div></div><div class="${x.ok?'ok-dot':'bad-dot'}">● ${x.ok?'OK':'ERR'}</div></div>`).join(''):'<div class="card empty-card">تاریخچه‌ای وجود ندارد.</div>'}catch(e){toast(e.message)}}

function formatUptime(s){const h=Math.floor(s/3600),m=Math.floor((s%3600)/60);return h?`${h}h ${m}m`:`${m}m`}
async function refreshDashboard(){
  const set=(id,v)=>{const el=$('#'+id);if(el)el.textContent=String(v)};
  let data=null;
  const endpoints=['/api/telemetry','/api/server-info','/api/dashboard','/api/health'];
  for(const endpoint of endpoints){
    try{ data=await j(endpoint); if(data?.ok!==false) break; }catch(_){ data=null; }
  }
  if(data){
    const uptime=Number(data.uptimeSeconds ?? data.server?.uptimeSeconds ?? data.uptimeSec ?? data.uptime ?? 0);
    const metrics=data.metrics||{};
    const active=metrics.activeScans ?? data.scanner?.activeJobs ?? 0;
    const req=metrics.requests ?? data.metrics?.requests ?? 0;
    const avg=metrics.avgResponseMs ?? data.metrics?.avgResponseMs;
    set('sUptime',formatUptime(uptime));set('sReq',Number(req));set('sScan',Number(active));set('sAvg',avg!=null?fmtMs(avg):'—');
    const online=$('#online'); if(online){online.textContent='● آنلاین';online.className='status-pill ok'}
    set('sOnline','آنلاین');
  }else{
    set('sUptime','offline');set('sReq','—');set('sScan','—');set('sAvg','—');set('sOnline','آفلاین');
    const online=$('#online'); if(online){online.textContent='● آفلاین';online.className='status-pill bad'}
  }
  try{const d=await j('/api/proxifly/summary');set('sProxiflyEntries',Number(d.totalEntries||0).toLocaleString());set('sProxiflyIps',Number(d.uniqueIpCount||0).toLocaleString());set('sProxiflyCountries',Number(d.countryCount||0).toLocaleString());set('sProxiflyMode',`${d.sourceMode==='local-fallback'?'JSON پشتیبان محلی':'Proxifly زنده'}${d.localSnapshotAvailable?' · فایل پشتیبان موجود است':''}`)}catch(_){set('sProxiflyEntries','—');set('sProxiflyIps','—');set('sProxiflyCountries','—');set('sProxiflyMode','منبع فعلاً در دسترس نیست')}
  try{const ip=await getBrowserPublicIp();set('heroIp',ip||'—')}catch(_){set('heroIp','—')}
}
function loadSavedTargets(){let values=[];try{values=JSON.parse(storageGet(SAVED_KEY,'[]')||'[]')}catch(_){};const s=$('#savedTargets');if(!s)return;s.innerHTML='<option value="">انتخاب…</option>'+values.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('')}
function loadRecipes(){let values=[];try{values=JSON.parse(storageGet(RECIPE_KEY,'[]')||'[]')}catch(_){};return Array.isArray(values)?values:[]}
function saveRecipe(){const target=$('#scanTargetMain').value.trim();if(!target)return toast('اول Target را وارد کن.');const recipe={name:`${target} · ${new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})}`,target,profile:$('#scanProfile').value,ports:[...selectedPorts].map(Number),onlyOpen:$('#onlyOpen').checked,pingOnly:$('#pingOnly').checked};const list=[recipe,...loadRecipes().filter(x=>x.target!==target||x.profile!==recipe.profile)].slice(0,20);storageSet(RECIPE_KEY,JSON.stringify(list));toast('Recipe ذخیره شد.')}
function openRecipePicker(){const list=loadRecipes();if(!list.length)return toast('Recipe ذخیره‌شده‌ای نداریم.');openModal('Load Scan Recipe',`<div class="recipe-list">${list.map((r,i)=>`<button class="recipe-row" data-recipe="${i}"><b>${esc(r.name)}</b><span>${esc(r.target)} · ${esc(r.profile||'custom')} · ${(r.ports||[]).join(',')}</span></button>`).join('')}</div>`);$$('[data-recipe]').forEach(b=>b.onclick=()=>{const r=list[Number(b.dataset.recipe)];$('#scanTargetMain').value=r.target||'';$('#scanProfile').value=r.profile||'custom';selectedPorts=new Set((r.ports||[]).map(Number));$('#onlyOpen').checked=Boolean(r.onlyOpen);$('#pingOnly').checked=Boolean(r.pingOnly);renderPortButtons();closeModal();toast('Recipe بارگذاری شد.')})}
function openScannerView(){switchView('scanner')}
$('#savedTargets')?.addEventListener('change',e=>{if(e.target.value&&$('#scanTargetMain'))$('#scanTargetMain').value=e.target.value})
$('#saveTargetBtn')?.addEventListener('click',()=>{const v=$('#scanTargetMain').value.trim();if(!v)return toast('اول target را وارد کن.');let values=[];try{values=JSON.parse(storageGet(SAVED_KEY,'[]')||'[]')}catch(_){}values=[v,...values.filter(x=>x!==v)].slice(0,30);storageSet(SAVED_KEY,JSON.stringify(values));loadSavedTargets();toast('Target ذخیره شد.')});
$('#saveRecipeBtn')?.addEventListener('click',saveRecipe);$('#loadRecipeBtn')?.addEventListener('click',openRecipePicker);

function renderPortGroups(){const box=$('#portGroups');if(!box)return;const groups=scanConfig?.portGroups||{};const names={web:'WEB',remote:'REMOTE',mail:'MAIL',dns:'DNS',database:'DATABASE',common:'COMMON'};box.innerHTML=Object.keys(names).map(key=>`<button class="group-btn" data-group="${key}">${names[key]}</button>`).join('');box.querySelectorAll('[data-group]').forEach(b=>b.onclick=()=>applyPortGroup(b.dataset.group));}
function renderPortControls(){return renderPortButtons()}
function renderPortButtons(){const box=$('#portButtons'),groups=scanConfig?.portGroups||{};const all=[...new Set(Object.values(groups).flat().map(Number))].sort((a,b)=>a-b);if(!box)return;box.innerHTML=all.map(p=>`<button class="port-btn ${selectedPorts.has(p)?'selected':''}" data-port="${p}"><span>${p}</span><small>${esc(portName(p))}</small></button>`).join('');box.querySelectorAll('[data-port]').forEach(b=>b.onclick=()=>togglePort(Number(b.dataset.port)));updateSelectedPorts()}
function togglePort(port){if(selectedPorts.has(port))selectedPorts.delete(port);else selectedPorts.add(port);renderPortButtons()}
function applyPortGroup(key){const ports=scanConfig?.portGroups?.[key]||[];selectedPorts=new Set(ports.map(Number));$('#scanProfile').value=scanConfig?.defaultProfiles?.[key]?key:$('#scanProfile').value;renderPortButtons();toast(`${ports.length} پورت انتخاب شد.`)}
function updateSelectedPorts(){const chips=$('#selectedPortChips');const arr=[...selectedPorts].sort((a,b)=>a-b);$('#portSelectionCount').textContent=`${arr.length} selected`;chips.innerHTML=arr.length?arr.map(p=>`<span class="selected-chip">${p}<small>${esc(portName(p))}</small></span>`).join(''):'<span class="muted">هیچ پورتی انتخاب نشده.</span>'}
$('#clearPorts')?.addEventListener('click',()=>{selectedPorts.clear();renderPortButtons()})
$('#scanProfile')?.addEventListener('change',()=>{const p=scanConfig?.defaultProfiles?.[$('#scanProfile').value];if(p?.ports?.length){selectedPorts=new Set(p.ports.map(Number));renderPortButtons()}})

async function loadScanConfig(){
  loadSavedTargets();
  try{
    scanConfig=await j('/api/scan/config');
    const enabled=Boolean(scanConfig.enabled);
    $('#scannerState').textContent=enabled?'READY':'ERROR';$('#scannerState').className='badge '+(enabled?'ok':'bad');
    $('#scanRules').textContent=scanConfig.allowedRulesCount??0;$('#scanMaxHosts').textContent=scanConfig.maxHosts??'—';$('#scanMaxPorts').textContent=scanConfig.maxPorts??'—';$('#scanEnabled').textContent=scanConfig.authorizedScanEnabled?'World + Active':'World only';
    $('#allowlistBox').innerHTML=scanConfig.authorizedScanEnabled?`<div class="notice"><b>${esc(scanConfig.allowedRulesCount??0)} rule</b> برای Active Scan فعال است؛ World Discovery بدون Target هم کار می‌کند.</div>`:'<div class="notice"><b>World Discovery فعال است.</b> <code>SCAN_ALLOWED_TARGETS</code> فقط برای Active Scanner اختیاری است.</div>';
    renderPortGroups();
    if(!selectedPorts.size)selectedPorts=new Set((scanConfig.defaultProfiles?.common?.ports||[]).map(Number));
    renderPortButtons();
  }catch(e){$('#scannerState').textContent='ERROR';$('#scannerState').className='badge bad';toast(e.message)}
}
$('#scanPreview')?.addEventListener('click',async()=>{const target=$('#scanTargetMain').value.trim();if(!target)return toast('Target را وارد کن.');try{const d=await j('/api/scan/preview?target='+encodeURIComponent(target));openModal('Scan Preview',`<div class="result">${k(['Target',d.target])}${k(['Hosts',d.count])}${k(['Kind',d.kind])}${k(['Authorization','Allowed'])}</div><div class="code">${esc((d.sample||[]).join('\n'))}</div>`)}catch(e){toast(e.message)}})
$('#scanStartMain')?.addEventListener('click',startMainScan);

async function startMainScan(){
  if(scanTimer)clearInterval(scanTimer);
  const target=$('#scanTargetMain').value.trim(), profile=$('#scanProfile').value, ports=[...selectedPorts].sort((a,b)=>a-b), timeout=Math.min(Math.max(Number($('#scanTimeout').value||2200),800),4000);
  if(!target)return toast('Target را وارد کن.');
  if(!ports.length && !$('#pingOnly').checked)return toast('حداقل یک پورت انتخاب کن.');
  $('#scanStartMain').disabled=true;$('#scanProgress').classList.remove('hidden');$('#scanDashboard').classList.add('hidden');setProgress(0,'در حال ساختن job…','—');
  try{const d=await j('/api/scan/jobs',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({target,profile,ports:ports.join(','),portTimeout:timeout,pingOnly:$('#pingOnly').checked,onlyOpen:$('#onlyOpen').checked})});currentScan=d.job.id;scanTimer=setInterval(pollScan,500);await pollScan()}catch(e){$('#scanStartMain').disabled=false;setProgress(0,'خطا',e.message);toast(e.message)}
}
async function pollScan(){if(!currentScan)return;try{const d=await j('/api/scan/jobs/'+encodeURIComponent(currentScan));const job=d.job;const pct=job.progress||0;setProgress(pct,job.phase||'در حال کار…',`${job.completedHosts||0}/${job.totalHosts||0} hosts`);if(job.status==='done'){clearInterval(scanTimer);scanTimer=null;currentRows=job.results||[];renderScanDashboard(job);$('#scanStartMain').disabled=false;$('#scanProgress').classList.add('hidden');toast(`تمام شد؛ ${job.summary?.online||0} دستگاه online.`)}else if(job.status==='error'){clearInterval(scanTimer);scanTimer=null;$('#scanStartMain').disabled=false;setProgress(0,'اسکن ناموفق',job.error||'Unknown error');toast(job.error||'Scan error')}}catch(e){clearInterval(scanTimer);scanTimer=null;$('#scanStartMain').disabled=false;setProgress(0,'خطا',e.message)}}
function setProgress(p,phase,meta){$('#scanPhase').textContent=phase;$('#scanPercent').textContent=Math.round(p)+'%';$('#scanBar').style.width=Math.max(0,Math.min(100,p))+'%';$('#scanProgressMeta').textContent=meta}
function renderScanDashboard(job){const s=job.summary||{};$('#scanDashboard').classList.remove('hidden');$('#scanFound').textContent=s.found??job.results.length;$('#scanOnline').textContent=s.online??0;$('#scanOpen').textContent=s.openPorts??0;$('#scanAvg').textContent=s.avgLatencyMs!=null?fmtMs(s.avgLatencyMs):'—';$('#scanDuration').textContent=fmtMs(s.durationMs);$('#scanWeb').textContent=s.webServices??0;$('#scanTls').textContent=s.tlsServices??0;const counts=s.serviceCounts||{};const top=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,4).map(([name,n])=>`${name}: ${n}`).join(' · ');$('#openFinderText').textContent=top||'—';$('#tableHint').textContent=`${job.results.length} host`;renderRows();}
function renderRows(){const q=$('#deviceSearch').value.trim().toLowerCase(),filter=$('#onlineFilter').value,sort=$('#sortFilter').value;let rows=currentRows.filter(r=>{if(filter==='online'&&!r.online)return false;if(filter==='offline'&&r.online)return false;const hay=[r.ip,r.hostname,r.mac,r.vendor].join(' ').toLowerCase();return !q||hay.includes(q)});if($('#onlyOpen').checked)rows=rows.filter(r=>(r.openPorts||[]).length>0);rows.sort((a,b)=>{if(sort==='latency')return (a.ping?.latencyMs??999999)-(b.ping?.latencyMs??999999);if(sort==='ports')return (b.openPorts?.length||0)-(a.openPorts?.length||0);if(sort==='status')return Number(b.online)-Number(a.online);return ipSort(a.ip,b.ip)});$('#deviceRows').innerHTML=rows.length?rows.map((r,i)=>`<tr><td class="${r.online?'device-online':'device-offline'}">● ${r.online?'Online':'Offline'}</td><td><code>${esc(r.ip)}</code></td><td>${esc(r.hostname||'—')}</td><td><code>${esc(r.mac||'—')}</code></td><td>${esc(r.vendor||'—')}</td><td>${r.ping?.latencyMs!=null?`<span class="latency-pill">${fmtMs(r.ping.latencyMs)}</span>`:'—'}</td><td><div class="port-list">${r.openPorts?.length?r.openPorts.map(p=>`<span class="port-chip open">${p.port}<small>${esc(p.service||portName(p.port))}</small></span>`).join(''):'<span class="port-chip">none</span>'}</div></td><td><div class="row-actions"><button class="row-btn" data-detail="${currentRows.indexOf(r)}">جزئیات</button><button class="row-btn icon-mini" data-copy="${esc(r.ip)}">⧉</button></div></td></tr>`).join(''):'<tr><td colspan="8" class="empty">موردی پیدا نشد.</td></tr>';$('#deviceRows').querySelectorAll('[data-detail]').forEach(btn=>btn.onclick=()=>showDevice(currentRows[Number(btn.dataset.detail)]));$('#deviceRows').querySelectorAll('[data-copy]').forEach(btn=>btn.onclick=()=>navigator.clipboard?.writeText(btn.dataset.copy).then(()=>toast('IP کپی شد.')).catch(()=>toast('کپی نشد.')))}
function ipSort(a,b){const aa=String(a||'').split('.').map(Number),bb=String(b||'').split('.').map(Number);for(let i=0;i<4;i++){const x=aa[i]??0,y=bb[i]??0;if(x!==y)return x-y}return String(a||'').localeCompare(String(b||''))}
$('#deviceSearch')?.addEventListener('input',renderRows);$('#onlineFilter')?.addEventListener('change',renderRows);$('#sortFilter')?.addEventListener('change',renderRows);

function lookupSingleIp(ip){closeModal();lookupToolWithValue(ip)}
function lookupToolWithValue(ip){
  inputTool(currentLanguage==='en'?'IP details / RDAP':'بررسی IP / RDAP',[{id:'ip',ph:'IP',value:ip}],async({ip})=>{
    const [d,p] = await Promise.all([
      j('/api/ip/lookup?ip='+encodeURIComponent(ip)),
      j('/api/ip-db/ping?ip='+encodeURIComponent(ip)).catch(e=>({ok:false,error:e.message,ping:null,databases:[]}))
    ]);
    const ping=p.ping||{};const online=Boolean(ping.ok);
    const databaseNames=(p.databases||[]).join(' · ')|| (currentLanguage==='en'?'Not yet in local database':'هنوز در دیتابیس محلی ثبت نشده');
    const country=currentLanguage==='en'?'Country':'کشور';const network=currentLanguage==='en'?'Network':'شبکه';const ports=currentLanguage==='en'?'Reported ports':'پورت‌های گزارش‌شده';
    return `${k(['IP',d.ip||ip])}${k([country,d.country||'—'])}${k([network,d.name||'—'])}${k(['ASN',d.asn?`AS${esc(d.asn.asn||d.asn)}`:'—'])}${k([currentLanguage==='en'?'Ping status':'وضعیت پینگ',online?(currentLanguage==='en'?'ONLINE':'آنلاین'):(currentLanguage==='en'?'No live reply':'پاسخ زنده دریافت نشد')])}${k([currentLanguage==='en'?'Average ping':'میانگین پینگ',fmtMs(ping.avgMs??ping.latencyMs)])}${k([currentLanguage==='en'?'Ping source':'منبع پینگ',ping.source||'—'])}${k([currentLanguage==='en'?'Saved in':'ذخیره‌شده در',databaseNames])}${k([ports,(d.openPorts||[]).join(', ')||'—'])}${k([currentLanguage==='en'?'IP range':'بازه IP',`${d.startAddress||'—'} → ${d.endAddress||'—'}`])}<details><summary>${currentLanguage==='en'?'Raw lookup data':'اطلاعات خام'}</summary><div class="code">${esc(JSON.stringify(d.raw,null,2))}</div></details>`;
  })
}
function dnsSingleHost(host){closeModal();inputTool('DNS Lookup',[{id:'host',ph:'hostname',value:host},{id:'type',label:'Record type',type:'select',value:'A',options:['A','AAAA','MX','NS','TXT','CNAME','SOA','SRV','CAA']}],async({host,type})=>{const d=await j('/api/dns?host='+encodeURIComponent(host)+'&type='+encodeURIComponent(type));return `<div class="code">${esc(JSON.stringify(d.records,null,2))}</div>`})}
function showDevice(r){
  if(!r)return;
  const ports=(r.openPorts||[]).map(x=>`<div class="kv"><span>${x.port} · ${esc(x.service||portName(x.port))}</span><span class="ok-dot">OPEN · ${fmtMs(x.latencyMs)}</span></div>`).join('')||'<div class="muted">پورت باز پیدا نشد.</div>';
  const http=(r.http||[]).map(x=>`<div class="result"><b>HTTP ${x.port}</b><div class="code">${esc(JSON.stringify(x.details,null,2))}</div></div>`).join('');
  const tls=(r.tls||[]).map(x=>`<div class="result"><b>TLS ${x.port}</b><div class="code">${esc(JSON.stringify(x.details,null,2))}</div></div>`).join('');
  const banners=(r.banners||[]).filter(x=>x.banner).map(x=>`<div class="result"><b>Banner ${x.port}</b><div class="code">${esc(x.banner)}</div></div>`).join('');
  openModal(`جزئیات ${r.ip}`,`<div class="result">${k(['Status',r.online?'ONLINE':'OFFLINE'])}${k(['Hostname',r.hostname||'—'])}${k(['MAC',r.mac||'—'])}${k(['Vendor',r.vendor||'—'])}${k(['Ping',fmtMs(r.ping?.latencyMs)])}${k(['Checked ports',r.totalPortsChecked])}${k(['Elapsed',fmtMs(r.elapsedMs)])}</div><div class="result"><b>Actions</b><div class="hero-actions"><button class="secondary" id="actionCopy">Copy IP</button><button class="secondary" id="actionIp">IP / RDAP</button>${r.hostname?'<button class="secondary" id="actionDns">DNS</button>':''}<button class="secondary" id="actionMtr">MTR</button>${http?'<button class="secondary" id="actionHttp">HTTP</button>':''}${tls?'<button class="secondary" id="actionTls">TLS</button>':''}<button class="primary" id="actionExport">Export JSON</button></div></div><div class="result"><b>Open ports</b>${ports}</div>${http}${tls}${banners}`);
  $('#actionCopy').onclick=()=>navigator.clipboard?.writeText(r.ip).then(()=>toast('IP کپی شد.')).catch(()=>toast('کپی نشد.'));$('#actionIp').onclick=()=>lookupSingleIp(r.ip);$('#actionDns')?.addEventListener('click',()=>dnsSingleHost(r.hostname));$('#actionMtr').onclick=()=>{closeModal();mtrToolWithValue(r.ip)};$('#actionHttp')?.addEventListener('click',()=>openModal(`HTTP ${r.ip}`,http||'<div class="notice">اطلاعات HTTP موجود نیست.</div>'));$('#actionTls')?.addEventListener('click',()=>openModal(`TLS ${r.ip}`,tls||'<div class="notice">اطلاعات TLS موجود نیست.</div>'));$('#actionExport').onclick=()=>downloadBlob(JSON.stringify(r,null,2),`mahdiar-${r.ip.replace(/[:.]/g,'_')}.json`,'application/json')
}
function mtrToolWithValue(host){inputTool('MTR / Route',[{id:'host',ph:'host',value:host}],async({host})=>{const d=await j('/api/mtr?host='+encodeURIComponent(host));if(!d.ok)return `<div class="notice">${esc(d.error||'MTR unavailable')}</div>`;return `${k(['Command',d.command])}<div class="code">${esc(d.raw||'')}</div>`})}
function exportData(){return currentRows.map(r=>({ip:r.ip,hostname:r.hostname||'',mac:r.mac||'',vendor:r.vendor||'',online:Boolean(r.online),latencyMs:r.ping?.latencyMs??null,openPorts:(r.openPorts||[]).map(p=>p.port),services:(r.openPorts||[]).map(p=>p.service||portName(p.port)),http:r.http||[],tls:r.tls||[]}))}
$('#exportJson')?.addEventListener('click',()=>downloadBlob(JSON.stringify(exportData(),null,2),'mahdiar-scan.json','application/json'));
$('#exportCsv')?.addEventListener('click',()=>{const rows=exportData(),head=['ip','hostname','mac','vendor','online','latencyMs','openPorts','services'];const body=[head,...rows.map(r=>head.map(k=>`"${String(Array.isArray(r[k])?r[k].join('|'):r[k]??'').replace(/"/g,'""')}"`))].map(x=>x.join(',')).join('\n');downloadBlob('\ufeff'+body,'mahdiar-scan.csv','text/csv;charset=utf-8')});
function downloadBlob(data,name,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type}));a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}

async function loadCountries(){const box=$('#countrySelect');if(!box||box.dataset.loaded==='1')return;try{const d=await j('/api/ip/countries');box.innerHTML=d.countries.map(c=>`<option value="${c.code}">${flag(c.code)} ${esc(c.name)} (${c.code})</option>`).join('');box.dataset.loaded='1';}catch(e){$('#countryState').textContent='خطا';$('#countryState').className='badge bad';toast(e.message)}}
function countryRangesTool(){openModal('IP کشورهای مختلف',`<div class="form-grid"><label class="modal-label">کشور<select id="countryModalSelect" class="field"></select></label><label class="modal-label">حداکثر رنج<input id="countryModalLimit" class="field" value="40" inputmode="numeric"></label><button id="countryModalRun" class="primary">نمایش</button></div><div id="countryModalOut" class="result">کشور را انتخاب کن.</div>`);j('/api/ip/countries').then(d=>{$('#countryModalSelect').innerHTML=d.countries.map(c=>`<option value="${c.code}">${flag(c.code)} ${esc(c.name)} (${c.code})</option>`).join('');$('#countryModalSelect').value='US'}).catch(e=>$('#countryModalOut').innerHTML=`<div class="code">${esc(e.message)}</div>`);$('#countryModalRun').onclick=async()=>{const c=$('#countryModalSelect').value,limit=Math.min(Math.max(Number($('#countryModalLimit').value||40),1),100);setLoading($('#countryModalOut'));try{const d=await j('/api/ip/country-ranges?country='+encodeURIComponent(c)+'&limit='+limit);$('#countryModalOut').innerHTML=`${k(['کشور',`${flag(d.country)} ${d.countryName} (${d.country})`])}${k(['کل رنج‌ها',d.totalRanges])}${k(['نمایش',d.returnedRanges])}<div class="result">${d.ranges.map(r=>`<div class="kv"><span><code>${esc(r.cidr)}</code></span><span>${Number(r.addresses).toLocaleString()} IP</span></div>`).join('')}</div><div class="mini-note">منبع: ${esc(d.source)}</div>`}catch(e){$('#countryModalOut').innerHTML=`<div class="code">${esc(e.message)}</div>`}}}
async function renderCountryRanges(){const c=$('#countrySelect').value,limit=$('#countryLimit').value,state=$('#countryState');state.textContent='در حال دریافت';state.className='badge neutral';$('#countryRanges').classList.add('hidden');$('#countrySummary').classList.add('hidden');try{const d=await j('/api/ip/country-ranges?country='+encodeURIComponent(c)+'&limit='+encodeURIComponent(limit));$('#countrySummary').classList.remove('hidden');$('#countrySummary').innerHTML=`<div class="info-grid"><div><small>Country</small><b>${flag(d.country)} ${esc(d.countryName)}</b></div><div><small>Code</small><b>${esc(d.country)}</b></div><div><small>Total ranges</small><b>${d.totalRanges}</b></div><div><small>Shown</small><b>${d.returnedRanges}</b></div></div><div class="notice">فهرست از ${esc(d.source)} گرفته شده؛ آخرین دریافت ${esc(new Date(d.fetchedAt).toLocaleString('fa-IR'))}. ${d.truncated?'نمایش محدود شده است.':''}</div>`;currentCountryRows=d.ranges||[];renderCountryRows();$('#countryRanges').classList.remove('hidden');$('#countryHint').textContent=`${currentCountryRows.length} range`;state.textContent='آماده';state.className='badge ok'}catch(e){state.textContent='خطا';state.className='badge bad';toast(e.message)}}
function renderCountryRows(){const q=$('#countrySearch').value.trim().toLowerCase();const rows=currentCountryRows.filter(r=>!q||`${r.cidr} ${r.firstIp}`.toLowerCase().includes(q));$('#countryRows').innerHTML=rows.length?rows.map(r=>`<tr><td class="device-online">● Listed</td><td><code>${esc(r.cidr)}</code></td><td><code>${esc(r.firstIp)}</code></td><td>${Number(r.addresses).toLocaleString()}</td><td><div class="row-actions"><button class="row-btn" data-country-ip="${esc(r.firstIp)}">IP Lookup</button><button class="row-btn" data-country-scan="${esc(r.cidr)}">Use in Scanner</button></div></td></tr>`).join(''):'<tr><td colspan="5" class="empty">موردی پیدا نشد.</td></tr>';$('#countryRows').querySelectorAll('[data-country-ip]').forEach(b=>b.onclick=()=>lookupSingleIp(b.dataset.countryIp));$('#countryRows').querySelectorAll('[data-country-scan]').forEach(b=>b.onclick=()=>openScannerWithTarget(b.dataset.countryScan))}
function openScannerWithTarget(target){switchView('scanner');$('#scanTargetMain').value=target;loadScanConfig();toast('CIDR وارد Scanner شد؛ active scan فقط با allowlist سرور اجرا می‌شود.')}
$('#loadCountryRanges')?.addEventListener('click',renderCountryRanges);$('#countrySearch')?.addEventListener('input',renderCountryRows);$('#openCountryScanner')?.addEventListener('click',()=>switchView('scanner'));

$('#clearHistory')?.addEventListener('click',async()=>{try{await j('/api/history',{method:'DELETE'});loadHistory();toast('تاریخچه پاک شد.')}catch(e){toast(e.message)}})
$('#refreshServer')?.addEventListener('click',loadServer);

loadSavedTargets();
refreshDashboard();
setInterval(refreshDashboard,20000);


/* ===== Functional v6 UI layer: real Ookla speedtest, 10-country discovery, map selection, Telegram Mini App and language switch ===== */
const LANGUAGE_TEXT = {
  fa: {
    dir:'rtl', title:'مهدیار اسکنر', menu:'منو', dashboard:'⌂ داشبورد', scanner:'🛰 اسکنر پیشرفته', countries:'🌍 کشورها و CIDR', tools:'🧰 تمام ابزارها', history:'🕘 تاریخچه', server:'🖥 وضعیت سرور',
    openScanner:'🛰 باز کردن اسکنر', myIp:'🔍 IP من', mtr:'〽 MTR / Route', quick:'نمای سریع', quickTools:'ابزارهای سریع', toolkit:'جعبه ابزار', serverTelemetry:'وضعیت سرور', language:'زبان',
    world:'🌍 اسکن پروکسی‌های Proxifly', selected:'انتخاب', searchSelected:'🔎 جستجوی کشورهای انتخاب‌شده', clear:'پاک کردن انتخاب‌ها', selectedAll:'همه کشورها', noneSelected:'همه کشورها', searching:'در حال دریافت از Proxifly و پینگ با Globalping…',
    speed:'تست سرعت', startSpeed:'شروع تست واقعی', speedReady:'تست توسط Ookla انجام می‌شود؛ نتیجه از سرور واقعی Speedtest انتخاب می‌شود.', download:'دانلود', upload:'آپلود', ping:'Ping', jitter:'Jitter', packetLoss:'Packet Loss', isp:'ISP', speedServer:'سرور تست', resultUrl:'لینک نتیجه',
    telegram:'🤖 اتصال ربات تلگرام + Mini App', saveTelegram:'ذخیره و فعال‌سازی', testTelegram:'تست پیام /start', online:'● آنلاین', offline:'● آفلاین'
  },
  en: {
    dir:'ltr', title:'Mahdiar scanner', menu:'Menu', dashboard:'⌂ Dashboard', scanner:'🛰 Advanced Scanner', countries:'🌍 Countries & CIDR', tools:'🧰 All Tools', history:'🕘 History', server:'🖥 Server Status',
    openScanner:'🛰 Open Scanner', myIp:'🔍 My IP', mtr:'〽 MTR / Route', quick:'Quick view', quickTools:'Quick tools', toolkit:'Toolkit', serverTelemetry:'Server telemetry', language:'Language',
    world:'🌍 Proxifly Proxy Scanner', selected:'Selected', searchSelected:'🔎 Search selected countries', clear:'Clear selections', selectedAll:'All countries', noneSelected:'All countries', searching:'Loading Proxifly and measuring with Globalping…',
    speed:'Speed test', startSpeed:'Run real test', speedReady:'Download/upload are measured against this server; latency uses Globalping.', download:'Download', upload:'Upload', ping:'Ping', jitter:'Jitter', packetLoss:'Packet loss', isp:'ISP', speedServer:'Test server', resultUrl:'Result URL',
    telegram:'🤖 Telegram Bot + Mini App', saveTelegram:'Save & activate', testTelegram:'Send /start test', online:'● Online', offline:'● Offline'
  }
};
Object.assign(LANGUAGE_TEXT.fa,{ipInfo:'اطلاعات IP',proxyBest:'بهترین IP پروکسی پرسرعت',proxyV4:'پروکسی‌های IPv4',proxyV6:'پروکسی‌های IPv6',guide:'راهنما',githubLive:'فهرست Proxifly',isps:'سازمان‌های مشاهده‌شده',countryIp:'IP کشورهای مختلف',search:'جستجو',ready:'آماده',noResults:'نتیجه‌ای پیدا نشد.'});
Object.assign(LANGUAGE_TEXT.en,{ipInfo:'IP Information',proxyBest:'Fast Proxy IP',proxyV4:'IPv4 Proxies',proxyV6:'IPv6 Proxies',guide:'Guide',githubLive:'Proxifly proxy feed',isps:'Observed organizations',countryIp:'Country IPs',search:'Search',ready:'Ready',noResults:'No results found.'});
const TOOL_I18N = {
  ip:['IP Discovery','Shows only your current public IP','IP discovery','Your current public IP'],
  geoip:['IP Lookup','RDAP, network, country and range','IP lookup','RDAP, network, country and range'],
  http:['HTTP Check','Status, latency and headers','HTTP check','Status, latency and headers'],
  webrtc:['WebRTC Test','Browser ICE candidates','WebRTC test','Browser ICE candidates'],
  dns:['DNS Test','DNS records with resolver fallback','DNS test','DNS records with resolver fallback'],
  speed:['Speed Test','Real internet speed test','Speed test','Real internet speed test'],
  global:['Multi-point Ping','Selected-country datacenter ping','Multi-point ping','Selected-country datacenter ping'],
  mtr:['MTR / Route','Network path from the server','MTR / Route','Network path from the server'],
  'dns-compare':['DNS Compare','Compare public resolvers','DNS compare','Compare public resolvers'],
  rules:['Web Rules','HTTPS and security headers','Web rules','HTTPS and security headers'],
  resolver:['DNS Resolver','A/AAAA/MX/NS/TXT and more','DNS resolver','A/AAAA/MX/NS/TXT and more'],
  blacklist:['Blacklist','DNSBL reputation for IPv4','Blacklist','DNSBL reputation for IPv4'],
  whois:['Whois / RDAP','IP registration data','Whois / RDAP','IP registration data'],
  mac:['MAC Vendor','Find MAC vendor','MAC vendor','Find MAC vendor'],
  browser:['Browser Info','Browser, screen and WebGL','Browser info','Browser, screen and WebGL'],
  security:['Security Checklist','TLS, HSTS, CSP and headers','Security checklist','TLS, HSTS, CSP and headers'],
  invisible:['Privacy Hints','A few visible privacy signals','Privacy hints','A few visible privacy signals'],
  status:['Server Status','CPU, RAM, uptime and interfaces','Server status','CPU, RAM, uptime and interfaces'],
  'advanced-dns':['Advanced DNS','Multiple DNS record types','Advanced DNS','Multiple DNS record types'],
  port:['Port Check','Check one public target port','Port check','Check one public target port'],
  scanner:['Mahdiar Scanner','Proxifly proxy inventory + Globalping measurements','اسکنر پروکسی','فهرست Proxifly و پینگ فقط با Globalping'],
  'country-ranges':['Country IP Ranges','IPv4 ranges and CIDR','Country IP ranges','IPv4 ranges and CIDR'],
  ssl:['SSL Checker','TLS, cipher and certificate','SSL checker','TLS, cipher and certificate']
};
function t(key){return (LANGUAGE_TEXT[currentLanguage]||LANGUAGE_TEXT.fa)[key] || key}
function toolLabel(tool){const v=TOOL_I18N[tool.id];return v ? (currentLanguage==='en'?[v[2],v[3]]:[v[0],v[1]]) : [tool.name,tool.desc]}
function renderToolGridLocalized(id){const box=$(id);if(!box)return;box.innerHTML=tools.map(tool=>{const l=toolLabel(tool);return `<button class="tool-card" data-tool="${esc(tool.id)}"><div class="tool-icon">${tool.icon}</div><b>${esc(l[0])}</b><p>${esc(l[1])}</p></button>`}).join('');box.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>tools.find(x=>x.id===b.dataset.tool)?.open())}
function applyLanguage(lang=currentLanguage){
  currentLanguage = lang==='en'?'en':'fa'; storageSet('mahdiar-language',currentLanguage);
  document.documentElement.lang=currentLanguage==='en'?'en':'fa'; document.documentElement.dir=LANGUAGE_TEXT[currentLanguage].dir;
  const mapText={
    '.nav[data-view="home"]':t('dashboard'), '.nav[data-view="scanner"]':t('scanner'), '.nav[data-view="countries"]':t('countries'), '.nav[data-view="tools"]':t('tools'), '.nav[data-view="history"]':t('history'), '.nav[data-view="server"]':t('server'),
    '[data-open="scanner"]':t('openScanner'), '[data-open="ip-info"]':t('ipInfo'), '#languageSelect':null,
    '#clearHistory':currentLanguage==='en'?'Clear':'پاک کردن', '#refreshServer':currentLanguage==='en'?'Refresh':'↻ بروزرسانی', '#worldDiscoverBtn':(currentLanguage==='en'?'🔎 Scan from start':'🔎 شروع اسکن'), '#worldClearCountries':(currentLanguage==='en'?'All countries':'همه کشورها'), '#telegramSaveBtn':t('saveTelegram'), '#telegramTestBtn':t('testTelegram')
  };
  for(const [sel,text] of Object.entries(mapText)){if(text!==null){const el=$(sel);if(el)el.textContent=text;}}
  const toolSection=$('#tools .section-title h2');if(toolSection)toolSection.textContent=currentLanguage==='en'?'🧰 Toolkit':'🧰 تمام ابزارها';
  const worldTitle=$('#scanner .section-title h2');if(worldTitle)worldTitle.textContent=t('world');
  const worldBtn=$('#worldDiscoverBtn');if(worldBtn)worldBtn.textContent=currentLanguage==='en'?'🔎 Scan from start':'🔎 شروع اسکن';
  const worldAll=$('#worldClearCountries');if(worldAll)worldAll.textContent=currentLanguage==='en'?'All countries':'همه کشورها';
  const tgTitle=$('.telegram-settings .config-title b');if(tgTitle)tgTitle.textContent=t('telegram');
  renderToolGridLocalized('#toolGrid');renderToolGridLocalized('#toolGrid2');
  renderWorldCountryPickersV6(); updateWorldSelectionUI(); syncWorldMapV6();
  loadTelegramStatusV6();
}
$('#languageSelect')?.addEventListener('change',e=>applyLanguage(e.target.value));

function defaultWorldCountriesV6(){return [
  ['TR','Turkey','ترکیه',38.9637,35.2433],['FR','France','فرانسه',46.2276,2.2137],['DE','Germany','آلمان',51.1657,10.4515],['US','United States','آمریکا',37.0902,-95.7129],['NL','Netherlands','هلند',52.1326,5.2913],
  ['GB','United Kingdom','انگلستان',55.3781,-3.4360],['AE','United Arab Emirates','امارات',23.4241,53.8478],['CH','Switzerland','سوئیس',46.8182,8.2275],['CA','Canada','کانادا',56.1304,-106.3468],['IR','Iran','ایران',32.4279,53.6880]
]}
async function loadWorldCountriesV6(){
  try{
    const d=await j('/api/world/countries'); worldCountryConfig=Array.isArray(d.countries)?d.countries:[];
  }catch(_){ worldCountryConfig=[]; }
  if(!worldCountryConfig.length)worldCountryConfig=defaultWorldCountriesV6();
  const allowed=new Set(worldCountryConfig.map(x=>x.code));
  selectedWorldCountries=new Set([...selectedWorldCountries].filter(x=>allowed.has(x)));
  if(!selectedWorldCountries.size)selectedWorldCountries=new Set(DEFAULT_WORLD_SELECTED_CODES.filter(x=>allowed.has(x)));
  storageSet(WORLD_SELECTION_KEY,JSON.stringify([...selectedWorldCountries]));
  renderWorldCountryPickersV6(); initWorldMapV6(); updateWorldSelectionUI();
}

function renderWorldCountryPickersV6(){
  const box=$('#worldCountryPickers'); if(!box)return;
  box.innerHTML=worldCountryConfig.map(c=>{const active=selectedWorldCountries.has(c.code);return `<button type="button" class="country-picker ${active?'active':'off'}" data-country="${esc(c.code)}" aria-pressed="${active}">${flag(c.code)} <b>${esc(currentLanguage==='en'?c.name:c.fa)}</b><small>${c.code}</small></button>`}).join('')+`<div class="mini-note country-all-note">${selectedWorldCountries.size?(currentLanguage==='en'?'Only selected countries are included.':'فقط کشورهای انتخاب‌شده بررسی می‌شوند.'):(currentLanguage==='en'?'No country selected = all available countries.':'اگر کشوری انتخاب نکنی، همه کشورها بررسی می‌شوند.')}</div>`;
  box.querySelectorAll('[data-country]').forEach(b=>b.onclick=()=>toggleWorldCountryV6(b.dataset.country));
}
function toggleWorldCountryV6(code){
  if(selectedWorldCountries.has(code))selectedWorldCountries.delete(code);else if(worldCountryConfig.some(x=>x.code===code))selectedWorldCountries.add(code);
  storageSet(WORLD_SELECTION_KEY,JSON.stringify([...selectedWorldCountries]));
  renderWorldCountryPickersV6();updateWorldSelectionUI();syncWorldMapV6();
}
function updateWorldSelectionUI(){
  const n=selectedWorldCountries.size; const el=$('#worldSelectedCount');
  if(el)el.textContent=n?(currentLanguage==='en'?`${n} selected`:`${n} کشور انتخاب`):(currentLanguage==='en'?'All countries':'همه کشورها');
  const hidden=$('#worldCountry');if(hidden)hidden.value=[...selectedWorldCountries][0]||'';
  const btn=$('#worldDiscoverBtn');if(btn)btn.disabled=false;
  const nxt=$('#worldNextBatch');if(nxt)nxt.disabled=!lastProxiflyPagination?.hasNext;
}

function mapProject(lat,lon,w,h){return {x:Math.max(12,Math.min(w-12,((Number(lon)+180)/360)*w)),y:Math.max(12,Math.min(h-12,((90-Number(lat))/180)*h))}}
function worldMarkerSize(code){return code==='US'||code==='CA'||code==='IR'||code==='FR'||code==='TR'?34:28}
const CONTINENT_SVG_PATHS_V7={"Africa":"M 477.8,204.6 L 453.9,185.9 L 451.0,179.8 L 454.8,174.0 L 454.8,167.0 L 452.6,164.8 L 455.6,158.3 L 463.5,149.0 L 473.4,143.5 L 474.2,137.2 L 483.5,129.6 L 494.0,131.0 L 504.1,127.6 L 517.4,126.3 L 530.6,126.4 L 528.7,134.3 L 553.0,142.7 L 555.9,138.0 L 559.8,136.5 L 580.3,141.3 L 595.2,140.4 L 597.0,144.5 L 594.9,148.5 L 590.1,143.7 L 590.9,146.4 L 598.7,159.8 L 602.4,162.4 L 604.1,170.5 L 620.3,185.4 L 618.7,187.0 L 623.9,190.1 L 642.0,186.9 L 635.0,202.2 L 611.8,221.1 L 608.9,226.2 L 607.8,230.5 L 612.4,240.7 L 613.3,250.1 L 609.6,254.9 L 596.6,262.3 L 598.5,272.6 L 590.5,276.5 L 589.5,283.7 L 578.4,293.3 L 571.6,296.1 L 562.7,295.9 L 555.8,298.1 L 551.0,296.5 L 550.6,290.6 L 542.3,279.7 L 539.6,267.8 L 532.8,258.2 L 532.7,252.7 L 538.0,240.6 L 533.1,227.0 L 524.4,217.7 L 526.1,206.1 L 523.6,203.6 L 516.4,204.8 L 512.0,200.0 L 494.5,203.7 L 487.1,202.7 L 477.8,204.6 Z M 639.4,253.2 L 638.5,251.8 L 630.8,274.6 L 626.1,276.2 L 622.3,274.7 L 620.2,267.7 L 623.3,263.0 L 623.5,253.7 L 632.5,249.9 L 636.7,243.8 L 639.4,253.2 Z","Asia":"M 635.2,181.5 L 620.8,184.8 L 617.4,173.3 L 608.7,164.1 L 606.9,158.4 L 596.2,148.0 L 595.2,140.4 L 600.4,127.4 L 576.8,127.4 L 572.7,120.7 L 581.2,116.5 L 593.1,114.6 L 612.1,117.0 L 615.8,114.8 L 611.3,111.0 L 626.3,113.5 L 631.6,116.5 L 635.0,115.1 L 640.0,118.8 L 635.7,122.3 L 636.7,125.2 L 649.5,126.7 L 649.7,121.9 L 646.4,119.4 L 647.0,117.4 L 652.0,117.2 L 649.2,114.4 L 646.7,116.7 L 645.8,112.8 L 639.7,108.4 L 647.3,106.9 L 647.3,103.1 L 635.0,103.8 L 629.1,99.4 L 632.1,94.5 L 634.9,95.9 L 641.0,91.5 L 654.8,94.1 L 670.4,93.6 L 666.6,90.9 L 671.4,88.4 L 670.7,86.0 L 691.9,82.7 L 704.0,87.2 L 713.6,84.8 L 722.3,93.5 L 731.6,93.0 L 742.7,97.4 L 756.2,93.6 L 770.2,96.2 L 774.6,90.7 L 788.0,95.3 L 796.9,94.9 L 801.3,97.3 L 817.7,95.0 L 827.4,96.7 L 835.4,90.9 L 833.8,89.0 L 843.3,87.3 L 849.9,88.9 L 854.6,96.1 L 859.4,96.9 L 863.9,100.8 L 875.1,99.2 L 869.7,107.2 L 864.0,107.6 L 864.3,112.4 L 860.3,117.3 L 854.3,120.0 L 859.6,127.1 L 858.6,131.2 L 851.3,132.8 L 850.3,127.3 L 852.4,126.9 L 846.4,124.0 L 848.1,120.5 L 836.3,122.1 L 839.4,118.4 L 837.9,117.2 L 826.5,122.5 L 832.5,126.2 L 835.6,124.5 L 839.9,125.5 L 831.0,131.6 L 838.6,139.3 L 836.8,141.7 L 838.7,145.7 L 829.6,156.4 L 821.9,160.6 L 807.7,163.9 L 806.8,166.4 L 801.5,163.1 L 794.1,167.8 L 793.5,169.5 L 802.4,178.5 L 803.3,187.1 L 792.1,194.5 L 791.9,191.3 L 778.0,183.0 L 775.6,192.9 L 786.0,201.8 L 789.5,211.9 L 781.6,208.4 L 778.0,199.6 L 773.6,195.0 L 773.2,196.4 L 774.3,187.7 L 769.9,174.6 L 764.9,177.5 L 761.6,176.7 L 762.0,171.5 L 753.9,160.6 L 751.4,160.5 L 750.8,162.8 L 741.6,163.6 L 740.3,166.9 L 723.1,177.0 L 721.8,190.3 L 715.4,196.0 L 704.3,176.8 L 701.8,164.0 L 695.8,165.1 L 684.4,154.3 L 670.8,155.1 L 659.4,153.5 L 656.9,150.2 L 648.6,150.9 L 643.1,148.4 L 639.2,143.0 L 635.9,142.6 L 633.3,143.4 L 634.5,146.8 L 641.1,155.9 L 641.7,152.9 L 643.3,153.4 L 643.9,157.6 L 650.0,157.4 L 656.6,151.9 L 657.9,157.1 L 666.1,161.7 L 656.3,172.3 L 635.2,181.5 Z M 591.6,132.4 L 591.5,130.5 L 596.0,129.8 L 591.6,132.4 Z M 580.5,116.3 L 573.2,119.1 L 572.5,115.1 L 580.5,116.3 Z M 824.3,236.6 L 827.5,234.3 L 830.9,235.8 L 824.3,236.6 Z M 821.4,235.0 L 818.2,235.9 L 792.7,231.4 L 794.6,229.1 L 801.7,231.2 L 807.7,230.4 L 821.4,235.0 Z M 793.9,229.0 L 785.0,225.1 L 764.7,201.9 L 770.8,202.5 L 788.4,214.8 L 787.3,216.7 L 794.7,222.3 L 793.9,229.0 Z M 826.3,214.8 L 822.6,224.6 L 819.1,224.8 L 814.6,222.5 L 806.2,222.0 L 802.6,214.0 L 804.6,210.2 L 808.8,210.6 L 825.4,198.4 L 831.1,202.1 L 825.9,207.3 L 830.5,212.8 L 826.3,214.8 Z M 722.6,191.5 L 727.2,197.0 L 726.8,199.5 L 723.2,200.7 L 722.6,191.5 Z M 832.0,187.8 L 829.2,192.7 L 825.5,195.0 L 832.0,187.8 Z M 808.4,167.9 L 804.1,171.5 L 801.8,170.8 L 803.1,167.6 L 808.4,167.9 Z M 835.5,238.8 L 830.5,237.8 L 833.1,237.4 L 835.5,238.8 Z M 842.9,239.5 L 849.9,235.1 L 853.7,235.1 L 842.9,239.5 Z M 833.1,236.0 L 837.1,235.4 L 841.4,234.3 L 841.0,235.7 L 833.1,236.0 Z M 872.8,231.5 L 872.5,229.7 L 873.6,228.0 L 874.2,229.8 L 872.8,231.5 Z M 882.3,235.1 L 885.2,232.5 L 883.1,227.9 L 871.3,223.5 L 869.4,224.8 L 866.6,221.7 L 871.4,220.3 L 862.6,217.2 L 872.2,216.9 L 873.4,221.6 L 876.3,223.0 L 881.8,219.1 L 891.7,221.2 L 891.8,236.8 L 889.3,234.8 L 882.3,235.1 Z M 852.4,224.1 L 850.0,222.6 L 853.5,223.3 L 852.4,224.1 Z M 855.3,223.1 L 859.4,221.7 L 863.4,224.2 L 861.1,223.2 L 855.3,223.1 Z M 845.7,214.0 L 833.8,214.4 L 833.4,216.2 L 835.9,218.4 L 842.6,216.5 L 837.5,219.5 L 842.1,227.8 L 839.5,227.6 L 840.9,225.7 L 837.5,225.9 L 836.0,221.3 L 832.8,228.6 L 829.9,221.7 L 833.4,213.6 L 835.8,211.9 L 847.9,211.6 L 845.7,214.0 Z M 857.5,212.3 L 856.6,216.9 L 854.7,215.6 L 853.9,212.6 L 855.4,209.8 L 857.5,212.3 Z M 849.1,200.5 L 845.1,200.3 L 843.4,196.3 L 838.7,197.8 L 843.0,194.2 L 848.5,193.5 L 848.4,191.7 L 850.6,192.8 L 851.5,197.8 L 850.5,200.0 L 849.5,197.6 L 848.2,198.8 L 849.1,200.5 Z M 844.7,188.2 L 841.7,193.4 L 839.9,191.8 L 844.7,188.2 Z M 840.7,189.3 L 838.6,186.6 L 842.0,187.3 L 840.7,189.3 Z M 846.7,190.8 L 846.9,186.8 L 845.2,185.0 L 848.6,185.9 L 849.4,188.6 L 847.3,188.0 L 846.7,190.8 Z M 834.2,182.8 L 837.6,183.8 L 836.8,185.8 L 835.6,184.7 L 834.2,182.8 Z M 838.1,180.8 L 844.3,182.1 L 844.7,185.1 L 835.1,181.9 L 833.0,175.9 L 835.3,170.8 L 839.8,171.5 L 838.1,180.8 Z M 838.8,155.3 L 836.6,160.6 L 835.4,162.5 L 833.6,158.7 L 838.8,155.3 Z M 874.0,133.4 L 869.5,136.9 L 867.7,136.2 L 869.2,133.6 L 874.0,133.4 Z M 891.0,129.4 L 881.2,132.3 L 877.2,135.1 L 875.2,132.4 L 863.9,134.1 L 866.7,135.8 L 863.0,140.9 L 859.5,135.5 L 868.4,130.4 L 876.9,130.1 L 879.8,125.9 L 881.6,127.0 L 887.3,123.7 L 888.6,118.1 L 892.7,116.2 L 894.1,121.4 L 891.6,123.8 L 891.0,129.4 Z M 863.3,114.1 L 863.3,114.1 L 863.3,114.1 L 863.3,114.1 Z M 888.8,115.7 L 888.4,113.3 L 892.7,111.3 L 894.4,106.2 L 899.8,109.5 L 903.7,109.0 L 904.3,111.7 L 897.7,114.7 L 893.4,113.0 L 891.9,115.7 L 888.8,115.7 Z","Europe":"M 352.9,209.9 L 348.5,209.5 L 350.1,201.2 L 356.5,205.1 L 352.9,209.9 Z M 475.3,126.9 L 475.6,117.6 L 473.9,112.2 L 496.2,109.8 L 496.7,105.1 L 487.2,98.7 L 495.5,98.8 L 494.6,96.1 L 503.7,95.3 L 513.1,88.2 L 522.6,87.1 L 524.4,86.0 L 522.6,82.4 L 523.7,78.6 L 529.4,77.1 L 530.3,80.1 L 526.8,82.5 L 530.4,86.0 L 554.6,85.0 L 559.1,83.2 L 559.9,77.8 L 567.0,78.8 L 567.9,75.5 L 564.8,73.6 L 580.9,71.6 L 563.5,72.0 L 559.2,69.9 L 559.8,64.0 L 570.6,59.5 L 566.4,57.3 L 561.6,58.0 L 559.4,61.1 L 549.6,65.1 L 547.6,68.5 L 552.2,71.5 L 546.7,74.7 L 544.1,81.0 L 536.0,82.7 L 528.8,72.9 L 523.3,75.7 L 515.7,75.0 L 513.9,67.0 L 516.4,65.4 L 529.2,61.0 L 541.0,53.0 L 553.3,48.2 L 568.2,45.3 L 578.2,44.9 L 586.9,46.7 L 583.3,47.3 L 586.4,48.8 L 601.4,50.0 L 614.1,53.9 L 614.2,55.4 L 606.6,57.3 L 592.2,55.8 L 596.7,57.6 L 597.1,61.1 L 602.8,62.5 L 601.5,60.3 L 603.3,59.4 L 610.0,60.9 L 612.3,60.3 L 610.5,58.5 L 616.9,56.2 L 622.1,57.2 L 623.7,55.5 L 620.7,51.2 L 628.5,52.0 L 630.1,53.3 L 626.6,54.9 L 628.7,55.7 L 649.2,50.5 L 651.3,50.6 L 648.6,52.1 L 663.3,50.5 L 666.5,51.9 L 669.7,50.3 L 666.8,48.9 L 668.2,48.1 L 690.3,52.3 L 692.2,51.1 L 685.9,49.1 L 685.3,45.3 L 692.2,41.0 L 701.6,41.1 L 699.6,44.4 L 702.2,46.8 L 701.6,50.1 L 704.6,51.6 L 698.0,56.6 L 701.2,56.9 L 708.5,53.1 L 708.2,50.2 L 704.4,48.7 L 706.7,46.3 L 703.1,44.3 L 708.0,42.7 L 707.4,41.0 L 710.2,42.3 L 709.1,44.6 L 712.1,45.0 L 710.8,43.3 L 715.5,42.4 L 726.4,43.6 L 723.6,39.1 L 741.2,38.4 L 738.9,37.1 L 742.1,35.6 L 779.9,32.4 L 789.9,29.4 L 797.9,32.3 L 808.5,31.7 L 817.0,33.8 L 803.9,37.8 L 842.2,40.7 L 842.4,38.9 L 852.7,39.3 L 864.7,45.9 L 867.4,43.4 L 888.5,44.2 L 886.5,42.0 L 890.2,41.0 L 915.3,42.5 L 924.9,45.8 L 941.7,45.7 L 947.1,49.1 L 966.2,48.8 L 971.0,50.9 L 974.5,50.1 L 972.2,48.6 L 973.5,47.5 L 1000.0,50.3 L 1000.0,59.8 L 992.8,60.7 L 997.9,66.2 L 982.4,67.7 L 973.1,71.9 L 969.2,70.3 L 954.3,72.0 L 950.0,75.9 L 953.3,77.4 L 950.3,84.0 L 945.5,85.2 L 944.5,87.9 L 940.4,88.5 L 935.5,93.1 L 931.8,82.7 L 933.1,79.4 L 954.6,68.9 L 956.9,65.6 L 944.8,70.4 L 942.5,67.4 L 935.3,68.2 L 928.4,72.2 L 930.7,73.7 L 920.2,74.6 L 920.4,72.9 L 916.1,72.5 L 895.0,74.0 L 875.4,84.3 L 883.8,86.6 L 888.6,85.5 L 892.6,88.2 L 889.1,99.3 L 874.6,111.3 L 867.4,111.6 L 863.3,114.1 L 864.0,107.6 L 869.7,107.2 L 875.1,99.2 L 863.9,100.8 L 859.4,96.9 L 854.6,96.1 L 847.4,88.0 L 836.1,87.8 L 831.4,95.2 L 827.4,96.7 L 817.7,95.0 L 801.3,97.3 L 796.9,94.9 L 788.0,95.3 L 774.6,90.7 L 770.2,96.2 L 756.2,93.6 L 742.7,97.4 L 731.6,93.0 L 722.3,93.5 L 713.6,84.8 L 704.0,87.2 L 691.9,82.7 L 670.7,86.0 L 671.4,88.4 L 666.6,90.9 L 670.4,93.6 L 654.8,94.1 L 641.0,91.5 L 634.9,95.9 L 632.1,94.5 L 629.1,99.4 L 636.4,104.2 L 629.7,108.4 L 635.0,115.1 L 632.8,116.7 L 626.3,113.5 L 611.0,111.2 L 601.9,106.9 L 608.7,102.1 L 597.1,104.5 L 600.9,107.2 L 594.1,109.0 L 590.2,106.7 L 592.5,104.9 L 585.4,103.7 L 580.1,107.7 L 577.8,114.6 L 572.5,115.1 L 572.4,117.5 L 565.9,117.8 L 567.8,119.1 L 562.9,118.8 L 566.7,123.7 L 563.3,125.9 L 564.3,128.0 L 560.2,127.0 L 553.9,118.8 L 553.8,115.0 L 536.5,105.7 L 534.2,106.6 L 535.0,109.7 L 551.3,119.0 L 546.9,118.4 L 547.4,122.1 L 544.7,124.3 L 542.8,119.3 L 524.7,109.0 L 518.1,112.0 L 508.6,112.1 L 508.4,114.9 L 502.3,117.0 L 500.3,122.5 L 494.0,127.4 L 483.7,128.9 L 481.9,126.7 L 475.3,126.9 Z M 523.4,121.4 L 522.7,117.2 L 525.6,116.6 L 526.9,121.4 L 523.4,121.4 Z M 524.4,115.7 L 526.1,112.3 L 525.6,116.1 L 524.4,115.7 Z M 473.1,86.3 L 479.0,83.3 L 484.3,84.7 L 481.1,90.2 L 476.2,91.6 L 472.3,91.2 L 474.5,88.7 L 473.1,86.3 Z M 485.9,83.5 L 482.9,79.3 L 483.9,76.9 L 486.1,74.9 L 491.7,74.9 L 488.7,77.5 L 494.6,77.2 L 491.3,81.3 L 504.7,89.0 L 504.0,92.5 L 484.0,95.2 L 490.5,92.1 L 485.4,90.8 L 488.3,90.1 L 487.3,87.2 L 491.8,86.0 L 485.9,83.5 Z M 534.4,81.0 L 533.6,84.1 L 530.3,81.7 L 534.4,81.0 Z M 444.5,63.0 L 436.8,62.2 L 439.5,61.2 L 433.5,60.0 L 438.3,58.8 L 432.4,58.3 L 438.5,56.4 L 442.8,58.0 L 459.7,56.2 L 459.1,57.8 L 462.2,59.4 L 444.5,63.0 Z M 28.1,57.4 L 20.7,58.7 L 19.6,61.5 L 4.6,58.8 L 3.6,57.1 L 0.3,57.6 L 0.0,59.8 L 0.0,50.3 L 15.7,56.5 L 15.1,54.8 L 22.6,55.2 L 28.1,57.4 Z M 6.5,45.1 L 0.0,45.8 L 0.0,44.2 L 2.7,44.1 L 6.5,45.1 Z M 541.9,127.5 L 534.9,123.9 L 543.1,123.7 L 541.9,127.5 Z M 557.8,28.1 L 568.7,29.0 L 557.6,29.4 L 559.5,28.8 L 557.8,28.1 Z M 559.8,26.4 L 544.2,31.6 L 529.0,24.7 L 547.2,23.8 L 559.8,26.4 Z M 548.2,23.1 L 563.7,22.3 L 576.1,23.8 L 564.0,25.3 L 548.2,23.1 Z M 565.3,130.7 L 571.5,131.0 L 573.0,130.7 L 568.7,131.6 L 565.3,130.7 Z M 896.0,100.7 L 898.6,104.8 L 896.5,103.3 L 894.7,105.2 L 894.2,103.2 L 893.6,87.7 L 896.3,85.1 L 901.8,98.0 L 897.7,97.2 L 896.0,100.7 Z M 1000.0,45.8 L 997.0,45.9 L 996.5,45.2 L 1000.0,44.2 L 1000.0,45.8 Z M 889.0,39.9 L 894.6,38.6 L 898.9,40.1 L 894.7,40.1 L 889.0,39.9 Z M 683.9,31.5 L 691.3,32.1 L 662.4,37.5 L 653.9,42.1 L 659.8,46.1 L 643.3,44.3 L 654.5,35.6 L 683.9,31.5 Z M 911.7,35.0 L 918.7,35.6 L 905.9,35.4 L 911.7,35.0 Z M 880.5,35.2 L 885.6,33.1 L 903.0,34.5 L 900.8,36.3 L 886.0,36.8 L 880.5,35.2 Z M 781.3,25.7 L 792.7,27.0 L 776.2,28.9 L 781.3,25.7 Z M 763.8,26.2 L 753.3,23.1 L 766.5,20.9 L 778.3,24.4 L 777.6,26.6 L 763.8,26.2 Z M 643.1,22.2 L 632.2,23.9 L 624.6,22.5 L 639.0,21.7 L 643.1,22.2 Z","North America":"M 70.0,168.4 L 66.8,169.5 L 67.1,166.6 L 70.0,168.4 Z M 65.5,165.9 L 66.0,165.0 L 66.7,165.4 L 65.5,165.9 Z M 64.5,164.7 L 63.2,164.3 L 64.6,164.4 L 64.5,164.7 Z M 60.8,164.1 L 61.0,163.1 L 62.1,164.1 L 60.8,164.1 Z M 56.7,161.9 L 57.0,162.7 L 56.1,162.3 L 56.7,161.9 Z M 230.2,148.5 L 230.0,165.7 L 237.7,171.7 L 247.9,168.9 L 249.2,164.8 L 258.2,163.5 L 253.0,177.0 L 268.3,178.5 L 268.3,190.2 L 273.8,194.0 L 279.0,192.0 L 283.2,192.9 L 284.9,196.8 L 283.7,197.7 L 280.2,193.5 L 275.3,197.8 L 262.1,191.3 L 257.0,183.2 L 246.6,181.7 L 237.0,176.3 L 231.8,177.6 L 212.5,171.3 L 207.0,167.3 L 205.5,160.6 L 188.3,145.8 L 185.7,140.5 L 181.2,139.0 L 181.5,142.9 L 196.0,159.6 L 194.4,160.5 L 188.4,155.9 L 188.1,152.9 L 180.4,148.8 L 182.9,146.8 L 174.2,136.1 L 164.9,132.3 L 154.4,118.7 L 155.8,106.2 L 153.6,99.9 L 158.0,100.2 L 159.5,102.5 L 158.8,97.9 L 151.0,94.6 L 146.0,93.6 L 144.9,90.0 L 141.3,89.0 L 127.6,76.2 L 91.3,69.6 L 78.6,73.7 L 81.6,68.6 L 72.2,73.2 L 74.2,74.4 L 71.6,76.1 L 59.9,81.2 L 42.3,85.0 L 61.9,77.5 L 63.8,74.2 L 50.1,74.8 L 48.6,71.7 L 40.7,70.5 L 39.6,66.7 L 42.9,64.2 L 53.4,62.7 L 51.3,61.1 L 53.4,60.2 L 41.8,61.0 L 33.0,58.1 L 43.1,56.0 L 50.9,57.1 L 36.8,51.7 L 65.1,44.5 L 120.8,50.4 L 144.1,46.6 L 150.7,49.0 L 154.4,47.4 L 154.8,49.2 L 162.6,48.3 L 183.6,51.6 L 179.7,52.8 L 197.6,54.0 L 200.6,52.8 L 197.7,51.8 L 199.5,51.0 L 218.2,53.4 L 226.5,53.1 L 228.7,51.2 L 233.0,52.0 L 233.0,54.2 L 238.2,50.0 L 232.0,47.6 L 232.2,44.9 L 239.2,43.6 L 245.8,47.3 L 243.3,48.5 L 248.5,49.0 L 248.5,51.4 L 252.2,49.5 L 257.4,54.5 L 262.3,50.7 L 262.4,48.1 L 270.5,48.6 L 274.4,51.0 L 272.3,52.2 L 273.9,54.7 L 261.8,56.0 L 257.4,60.3 L 248.0,63.0 L 238.2,69.5 L 237.0,74.2 L 241.1,74.6 L 243.6,78.6 L 271.5,83.3 L 271.9,87.7 L 278.0,92.7 L 281.7,89.4 L 278.3,84.4 L 287.4,79.9 L 281.9,74.5 L 285.2,72.0 L 283.0,66.1 L 294.9,65.8 L 306.7,69.1 L 307.5,74.2 L 312.1,75.9 L 320.6,70.9 L 329.5,78.9 L 328.3,80.4 L 345.1,87.7 L 345.3,90.4 L 333.2,95.0 L 315.6,95.0 L 302.5,103.1 L 319.3,97.4 L 321.7,98.6 L 319.1,100.2 L 320.9,104.5 L 324.5,105.7 L 329.1,105.4 L 331.9,102.7 L 333.9,105.3 L 318.4,111.0 L 316.2,108.8 L 321.0,106.8 L 313.5,107.2 L 303.8,112.1 L 305.7,115.5 L 295.2,117.2 L 300.2,117.2 L 294.6,117.7 L 291.9,122.0 L 290.2,120.6 L 291.5,123.3 L 289.1,126.1 L 287.9,121.5 L 288.0,124.0 L 286.1,123.6 L 289.6,130.1 L 274.1,139.9 L 277.6,150.8 L 276.7,154.8 L 273.0,153.2 L 267.5,143.5 L 254.4,142.4 L 251.1,143.0 L 251.6,145.3 L 237.0,144.6 L 230.2,148.5 Z M 144.3,95.6 L 143.4,93.7 L 150.7,94.9 L 156.9,99.1 L 144.3,95.6 Z M 135.6,90.3 L 130.4,87.4 L 130.1,85.6 L 134.0,85.7 L 133.2,88.4 L 135.6,90.3 Z M 70.4,77.7 L 74.4,76.5 L 77.4,77.4 L 72.2,79.5 L 70.4,77.7 Z M 34.8,71.2 L 39.8,71.0 L 40.1,71.9 L 34.8,71.2 Z M 31.4,63.8 L 23.5,63.7 L 23.0,62.6 L 31.4,63.8 Z M 219.2,48.8 L 214.6,49.0 L 215.5,50.8 L 205.7,49.7 L 185.2,51.3 L 174.1,47.9 L 187.7,46.9 L 172.5,46.5 L 171.0,45.6 L 177.5,44.7 L 168.3,44.1 L 180.0,39.9 L 182.9,40.3 L 181.5,41.4 L 194.7,40.7 L 199.5,43.8 L 200.9,42.8 L 198.9,40.4 L 201.3,40.0 L 207.2,41.4 L 209.8,45.4 L 219.2,48.8 Z M 168.8,41.8 L 165.4,44.5 L 158.1,45.6 L 150.2,43.3 L 155.7,39.0 L 153.0,37.5 L 179.1,39.5 L 168.8,41.8 Z M 203.9,39.2 L 207.6,39.1 L 209.7,39.6 L 207.3,41.2 L 203.9,39.2 Z M 206.4,34.7 L 183.7,36.5 L 189.5,35.4 L 173.0,35.3 L 179.4,32.3 L 197.0,34.7 L 193.1,32.4 L 195.6,31.5 L 206.4,34.7 Z M 176.8,31.3 L 166.9,33.3 L 158.7,33.2 L 169.2,29.8 L 177.2,29.5 L 176.8,31.3 Z M 186.9,28.5 L 194.8,28.7 L 184.6,29.3 L 186.9,28.5 Z M 223.1,28.9 L 207.8,27.8 L 210.5,27.0 L 207.0,25.6 L 219.9,26.8 L 223.1,28.9 Z M 190.3,26.6 L 195.4,27.2 L 187.4,27.7 L 190.3,26.6 Z M 267.3,66.5 L 268.7,64.7 L 272.6,64.7 L 269.3,66.5 L 267.3,66.5 Z M 277.5,62.8 L 269.1,61.9 L 262.4,64.4 L 257.7,63.2 L 261.4,58.0 L 277.5,62.8 Z M 222.8,49.2 L 227.2,47.4 L 234.3,49.9 L 222.8,49.2 Z M 227.6,40.6 L 231.8,41.7 L 231.3,43.8 L 224.1,44.5 L 215.3,41.8 L 221.0,41.3 L 217.9,39.8 L 221.2,38.6 L 230.2,39.5 L 227.6,40.6 Z M 235.0,42.9 L 233.2,40.8 L 234.7,38.6 L 248.6,38.6 L 235.0,42.9 Z M 236.5,34.3 L 238.5,36.8 L 231.1,36.0 L 236.5,34.3 Z M 250.7,37.0 L 230.2,31.7 L 245.5,31.6 L 252.3,34.4 L 274.6,34.1 L 278.2,36.0 L 250.7,37.0 Z M 219.8,35.7 L 219.8,34.3 L 215.3,34.5 L 215.1,32.6 L 228.5,32.8 L 227.3,35.8 L 219.8,35.7 Z M 239.3,29.8 L 232.9,29.7 L 232.1,29.1 L 237.7,29.1 L 239.3,29.8 Z M 226.0,26.6 L 231.2,26.8 L 234.6,27.7 L 229.7,29.0 L 226.0,26.6 Z M 236.8,21.0 L 261.6,25.5 L 252.7,28.0 L 242.0,27.8 L 239.0,26.9 L 241.3,25.4 L 231.4,23.5 L 236.8,21.0 Z M 330.7,190.8 L 328.7,189.3 L 330.8,189.1 L 330.7,190.8 Z M 285.5,172.7 L 282.7,170.9 L 288.3,172.3 L 285.5,172.7 Z M 313.4,172.1 L 315.9,170.8 L 317.8,171.5 L 313.4,172.1 Z M 296.7,167.4 L 310.2,170.5 L 303.7,171.0 L 301.7,173.0 L 293.2,171.2 L 299.1,170.4 L 296.7,167.4 Z M 283.4,161.8 L 293.6,167.1 L 284.0,167.6 L 285.9,166.2 L 281.3,163.4 L 272.8,160.9 L 264.0,162.7 L 271.5,159.6 L 283.4,161.8 Z M 282.2,156.3 L 283.6,154.9 L 284.6,158.2 L 283.9,158.4 L 282.2,156.3 Z M 283.9,150.4 L 286.1,151.5 L 285.6,153.2 L 285.2,151.6 L 283.9,150.4 Z M 280.8,151.9 L 283.8,150.9 L 283.8,151.5 L 280.8,151.9 Z M 321.8,104.2 L 322.2,102.6 L 327.7,104.1 L 325.3,105.2 L 321.8,104.2 Z M 342.2,96.0 L 351.5,97.3 L 350.6,99.1 L 352.5,98.7 L 353.8,101.4 L 352.6,103.5 L 349.5,103.2 L 349.3,100.9 L 346.1,103.0 L 334.9,100.6 L 344.8,91.7 L 342.2,96.0 Z M 327.0,97.7 L 320.8,95.9 L 328.3,97.7 L 327.0,97.7 Z M 278.7,67.8 L 278.0,66.0 L 279.8,66.5 L 278.7,67.8 Z M 291.3,52.5 L 289.3,54.6 L 285.5,53.5 L 286.6,52.2 L 291.3,52.5 Z M 283.8,41.2 L 314.0,49.7 L 308.9,50.8 L 328.2,55.3 L 322.4,59.7 L 311.1,56.7 L 318.6,61.2 L 319.4,65.3 L 308.9,62.7 L 316.2,67.1 L 292.1,60.5 L 284.1,61.6 L 281.8,60.7 L 283.6,59.0 L 294.6,58.6 L 297.4,53.2 L 280.7,47.4 L 253.7,46.8 L 251.4,46.0 L 254.3,44.9 L 250.3,44.9 L 249.4,42.4 L 254.4,39.3 L 261.6,38.7 L 259.5,40.2 L 261.7,41.7 L 271.3,38.8 L 276.1,41.3 L 275.7,42.9 L 283.8,41.2 Z M 442.1,17.4 L 411.4,18.6 L 438.7,19.7 L 435.6,21.1 L 456.2,19.3 L 466.1,20.8 L 444.3,23.5 L 450.7,23.6 L 445.3,26.9 L 445.4,29.5 L 448.7,31.1 L 439.8,31.9 L 444.9,33.2 L 445.6,35.2 L 442.6,35.5 L 446.2,37.5 L 434.5,39.9 L 438.1,42.6 L 431.1,42.2 L 439.6,46.2 L 429.0,44.4 L 430.0,46.0 L 426.8,47.2 L 437.9,47.5 L 389.4,58.6 L 381.1,65.3 L 382.2,67.1 L 379.5,71.4 L 365.9,69.6 L 356.6,63.0 L 350.1,54.5 L 358.7,47.9 L 348.1,48.7 L 349.0,45.8 L 357.2,46.4 L 344.9,43.8 L 348.0,41.6 L 337.3,34.6 L 309.7,33.3 L 301.7,31.0 L 314.5,30.2 L 296.4,28.6 L 317.5,25.3 L 311.0,23.6 L 332.5,19.0 L 360.0,18.1 L 376.3,19.9 L 370.1,17.6 L 402.5,15.2 L 442.1,17.4 Z M 288.2,41.0 L 279.2,41.2 L 275.5,39.0 L 283.2,39.1 L 288.2,41.0 Z M 245.6,19.4 L 297.7,16.2 L 328.2,17.6 L 312.1,20.3 L 318.1,20.3 L 302.3,24.4 L 286.4,25.5 L 290.6,27.4 L 278.4,30.6 L 283.6,31.6 L 276.2,33.0 L 251.4,32.3 L 256.2,30.6 L 254.8,28.9 L 264.0,29.8 L 255.7,27.8 L 263.6,25.5 L 258.5,23.3 L 272.6,22.8 L 256.7,22.7 L 245.6,19.4 Z","South America":"M 309.3,347.8 L 299.3,345.2 L 292.6,341.2 L 302.5,344.2 L 304.8,341.4 L 309.3,340.7 L 311.8,343.6 L 319.3,345.7 L 309.3,347.8 Z M 310.7,340.1 L 303.2,341.4 L 301.6,343.7 L 291.8,339.8 L 290.0,331.3 L 294.1,327.1 L 289.9,326.4 L 293.5,320.4 L 296.6,321.2 L 298.0,316.2 L 293.5,318.3 L 296.6,308.8 L 295.6,303.8 L 301.6,292.4 L 304.5,258.8 L 288.9,250.0 L 273.9,226.3 L 278.4,221.3 L 275.1,220.4 L 277.5,213.2 L 285.8,205.8 L 284.8,194.6 L 289.8,192.4 L 291.9,188.5 L 300.7,185.3 L 302.4,186.1 L 300.1,187.7 L 300.8,193.3 L 301.7,188.8 L 305.7,185.9 L 310.6,189.8 L 319.7,190.9 L 328.1,189.4 L 326.7,191.2 L 341.3,200.7 L 350.1,201.2 L 348.5,209.5 L 352.9,209.9 L 357.5,205.0 L 361.2,210.9 L 360.0,215.2 L 364.9,215.6 L 365.0,218.0 L 367.2,216.4 L 375.3,218.7 L 376.2,221.4 L 388.9,221.9 L 401.1,227.3 L 403.5,232.5 L 402.4,236.5 L 392.6,246.2 L 390.9,257.7 L 386.3,267.4 L 367.6,274.4 L 364.2,283.5 L 350.5,297.2 L 343.8,298.3 L 337.7,296.0 L 342.3,303.2 L 335.5,307.5 L 326.8,307.8 L 325.7,313.0 L 319.1,313.1 L 319.5,315.5 L 323.7,316.7 L 318.9,318.9 L 317.9,322.6 L 313.1,323.8 L 312.3,325.6 L 317.7,327.8 L 307.9,336.2 L 310.7,340.1 Z M 339.6,338.1 L 335.0,339.7 L 330.0,338.9 L 337.4,337.1 L 339.6,338.1 Z","Oceania":"M 910.9,318.2 L 905.7,319.0 L 902.1,312.2 L 911.9,312.6 L 910.9,318.2 Z M 843.5,296.0 L 833.0,296.2 L 827.8,298.8 L 819.5,296.7 L 821.7,291.9 L 814.8,277.4 L 817.3,277.8 L 815.0,273.3 L 815.9,268.7 L 824.2,264.5 L 835.7,262.0 L 841.7,254.2 L 844.1,255.8 L 843.1,254.6 L 849.1,249.0 L 853.0,248.0 L 860.1,250.8 L 862.8,244.9 L 868.3,243.9 L 866.2,241.9 L 867.7,241.6 L 875.8,244.3 L 879.1,243.3 L 880.4,244.5 L 876.4,250.8 L 889.5,257.3 L 892.4,254.2 L 895.9,240.5 L 899.8,249.8 L 903.8,250.8 L 906.6,260.3 L 913.5,263.7 L 925.4,277.3 L 924.7,290.6 L 916.7,304.4 L 906.4,308.3 L 902.9,305.5 L 898.9,307.7 L 890.7,305.8 L 887.7,301.3 L 883.7,300.1 L 883.9,297.1 L 880.1,299.2 L 882.8,293.6 L 877.7,298.3 L 873.0,292.9 L 859.8,290.5 L 845.1,293.7 L 843.5,296.0 Z M 0.0,253.4 L 0.2,254.4 L 0.0,254.5 L 0.0,253.4 Z M 944.0,238.4 L 945.5,237.5 L 946.8,238.6 L 944.0,238.4 Z M 942.0,234.4 L 939.5,232.7 L 944.2,235.4 L 942.0,234.4 Z M 935.8,232.1 L 934.8,230.8 L 937.6,232.6 L 935.8,232.1 Z M 891.7,221.2 L 910.1,229.5 L 908.9,232.6 L 918.6,240.3 L 910.9,239.2 L 902.1,233.2 L 896.2,237.3 L 891.8,236.8 L 891.7,221.2 Z M 933.4,230.6 L 929.8,229.1 L 929.6,227.0 L 933.4,230.6 Z M 912.0,228.7 L 918.9,228.0 L 920.9,225.0 L 923.2,225.3 L 922.2,228.1 L 917.3,230.1 L 912.0,228.7 Z M 924.5,226.4 L 920.5,222.3 L 918.5,221.5 L 922.9,222.7 L 925.1,224.5 L 924.5,226.4 Z M 964.0,322.8 L 980.0,311.7 L 984.0,313.8 L 980.8,319.8 L 976.3,320.7 L 970.4,326.4 L 963.0,325.4 L 964.0,322.8 Z M 986.3,314.0 L 985.8,310.3 L 982.8,309.4 L 985.3,304.3 L 979.5,297.5 L 984.2,299.2 L 988.8,304.7 L 995.9,305.1 L 988.9,313.6 L 986.3,314.0 Z M 964.2,267.9 L 956.0,263.8 L 955.6,263.0 L 964.2,267.9 Z M 992.7,258.4 L 993.5,256.5 L 996.4,257.1 L 996.0,258.4 L 992.7,258.4 Z M 996.1,254.7 L 998.4,254.1 L 1000.0,253.4 L 1000.0,254.5 L 996.1,254.7 Z M 964.5,253.0 L 966.2,254.3 L 965.3,254.7 L 964.5,253.0 Z M 964.2,250.7 L 963.3,252.4 L 962.9,249.9 L 964.2,250.7 Z M 949.8,240.0 L 949.2,240.8 L 948.1,239.4 L 949.8,240.0 Z M 947.0,234.9 L 948.7,238.4 L 946.1,234.9 L 947.0,234.9 Z"};
function renderWorldMapSvg(){
  const el=$('#worldMap'); if(!el)return;
  if(!worldCountryConfig.length)worldCountryConfig=defaultWorldCountriesV6();
  const W=1000,H=430;
  const grid=[];
  for(let lon=-180;lon<=180;lon+=30){const p=mapProject(0,lon,W,H);grid.push(`<line x1="${p.x}" y1="0" x2="${p.x}" y2="${H}" stroke="rgba(130,160,205,.10)"/>`)}
  for(let lat=-60;lat<=60;lat+=20){const p=mapProject(lat,0,W,H);grid.push(`<line x1="0" y1="${p.y}" x2="${W}" y2="${p.y}" stroke="rgba(130,160,205,.10)"/>`)}
  const continentOrder=['North America','South America','Europe','Africa','Asia','Oceania'];
  const landSvg=continentOrder.map(c=>`<path d="${CONTINENT_SVG_PATHS_V7[c]||''}" fill="rgba(90,118,150,.30)" stroke="rgba(170,195,220,.30)" stroke-width="1.6" fill-rule="evenodd"/>`).join('');
  const continentLabels=[['Americas',235,215],['Europe',485,82],['Africa',465,190],['Asia',705,145],['Oceania',805,315]].map(([name,x,y])=>`<text x="${x}" y="${y}" fill="rgba(235,242,255,.25)" font-size="18">${name}</text>`).join('');
  const countries=[];
  for(const c of worldCountryConfig){
    if(selectedWorldCountries.size&&!selectedWorldCountries.has(c.code))continue;
    const p=mapProject(c.lat,c.lon,W,H),r=worldMarkerSize(c.code);
    countries.push(`<g class="world-svg-country" data-map-country="${esc(c.code)}" tabindex="0"><title>${esc(currentLanguage==='en'?c.name:c.fa)}</title><circle cx="${p.x}" cy="${p.y}" r="${r}" fill="rgba(61,123,255,.42)" stroke="rgba(170,215,255,.98)" stroke-width="3"/><circle cx="${p.x}" cy="${p.y}" r="7" fill="rgba(255,255,255,.96)"/><text x="${p.x}" y="${p.y+r+18}" text-anchor="middle" fill="rgba(240,247,255,.98)" font-size="13" font-weight="700">${flag(c.code)} ${esc(currentLanguage==='en'?c.name:c.fa)}</text></g>`);
  }
  const ips=(worldRows||[]).filter(r=>(!selectedWorldCountries.size||selectedWorldCountries.has(r.countryCode||r.country)) && Number.isFinite(Number(r.lat))&&Number.isFinite(Number(r.lon))).slice(0,80).map(r=>{const p=mapProject(r.lat,r.lon,W,H);return `<g class="world-svg-ip"><title>${esc(r.ip)} · ${esc(r.city||'')} · ${esc(r.provider||'')}</title><circle cx="${p.x}" cy="${p.y}" r="5" fill="rgba(255,245,160,.98)" stroke="rgba(61,123,255,.95)" stroke-width="2"/></g>`}).join('');
  el.innerHTML=`<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="World continent map"><rect width="${W}" height="${H}" rx="18" fill="#09101d"/>${grid.join('')}${landSvg}${continentLabels}<text x="24" y="28" fill="rgba(235,242,255,.58)" font-size="12">${esc((selectedWorldCountries.size?(currentLanguage==='en'?'Selected countries only':'فقط کشورهای انتخاب‌شده'):(currentLanguage==='en'?'All available countries':'همه کشورها')))}</text><text x="976" y="28" text-anchor="end" fill="rgba(235,242,255,.55)" font-size="11">${esc(`${selectedWorldCountries.size||worldCountryConfig.length}/${worldCountryConfig.length}`)}</text>${countries.join('')}${ips}</svg>`;
  el.querySelectorAll('[data-map-country]').forEach(node=>{const fn=()=>toggleWorldCountryV6(node.dataset.mapCountry);node.addEventListener('click',fn);node.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();fn()}})});
}
function initWorldMapV6(){renderWorldMapSvg()}
function syncWorldMapV6(){renderWorldMapSvg()}
$('#worldClearCountries')?.addEventListener('click',()=>{selectedWorldCountries.clear();storageSet(WORLD_SELECTION_KEY,'[]');renderWorldCountryPickersV6();updateWorldSelectionUI();syncWorldMapV6()});

function flattenWorldResultsV6(data){
  return (data?.countries||[]).flatMap(g=>(g.results||[]).map(r=>({countryGroupCode:g.country,countryName:g.countryName,...r})));
}
function renderWorldSummaryV6(data){
  const s=data?.summary||{}; const n=data?.foundCountries?.length||0; const p=data?.pagination||{};
  $('#worldHint').textContent=currentLanguage==='en'?`${p.returned??0} displayed · ${p.total??s.candidates??0} matching feed entries`:`${p.returned??0} نمایش داده‌شده · از ${p.total??s.candidates??0} نتیجه فیلترشده`;
  $('#worldSummary').innerHTML=`<div><small>${currentLanguage==='en'?'Source':'منبع'}</small><b>Proxifly JSON</b></div><div><small>${currentLanguage==='en'?'Batch':'دسته فعلی'}</small><b>${p.offset??0}–${Math.max(0,(p.offset??0)+(p.returned??0))}</b></div><div><small>${currentLanguage==='en'?'Matching proxies':'پروکسی‌های مطابق'}</small><b>${p.total??s.candidates??0}</b></div><div><small>${currentLanguage==='en'?'Globalping attempted':'تست‌شده با Globalping'}</small><b>${s.pinged??0}</b></div><div><small>${currentLanguage==='en'?'Ping responses':'پاسخ پینگ'}</small><b>${s.successfulPings??0}</b></div>`;
}
let worldSearchInProgressV8=false;
function renderWorldRowsV6(){
  const rows=worldRows||[]; const table=$('#worldRows');if(!table)return;
  const empty=worldSearchInProgressV8
    ?(currentLanguage==='en'?'Loading Proxifly entries and requesting Globalping measurements…':'در حال دریافت پروکسی‌ها و درخواست اندازه‌گیری از Globalping…')
    :(currentLanguage==='en'?'No proxies in this batch. Start a scan or move to the next batch.':'در این دسته پروکسی‌ای وجود ندارد. اسکن را شروع کن یا دسته بعدی را بزن.');
  table.innerHTML=rows.length?rows.map((r,i)=>{
    const cc=r.countryCode||r.countryGroupCode||'';
    const countryMeta=worldCountryConfig.find(c=>c.code===cc);
    const countryLabel=currentLanguage==='en'?(r.countryName||countryMeta?.name||cc||'Unknown'):(countryMeta?.fa||r.countryName||cc||'نامشخص');
    const org=r.datacenterName||r.provider||r.asName||'';
    const asn=r.asn?`AS${String(r.asn).replace(/^AS/i,'')}`:'';
    const where=[r.city,asn].filter(Boolean).join(' · ');
    const pingOk=Boolean(r.ping?.ok&&r.ping?.source==='Globalping');
    const status=pingOk?`<span class="scan-status online">● ${currentLanguage==='en'?'PING OK':'پاسخ پینگ'}</span>`:`<span class="scan-status unknown">● ${currentLanguage==='en'?'NO PING':'بدون پاسخ پینگ'}</span>`;
    const protocol=String(r.protocol||'unknown').toUpperCase();
    const ping=r.ping?.avgMs!=null?fmtMs(r.ping.avgMs):'—';
    const port=Number(r.port||r.observedPorts?.[0]||0);
    const ipForPort=String(r.ip||'').includes(':')?`[${r.ip}]`:r.ip;
    const ipPort=port?`${ipForPort}:${port}`:r.ip;
    return `<tr><td>${status}<small class="table-sub">Globalping</small></td><td><div class="ip-cell"><code>${esc(ipPort)}</code></div></td><td><b>${flag(cc)} ${esc(countryLabel||'—')}</b><small class="table-sub">${esc(org|| (currentLanguage==='en'?'Organization unknown':'سازمان نامشخص'))}</small><small class="table-sub">${esc(where||'')}</small></td><td><span class="scanner-port-chip">${esc(protocol)}${port?` · ${port}`:''}</span></td><td><span class="latency-pill">${esc(ping)}</span>${r.ping?.error?`<small class="table-sub" title="${esc(r.ping.error)}">${currentLanguage==='en'?'No latency':'پینگ نامشخص'}</small>`:''}</td><td><div class="row-actions"><button class="row-btn" data-world-copy="${esc(r.ip)}">⧉ ${currentLanguage==='en'?'Copy IP':'کپی IP'}</button><button class="row-btn" data-world-copy-proxy="${esc(ipPort)}">${currentLanguage==='en'?'Copy proxy':'کپی پروکسی'}</button></div></td></tr>`;
  }).join(''):`<tr><td colspan="6" class="empty">${empty}</td></tr>`;
  table.querySelectorAll('[data-world-copy]').forEach(b=>b.onclick=()=>copyIpV8(b.dataset.worldCopy));
  table.querySelectorAll('[data-world-copy-proxy]').forEach(b=>b.onclick=()=>copyIpV8(b.dataset.worldCopyProxy));
  syncWorldMapV6();
}
async function copyWorldBatchIPsV6(){
  const rows=worldRows||[];if(!rows.length)return toast(currentLanguage==='en'?'No IPs in this batch.':'در این دسته IP وجود ندارد.');
  try{await navigator.clipboard.writeText(rows.map(r=>r.ip).filter(Boolean).join('\n'));toast(currentLanguage==='en'?`${rows.length} IPs copied.`:`${rows.length} IP کپی شد.`)}catch(_){toast(currentLanguage==='en'?'Clipboard unavailable.':'دسترسی به کلیپ‌بورد ممکن نیست.')}
}
async function runWorldDiscoveryV6(nextBatch=false){
  if(worldSearchInProgressV8)return;
  const limit=Math.min(12,Math.max(1,Number($('#worldLimit')?.value||6)));
  const protocol=$('#worldProxyProtocol')?.value||'';
  const family=$('#worldProxyFamily')?.value||'all';
  const probeCountry=$('#globalpingProbeCountry')?.value||'DE';
  const query=$('#worldProvider')?.value.trim()||'';
  if(!nextBatch)currentProxiflyOffset=0;
  else if(lastProxiflyPagination?.hasNext)currentProxiflyOffset=Number(lastProxiflyPagination.nextOffset||currentProxiflyOffset);
  else return toast(currentLanguage==='en'?'There is no next batch.':'دسته بعدی وجود ندارد.');
  const btn=$('#worldDiscoverBtn'),nxt=$('#worldNextBatch');if(btn)btn.disabled=true;if(nxt)nxt.disabled=true;
  worldSearchInProgressV8=true;worldRows=[];worldData=null;
  $('#worldResultsCard')?.classList.remove('hidden');
  const status=$('#worldSearchStatus');if(status){status.classList.remove('hidden');status.textContent=currentLanguage==='en'?`Loading up to ${limit} proxies from Proxifly and measuring each IP with Globalping from ${probeCountry}…`:`در حال دریافت حداکثر ${limit} پروکسی از Proxifly و سنجش هر IP با Globalping از ${probeCountry}…`}
  const sourceStatus=$('#worldSourceStatus');if(sourceStatus)sourceStatus.innerHTML='<span class="source-pill active">● Proxifly JSON</span><span class="source-pill active">● Globalping</span><span class="source-pill">IP metadata · best effort</span>';
  const emptyRow=$('#worldRows');if(emptyRow)emptyRow.innerHTML=`<tr><td colspan="6" class="empty"><div class="loading-line"><span></span><span></span><span></span> ${esc(currentLanguage==='en'?'Proxifly → Globalping':'Proxifly ← دریافت و Globalping ← پینگ')}</div></td></tr>`;
  try{
    const params=new URLSearchParams({protocol,family,q:query,offset:String(currentProxiflyOffset),limit:String(limit),probeCountry});
    if(selectedWorldCountries.size)params.set('countries',[...selectedWorldCountries].join(','));
    const d=await j(`/api/world-discovery?${params.toString()}`);
    worldData=d;worldRows=flattenWorldResultsV6(d);lastProxiflyPagination=d.pagination||null;currentProxiflyOffset=Number(d.pagination?.offset||0);
    renderWorldSummaryV6(d);renderWorldRowsV6();
    if(status){status.classList.remove('hidden');status.textContent=worldRows.length?(currentLanguage==='en'?`Batch complete: ${worldRows.length} proxies listed; Globalping measurement attempted for each. Country and organization data may be approximate; ping does not validate proxy relay/connectivity.`:`دسته تکمیل شد: ${worldRows.length} پروکسی نمایش داده شد و برای هرکدام Globalping درخواست پینگ شد. کشور و سازمان ممکن است تقریبی باشد؛ پینگ به‌تنهایی سلامت اتصال پروکسی را تأیید نمی‌کند.`):(currentLanguage==='en'?'No entries matched these filters.':'با این فیلترها نتیجه‌ای پیدا نشد.')}
    if(nxt)nxt.disabled=!lastProxiflyPagination?.hasNext;
    if(worldRows.length)toast(currentLanguage==='en'?`Batch ${worldRows.length}: Proxifly + Globalping.`:`دسته ${worldRows.length}تایی با Proxifly و Globalping آماده شد.`);
  }catch(e){
    worldSearchInProgressV8=false;if(emptyRow)emptyRow.innerHTML=`<tr><td colspan="6" class="empty">${esc(e.message)}</td></tr>`;
    if(status){status.classList.remove('hidden');status.textContent=currentLanguage==='en'?`Scan failed: ${e.message}`:`اسکن ناموفق بود: ${e.message}`}
    toast(e.message);
  }finally{worldSearchInProgressV8=false;if(btn)btn.disabled=false;if(nxt)nxt.disabled=!lastProxiflyPagination?.hasNext;}
}
$('#worldDiscoverBtn')?.addEventListener('click',()=>runWorldDiscoveryV6(false));
$('#worldNextBatch')?.addEventListener('click',()=>runWorldDiscoveryV6(true));
$('#worldCopyIPs')?.addEventListener('click',copyWorldBatchIPsV6);
$('#worldCopyIPsResults')?.addEventListener('click',copyWorldBatchIPsV6);
$('#worldExportJson')?.addEventListener('click',()=>{if(!worldData)return toast(currentLanguage==='en'?'Run discovery first.':'اول جستجو را اجرا کن.');downloadBlob(JSON.stringify(worldData,null,2),'mahdiar-proxifly-globalping.json','application/json')});
$('#worldExportCsv')?.addEventListener('click',()=>{if(!worldData)return toast(currentLanguage==='en'?'Run discovery first.':'اول جستجوی جهانی را اجرا کن.');const head=['ip','port','protocol','provider','asn','country','countryName','city','datacenterName','pingMs','pingSource','pingOk','pingLoss','sources'];const flat=flattenWorldResultsV6(worldData);const body=[head,...flat.map(r=>head.map(k=>{const v=k==='pingMs'?(r.ping?.avgMs??''):k==='pingSource'?(r.ping?.source||''):k==='pingOk'?(r.ping?.ok??false):k==='pingLoss'?(r.ping?.loss??''):(Array.isArray(r[k])?r[k].join('|'):r[k]??'');return `"${String(v).replace(/"/g,'""')}"`;}))].map(x=>x.join(',')).join('\n');downloadBlob('\ufeff'+body,'mahdiar-proxifly-globalping.csv','text/csv;charset=utf-8')});

function speedGaugeHtml(label,value){const v=Math.max(0,Number(value)||0);const pct=v<=0?0:Math.min(100,18+82*(Math.log10(v+1)/Math.log10(1001)));const band=v<10?'Slow':v<50?'Basic':v<100?'Good':v<500?'Fast':v<1000?'Very Fast':'Gigabit+';return `<div class="speed-gauge" style="--pct:${pct}%"><div class="gauge-core"><div class="gauge-value">${v.toFixed(1)}</div><div class="gauge-label">Mbps · ${esc(label)}</div><div class="muted">${band} · live server measurement</div></div></div>`}

async function measureGlobalpingLatency(){
  try {
    const response=await fetch('/api/speed/ping?ts='+Date.now(),{cache:'no-store',headers:{accept:'application/json'}});
    const data=await response.json();
    if(!response.ok||!data.ok) return {latency:null,jitter:null};
    return {latency:Number.isFinite(Number(data.avgMs))?Number(data.avgMs):null,jitter:Number.isFinite(Number(data.jitterMs))?Number(data.jitterMs):null,source:'Globalping'};
  } catch (_) { return {latency:null,jitter:null,source:'Globalping'}; }
}
function makeUploadBlob(bytes){
  const size=Math.max(256*1024,Math.min(Number(bytes)||2*1024*1024,4*1024*1024));
  const u=new Uint8Array(size);
  if(window.crypto?.getRandomValues){
    for(let i=0;i<size;i+=65536) window.crypto.getRandomValues(u.subarray(i,Math.min(i+65536,size)));
  }
  return new Blob([u],{type:'application/octet-stream'});
}

async function measureServerSpeed(){
  const downSession=await j('/api/speed/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({bytes:8*1024*1024,direction:'download'})});
  const d0=performance.now(); const dr=await fetch(downSession.downloadUrl+'&cb='+Date.now(),{cache:'no-store'}); if(!dr.ok)throw new Error(`Server download HTTP ${dr.status}`); const db=await dr.arrayBuffer(); const dsec=Math.max((performance.now()-d0)/1000,.001);
  const uploadSession=await j('/api/speed/session',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({bytes:2*1024*1024,direction:'upload'})});
  const ub=makeUploadBlob(2*1024*1024),u0=performance.now(); const ur=await fetch(uploadSession.uploadUrl,{method:'POST',body:ub,cache:'no-store',headers:{'content-type':'application/octet-stream'}}); if(!ur.ok)throw new Error(`Server upload HTTP ${ur.status}`); const usec=Math.max((performance.now()-u0)/1000,.001);
  const latency=await measureGlobalpingLatency();
  return {provider:location.origin,download:{mbps:db.byteLength*8/dsec/1e6},upload:{mbps:ub.size*8/usec/1e6},latency:latency.latency,jitter:latency.jitter,pingSource:'Globalping',downloadBytes:db.byteLength,uploadBytes:ub.size};
}
const SPEED_PHASE_MS_V8 = 15000;
const SPEED_DOWNLOAD_CAP_V8 = 256 * 1024 * 1024;
const SPEED_UPLOAD_CAP_V8 = 128 * 1024 * 1024;
const sleepV8 = ms => new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));
async function newSpeedSessionV8(bytes, direction) {
  return j('/api/speed/session', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ bytes, direction }) });
}
async function measureServerDownload15sV8(onProgress) {
  const began = performance.now(), deadline = began + SPEED_PHASE_MS_V8;
  let total = 0, transferEnd = began, requestCount = 0;
  while (performance.now() < deadline && total < SPEED_DOWNLOAD_CAP_V8) {
    const session = await newSpeedSessionV8(16000000, 'download');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), Math.max(1, deadline - performance.now()));
    let readThisRequest = 0;
    try {
      const response = await fetch(session.downloadUrl + `&cb=${Date.now()}_${requestCount++}`, { cache: 'no-store', headers: { accept: 'application/octet-stream' }, signal: controller.signal });
      if (!response.ok) throw new Error(`Download HTTP ${response.status}`);
      if (!response.body?.getReader) {
        const data = await response.arrayBuffer();
        readThisRequest = Math.min(data.byteLength, SPEED_DOWNLOAD_CAP_V8 - total);
        total += readThisRequest;
      } else {
        const reader = response.body.getReader();
        try {
          while (performance.now() < deadline && total < SPEED_DOWNLOAD_CAP_V8) {
            const part = await reader.read();
            if (part.done) break;
            const count = Math.min(part.value?.byteLength || 0, SPEED_DOWNLOAD_CAP_V8 - total);
            total += count; readThisRequest += count; transferEnd = performance.now();
            if (total >= SPEED_DOWNLOAD_CAP_V8) { await reader.cancel().catch(() => {}); break; }
            onProgress?.(Math.max(0, deadline - performance.now()));
          }
          if (performance.now() >= deadline) await reader.cancel().catch(() => {});
        } finally { try { reader.releaseLock(); } catch (_) {} }
      }
      if (readThisRequest > 0) transferEnd = performance.now();
    } catch (error) {
      if (!total && performance.now() < deadline) throw error;
      // Retain bytes already transferred if a later chunk request fails.
      if (total > 0 && performance.now() < deadline && !controller.signal.aborted) break;
    } finally { clearTimeout(timer); }
    if (!readThisRequest && performance.now() < deadline && !total) throw new Error('The server returned no download data.');
  }
  if (total >= SPEED_DOWNLOAD_CAP_V8 && performance.now() < deadline) await sleepV8(deadline - performance.now());
  const activeSeconds = Math.max((transferEnd - began) / 1000, 0.001);
  if (!total) throw new Error('No download data was received before the 15-second limit.');
  return { bytes: total, seconds: activeSeconds, mbps: total * 8 / activeSeconds / 1e6, capped: total >= SPEED_DOWNLOAD_CAP_V8 };
}
async function measureServerUpload15sV8(onProgress) {
  const began = performance.now(), deadline = began + SPEED_PHASE_MS_V8;
  const chunkBytes = 7 * 1024 * 1024;
  let total = 0, transferEnd = began, requestCount = 0;
  while (performance.now() < deadline && total < SPEED_UPLOAD_CAP_V8) {
    const session = await newSpeedSessionV8(chunkBytes, 'upload');
    const payload = makeUploadBlob(chunkBytes);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), Math.max(1, deadline - performance.now()));
    try {
      const response = await fetch(session.uploadUrl + `?cb=${Date.now()}_${requestCount++}`, {
        method: 'POST', body: payload, cache: 'no-store',
        headers: { 'content-type': 'application/octet-stream' }, signal: controller.signal
      });
      if (!response.ok) throw new Error(`Upload HTTP ${response.status}`);
      const result = await response.json();
      const accepted = Math.min(Number(result?.bytes) || 0, payload.size, SPEED_UPLOAD_CAP_V8 - total);
      if (accepted <= 0) throw new Error('The server did not confirm any uploaded bytes.');
      total += accepted; transferEnd = performance.now();
      onProgress?.(Math.max(0, deadline - performance.now()));
    } catch (error) {
      if (!total && performance.now() < deadline) throw error;
      // Do not discard a valid partial upload measurement after a later request fails.
      if (total > 0 && performance.now() < deadline && !controller.signal.aborted) break;
    } finally { clearTimeout(timer); }
  }
  if (total >= SPEED_UPLOAD_CAP_V8 && performance.now() < deadline) await sleepV8(deadline - performance.now());
  const activeSeconds = Math.max((transferEnd - began) / 1000, 0.001);
  if (!total) throw new Error('The server did not confirm uploaded bytes before the 15-second limit.');
  return { bytes: total, seconds: activeSeconds, mbps: total * 8 / activeSeconds / 1e6, capped: total >= SPEED_UPLOAD_CAP_V8 };
}
async function speedToolV6(){
  openModal(t('speed'),`<div class="result speed-test-panel"><div id="speedGauges" class="speed-stats"><div>${speedGaugeHtml(t('download'),0)}</div><div>${speedGaugeHtml(t('upload'),0)}</div></div><div class="hero-actions"><button id="speedGo" class="primary">${esc(t('startSpeed'))}</button></div><div id="speedOut" class="muted">${esc(currentLanguage==='en'?'15 seconds are reserved for download and then 15 seconds for upload.':'۱۵ ثانیه برای دانلود و پس از آن ۱۵ ثانیه برای آپلود اختصاص دارد.')}</div></div>`);
  const btn=$('#speedGo'),out=$('#speedOut'); if(!btn||!out)return;
  btn.onclick=async()=>{
    btn.disabled=true;
    let ping=null,jitter=null,down=null,up=null;
    const errors=[];
    try{
      out.textContent=currentLanguage==='en'?'Measuring ping with Globalping…':'در حال اندازه‌گیری پینگ با Globalping…';
      const r=await fetch(`/api/speed/ping?ts=${Date.now()}`,{cache:'no-store',headers:{accept:'application/json'}});
      const data=await r.json();
      if(!r.ok || !data.ok || !Number.isFinite(Number(data.avgMs))) throw new Error(data.error || `Globalping HTTP ${r.status}`);
      ping=Number(data.avgMs);
      jitter=Number.isFinite(Number(data.jitterMs))?Number(data.jitterMs):null;
    }catch(e){errors.push(`${currentLanguage==='en'?'Ping':'پینگ'}: ${e.message}`)}
    const downloadPhaseStart=performance.now();
    try{
      out.textContent=currentLanguage==='en'?'Downloading (15-second phase)…':'در حال دانلود؛ بازه تست ۱۵ ثانیه‌ای…';
      down=await measureServerDownload15sV8(ms=>{if(out)out.textContent=`${currentLanguage==='en'?'Downloading':'در حال دانلود'} · ${Math.max(0,ms/1000).toFixed(1)}s`;});
    }catch(e){errors.push(`${currentLanguage==='en'?'Download':'دانلود'}: ${e.message}`)}
    await sleepV8(Math.max(0,SPEED_PHASE_MS_V8-(performance.now()-downloadPhaseStart)));
    const uploadPhaseStart=performance.now();
    try{
      out.textContent=currentLanguage==='en'?'Uploading (15-second phase)…':'در حال آپلود؛ بازه تست ۱۵ ثانیه‌ای…';
      up=await measureServerUpload15sV8(ms=>{if(out)out.textContent=`${currentLanguage==='en'?'Uploading':'در حال آپلود'} · ${Math.max(0,ms/1000).toFixed(1)}s`;});
    }catch(e){errors.push(`${currentLanguage==='en'?'Upload':'آپلود'}: ${e.message}`)}
    await sleepV8(Math.max(0,SPEED_PHASE_MS_V8-(performance.now()-uploadPhaseStart)));
    const gauges=$('#speedGauges');
    if(gauges)gauges.innerHTML=`<div>${speedGaugeHtml(t('download'),down?.mbps||0)}</div><div>${speedGaugeHtml(t('upload'),up?.mbps||0)}</div>`;
    const stat=(label,value)=>`<div class="speed-stat"><b>${esc(label)}</b><div>${value}</div></div>`;
    const fmtRate=v=>v?`${v.mbps.toFixed(2)} Mbps`:'—';
    const fmtBytes=v=>v?`${(v.bytes/1024/1024).toFixed(1)} MB`:'—';
    let result=`<div class="speed-stats">${stat(t('ping'),ping==null?'—':fmtMs(ping))}${stat(t('jitter'),jitter==null?'—':fmtMs(jitter))}${stat(t('download'),fmtRate(down))}${stat(t('upload'),fmtRate(up))}${stat(currentLanguage==='en'?'Downloaded':'حجم دانلود',fmtBytes(down))}${stat(currentLanguage==='en'?'Uploaded':'حجم آپلود',fmtBytes(up))}</div>`;
    if(errors.length)result+=`<div class="network-warning">${errors.map(esc).join('<br>')}</div>`;
    if(down?.capped||up?.capped)result+=`<div class="muted">${esc(currentLanguage==='en'?'A safety cap limited the amount of test data on this run.':'برای جلوگیری از مصرف بیش از حد اینترنت، حجم تست در این اجرا سقف داشت.')}</div>`;
    out.innerHTML=result;
    btn.disabled=false;
  };
}

let btnRef=null;
window.addEventListener('error',e=>{try{toast(`UI error: ${e.message||'unknown error'}`)}catch(_){} });
window.addEventListener('unhandledrejection',e=>{try{toast(`Request error: ${e.reason?.message||e.reason||'unknown error'}`)}catch(_){} });

function globalToolV6(){
  const selected=[...selectedWorldCountries];
  openModal(currentLanguage==='en'?'Multi-point Ping':'پینگ چندنقطه‌ای',`<div class="notice">${currentLanguage==='en'?'Only currently selected countries are searched. Countries with zero results are not displayed.':'فقط کشورهای انتخاب‌شده جستجو می‌شوند؛ کشوری که IP نداشته باشد در خروجی نمایش داده نمی‌شود.'}</div><div id="globalOut" class="result">${esc(t('searching'))}</div>`);
  if(!selected.length){$('#globalOut').innerHTML=`<div class="notice">${esc(t('noneSelected'))}</div>`;return;}
  j('/api/multi-ping?countries='+encodeURIComponent(selected.join(','))+'&ports=80,443&limit=3').then(d=>{
    const out=$('#globalOut');if(!out)return; const groups=d.countries||[]; const rows=groups.flatMap(g=>(g.results||[]).map(r=>({g,r})));
    $('#globalOut').innerHTML=rows.length?rows.map(({g,r})=>{const services=[...(r.confirmedPorts||[]),...(r.observedPorts||[])].filter((x,i,a)=>a.indexOf(x)===i).map(p=>`${p} ${portName(p)}`).join(' · ')||'—';return `<div class="result"><div class="kv"><span>${flag(g.country)} ${esc(currentLanguage==='en'?g.countryName:g.countryName)} · <code>${esc(r.ip)}</code></span><span>${r.ping?.ok?`<span class="ok-dot">● ${fmtMs(r.ping.avgMs)}</span>`:'<span class="bad-dot">● no ping</span>'}</span></div>${k(['Provider',r.provider||'—'])}${k(['ASN',r.asn?`AS${r.asn}`:'—'])}${k([currentLanguage==='en'?'Services / ports':'سرویس / پورت',services])}</div>`}).join(''):`<div class="notice">${currentLanguage==='en'?'No results were found in the selected countries.':'در کشورهای انتخاب‌شده نتیجه‌ای پیدا نشد.'}</div>`;
  }).catch(e=>{const out=$('#globalOut');if(out)out.innerHTML=`<div class="code">${esc(e.message)}</div>`});
}


const TOOL_COUNTRIES_V7=[
 ['TR','Turkey','ترکیه'],['FR','France','فرانسه'],['DE','Germany','آلمان'],['US','United States','آمریکا'],['NL','Netherlands','هلند'],['GB','United Kingdom','انگلستان'],['AE','United Arab Emirates','امارات'],['CH','Switzerland','سوئیس'],['CA','Canada','کانادا'],['IR','Iran','ایران'],['FI','Finland','فنلاند'],['ES','Spain','اسپانیا']
];
function countryOptionsV7(includeAll=false){return `${includeAll?'<option value="">همه کشورها</option>':''}`+TOOL_COUNTRIES_V7.map(c=>`<option value="${c[0]}">${flag(c[0])} ${esc(currentLanguage==='en'?c[1]:c[2])}</option>`).join('')}
function multiCountryCheckboxesV7(selected){return TOOL_COUNTRIES_V7.map(c=>{const on=selected.has(c[0]);return `<label class="check"><input type="checkbox" data-mpc="${c[0]}" ${on?'checked':''}><span>${flag(c[0])} ${esc(currentLanguage==='en'?c[1]:c[2])}</span></label>`}).join('')}
function readMultiCountriesV7(){const xs=$$('[data-mpc]:checked').map(x=>x.dataset.mpc);return xs.length?xs: [...selectedWorldCountries];}
function proxyRowsHtmlV7(rows){return rows.map(r=>`<div class="result"><div class="kv"><span><code>${esc(String(r.ip).includes(':')?'['+r.ip+']':r.ip)}:${r.port}</code></span><span>${fmtMs(r.latencyMs)}</span></div>${k([currentLanguage==='en'?'Protocol':'پروتکل',r.protocol||'—'])}${k([currentLanguage==='en'?'Country':'کشور',r.country?`${flag(r.country)} ${esc(worldCountryConfig.find(c=>c.code===r.country)?.name||r.country)}`:'—'])}${r.anonymity?k([currentLanguage==='en'?'Anonymity':'ناشناس‌سازی',r.anonymity]):''}${r.provider?k([currentLanguage==='en'?'Provider':'شرکت',r.provider]):''}${r.city?k([currentLanguage==='en'?'City':'شهر',r.city]):''}${k([currentLanguage==='en'?'HTTPS':'HTTPS',r.https?'Yes':'No'])}</div>`).join('')}
async function ipDatabaseToolV8(){
  const title=currentLanguage==='en'?'IP Databases':'دیتابیس‌های IP';
  openModal(title,`<div id="ipDbOut" class="result">${esc(currentLanguage==='en'?'Loading databases and stored IPs…':'در حال دریافت دیتابیس‌ها و IPهای ذخیره‌شده…')}</div>`);
  const out=$('#ipDbOut');setLoading(out);
  try{
    const d=await j('/api/ip-db/summary');
    const providerCards=(d.providers||[]).map(p=>`<button class="tool-card db-provider-card" data-ipdb-provider="${esc(p.provider)}"><div class="tool-icon">🏢</div><b>${esc(p.provider)}</b><p>${Number(p.ipCount||0).toLocaleString()} IP · ${(p.countries||[]).length} ${currentLanguage==='en'?'countries':'کشور'}${p.avgMs!=null?` · ${fmtMs(p.avgMs)}`:''}</p></button>`).join('');
    const localCards=(d.localDatabases||[]).map(x=>`<div class="db-source-card ${x.ready?'ready':'unready'}"><div class="db-source-top"><b>${esc(x.name)}</b><span>${x.ready?(currentLanguage==='en'?'READY':'فعال'):(currentLanguage==='en'?'OFFLINE':'غیرفعال')}</span></div><small>${esc(x.file||'')}</small><strong>${Number(x.ipCount||0).toLocaleString()} ${currentLanguage==='en'?'saved IPs':'IP ذخیره‌شده'}</strong></div>`).join('');
    const sourceCards=(d.sources||[]).map(x=>`<div class="db-source-card ${x.ready?'ready':'unready'}"><div class="db-source-top"><b>${esc(x.name)}</b><span>${x.ready?(currentLanguage==='en'?'ACTIVE':'فعال'):(currentLanguage==='en'?'NEEDS KEY':'نیازمند کلید')}</span></div><small>${esc(x.category||'')}</small><strong>${Number(x.storedIPs||0).toLocaleString()} ${currentLanguage==='en'?'IPs attributed':'IP منتسب'}</strong>${x.requiredForDiscovery?`<em>${currentLanguage==='en'?'Required during discovery':'در جستجو الزامی'}</em>`:''}</div>`).join('');
    const manualCount=Number(d.totals?.manualIpCount||0);
    out.innerHTML=`
      <div class="intel-stat-grid"><div class="intel-stat-card"><small>${currentLanguage==='en'?'Datacenter IPs':'IP دیتاسنتر'}</small><b>${Number(d.totals?.datacenterIpCount||d.totals?.ipCount||0).toLocaleString()}</b></div><div class="intel-stat-card"><small>${currentLanguage==='en'?'All unique saved IPs':'تمام IPهای ذخیره‌شده یکتا'}</small><b>${Number(d.totals?.allStoredIpCount||0).toLocaleString()}</b></div><div class="intel-stat-card"><small>${currentLanguage==='en'?'Datacenters':'دیتاسنتر'}</small><b>${Number(d.totals?.datacenterCount||0).toLocaleString()}</b></div><div class="intel-stat-card"><small>${currentLanguage==='en'?'Active sources':'منابع فعال'}</small><b>${Number(d.totals?.activeSourceCount||0)}/${Number(d.totals?.totalSourceCount||0)}</b></div></div>
      <div class="subsection-head"><b>${currentLanguage==='en'?'Local databases':'دیتابیس‌های محلی سرور'}</b><span>${manualCount.toLocaleString()} ${currentLanguage==='en'?'authorized scan IPs':'IP اسکن مجاز'}</span></div><div class="db-source-grid">${localCards}</div>
      <div class="subsection-head"><b>${currentLanguage==='en'?'Live data sources':'منابع زنده داده'}</b><span>${currentLanguage==='en'?'Key status; secrets are never shown':'وضعیت کلید؛ خود کلید نمایش داده نمی‌شود'}</span></div><div class="db-source-grid">${sourceCards}</div>
      <div class="subsection-head"><b>${currentLanguage==='en'?'Datacenter providers':'ارائه‌دهندگان دیتاسنتر'}</b><span>${Number(d.totals?.providersWithIPs||0)} ${currentLanguage==='en'?'with saved IPs':'دارای IP ذخیره‌شده'}</span></div><div id="ipDbProviders" class="tool-grid">${providerCards||`<div class="notice">${esc(currentLanguage==='en'?'No Proxifly scan results have been stored yet. Start a scan in the Scanner view.':'هنوز نتیجه‌ای از Proxifly ذخیره نشده؛ از بخش اسکنر یک اسکن را شروع کن.')}</div>`}</div>
      <div class="config-actions"><button id="ipDbShowAll" class="primary">${currentLanguage==='en'?'Show all saved IPs':'نمایش تمام IPهای ذخیره‌شده'}</button><button id="ipDbManual" class="secondary">${currentLanguage==='en'?'Authorized scan results':'نتایج اسکن مجاز'}</button></div><div id="ipDbDetail" class="result"></div>`;
    $('#ipDbProviders')?.querySelectorAll('[data-ipdb-provider]').forEach(b=>b.onclick=()=>loadIpDbProviderV8(b.dataset.ipdbProvider));
    $('#ipDbShowAll')?.addEventListener('click',async()=>{const det=$('#ipDbDetail');setLoading(det);try{const all=await j('/api/ip-db/all?limit=1000');det.innerHTML=`<div class="subsection-head"><b>${currentLanguage==='en'?'All unique saved IPs':'تمام IPهای یکتای ذخیره‌شده'}</b><span>${Number(all.totalInDatabase||0).toLocaleString()} ${currentLanguage==='en'?'records':'رکورد'}</span></div>${ipDbRowsHtmlV8(all.results||[],false,true)}`;wireIpDbTableActions(det)}catch(e){det.innerHTML=`<div class="code">${esc(e.message)}</div>`}});
    $('#ipDbManual')?.addEventListener('click',async()=>{const det=$('#ipDbDetail');setLoading(det);try{const d2=await j('/api/ip-db/manual?limit=500');det.innerHTML=ipDbRowsHtmlV8(d2.results||[],true,true);wireIpDbTableActions(det)}catch(e){det.innerHTML=`<div class="code">${esc(e.message)}</div>`}});
  }catch(e){out.innerHTML=`<div class="code">${esc(e.message)}</div>`}
}
async function loadIpDbProviderV8(provider){
  const det=$('#ipDbDetail');if(!det)return;setLoading(det);
  try{
    const d=await j('/api/ip-db/provider?provider='+encodeURIComponent(provider)+'&limit=300');
    det.innerHTML=`<div class="config-title"><div><b>🏢 ${esc(provider)}</b><small>${Number(d.totalInDatabase||0).toLocaleString()} ${currentLanguage==='en'?'IPs in database':'IP در دیتابیس'}</small></div><button id="ipDbPingAll" class="primary">Globalping · ${currentLanguage==='en'?'Ping IPs':'پینگ IPها'}</button></div>${ipDbRowsHtmlV8(d.results||[],false,true)}`;
    wireIpDbTableActions(det);
    $('#ipDbPingAll')?.addEventListener('click',async()=>{const btn=$('#ipDbPingAll');if(btn)btn.disabled=true;try{const visible=d.results||[];for(let k=0;k<visible.length;k+=20)await pingIpDbRowsV8(visible.slice(k,k+20),false);toast(currentLanguage==='en'?'Ping requests completed.':'درخواست‌های پینگ تمام شد.')}finally{if(btn)btn.disabled=false}});
  }catch(e){det.innerHTML=`<div class="code">${esc(e.message)}</div>`}
}
function wireIpDbTableActions(root){
  root?.querySelectorAll('[data-db-copy]').forEach(b=>b.onclick=()=>copyIpV8(b.dataset.dbCopy));
  root?.querySelectorAll('[data-db-details]').forEach(b=>b.onclick=()=>lookupSingleIp(b.dataset.dbDetails));
}
function ipDbRowsHtmlV8(rows,manual=false,showDetails=true){
  const headers=manual?['#','IP',currentLanguage==='en'?'Target':'هدف',currentLanguage==='en'?'Ping':'پینگ','ASN',currentLanguage==='en'?'Ports':'پورت‌ها',currentLanguage==='en'?'Database':'دیتابیس',currentLanguage==='en'?'Action':'عملیات']:['#','IP',currentLanguage==='en'?'Country / database':'کشور / دیتابیس',currentLanguage==='en'?'Ping':'پینگ','ASN',currentLanguage==='en'?'Ports':'پورت‌ها',currentLanguage==='en'?'Action':'عملیات'];
  const body=rows.length?rows.map((r,i)=>{
    const ports=[...(r.confirmedPorts||[]),...(r.observedPorts||[]),...(r.openPorts||[]).map(x=>x.port)].filter(Boolean).map(Number).filter(Boolean).filter((x,j,a)=>a.indexOf(x)===j).sort((a,b)=>a-b);
    const country=r.country||r.countryCode||'—';
    const db=manual?(r.database||r.databases?.join(' + ')||r.source||'Authorized Scan Database'):(r.database||r.databases?.join(' + ')||(r.sources||[]).join(' · ')||r.source||'Datacenter IP Database');
    const status=r.ping?.ok?`<span class="device-online">● ${currentLanguage==='en'?'ONLINE':'آنلاین'}</span>`:`<span class="mini-badge">${currentLanguage==='en'?'UNKNOWN':'نامشخص'}</span>`;
    const action=showDetails?`<div class="row-actions"><button class="row-btn" data-db-details="${esc(r.ip)}">${currentLanguage==='en'?'Details':'جزئیات'}</button><button class="row-btn icon-mini" data-db-copy="${esc(r.ip)}" aria-label="Copy IP">⧉</button></div>`:'';
    if(manual)return `<tr><td>${i+1}</td><td><code>${esc(r.ip)}</code></td><td>${esc(r.target||'—')}</td><td>${fmtMs(r.ping?.latencyMs??r.ping?.avgMs)}</td><td>${r.asn?`AS${esc(r.asn)}`:'—'}</td><td>${esc(ports.join(', ')||'—')}</td><td><small>${esc(db)}</small></td><td>${action}</td></tr>`;
    return `<tr><td>${i+1}</td><td><div class="ip-cell"><code>${esc(r.ip)}</code></div></td><td><b>${esc(country)}</b><small class="table-sub">${esc(db)}</small></td><td>${fmtMs(r.ping?.avgMs??r.ping?.latencyMs??r.latencyMs)}</td><td>${r.asn?`AS${esc(r.asn)}`:'—'}</td><td><div class="port-list">${ports.length?ports.map(p=>`<span class="scanner-port-chip">${p}</span>`).join(''):'—'}</div></td><td>${action}</td></tr>`;
  }).join(''):`<tr><td colspan="${headers.length}" class="empty">${esc(currentLanguage==='en'?'No persisted IP records yet. Run discovery/authorized scanning first.':'هنوز IP ذخیره‌شده‌ای وجود ندارد. ابتدا Discovery یا اسکن مجاز را اجرا کن.')}</td></tr>`;
  const html=`<div class="table-wrap compact-ip-table"><table><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${body}</tbody></table></div>`;
  // Event handlers attach after the table is inserted by callers, using event delegation on the document.
  return html;
}
function copyIpV8(ip){const value=String(ip||'');if(!value)return;const copied=navigator.clipboard?.writeText(value);if(copied&&typeof copied.then==='function')copied.then(()=>toast(currentLanguage==='en'?'IP copied.':'IP کپی شد.')).catch(()=>fallbackCopyIpV8(value));else fallbackCopyIpV8(value)}
function fallbackCopyIpV8(value){const area=document.createElement('textarea');area.value=value;area.style.position='fixed';area.style.opacity='0';document.body.appendChild(area);area.select();try{document.execCommand('copy');toast(currentLanguage==='en'?'IP copied.':'IP کپی شد.')}catch(_){toast(currentLanguage==='en'?'Copy failed.':'کپی نشد.')}finally{area.remove()}}
async function pingIpDbRowsV8(rows,notify=true){const ips=(rows||[]).map(r=>r.ip).filter(isValidIP).slice(0,20);if(!ips.length)return;try{const d=await j('/api/ip-db/globalping',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({ips,countries:[...selectedWorldCountries]})});if(notify)toast(`${d.results?.filter(r=>r.ping?.ok).length||0} IP با Globalping پاسخ داد.`)}catch(e){if(notify)toast(e.message)}}
async function proxyToolV7(mode){
  const title=mode==='best'?t('proxyBest'):mode==='v4'?t('proxyV4'):t('proxyV6');
  openModal(title,`<div class="form-grid"><label class="modal-label">${currentLanguage==='en'?'Country':'کشور'}<select id="pxCountry" class="field">${countryOptionsV7(true)}</select></label><label class="modal-label">${currentLanguage==='en'?'Protocol':'پروتکل'}<select id="pxProtocol" class="field"><option value="">All</option><option>http</option><option>https</option><option>socks4</option><option>socks5</option></select></label><button id="pxRun" class="primary">${esc(t('search'))}</button></div><div class="config-actions"><button id="pxJson" class="secondary">JSON</button></div><div id="pxOut" class="result">${esc(t('ready'))}</div>`);
  const run=async()=>{const out=$('#pxOut');setLoading(out);try{const country=$('#pxCountry').value,protocol=$('#pxProtocol').value;const d=await j(`/api/proxy/list?mode=${encodeURIComponent(mode)}&country=${encodeURIComponent(country)}&protocol=${encodeURIComponent(protocol)}&limit=40`);out.innerHTML=`${k([currentLanguage==='en'?'Source':'منبع',d.source])}${k([currentLanguage==='en'?'Found':'پیدا شده',d.count])}${proxyRowsHtmlV7(d.rows||[])||`<div class="notice">${esc(t('noResults'))}</div>`}`}catch(e){out.innerHTML=`<div class="code">${esc(e.message)}</div>`}};
  $('#pxRun').onclick=run;
  $('#pxJson').onclick=async()=>{try{const q=new URLSearchParams({mode,country:$('#pxCountry').value,protocol:$('#pxProtocol').value,limit:'200'});const d=await j('/api/proxy/list?'+q.toString());downloadBlob(JSON.stringify(d,null,2),'mahdiar-proxies.json','application/json')}catch(e){toast(e.message)}};
}
function bestProxyOpen(){return proxyToolV7('best')}
function proxyV4Open(){return proxyToolV7('v4')}
function proxyV6Open(){return proxyToolV7('v6')}
function multiPingToolV7(){
  const defaults=new Set(selectedWorldCountries.size?[...selectedWorldCountries]:['DE','FR','NL']);
  openModal(t('global'),`<label class="modal-label">${currentLanguage==='en'?'Target IP / hostname':'IP یا دامنه هدف'}<input id="gpTarget" class="field" placeholder="1.1.1.1 یا example.com"></label><div class="subsection-head"><b>${currentLanguage==='en'?'Probe countries':'کشورهای نود'}</b></div><div class="form-grid">${multiCountryCheckboxesV7(defaults)}</div><div class="config-actions"><button id="gpRun" class="primary">${esc(t('search'))}</button></div><div id="gpOut" class="result">${esc(t('ready'))}</div>`);
  $('#gpRun').onclick=async()=>{const target=$('#gpTarget').value.trim();if(!target)return toast(currentLanguage==='en'?'Enter a target.':'هدف را وارد کن.');const out=$('#gpOut');setLoading(out);try{const countries=readMultiCountriesV7();const d=await j(`/api/multi-ping?target=${encodeURIComponent(target)}&countries=${encodeURIComponent(countries.join(','))}&packets=3`);out.innerHTML=(d.results||[]).map(r=>`<div class="result"><div class="kv"><span>${flag(r.country)} ${esc(currentLanguage==='en'?r.countryName:r.countryName)} · ${esc(r.city||'—')}</span><span>${r.avgMs!=null?fmtMs(r.avgMs):'—'}</span></div>${k(['ASN',r.asn?`AS${r.asn}`:'—'])}${k([currentLanguage==='en'?'Network':'شبکه',r.network||'—'])}${k([currentLanguage==='en'?'Min / Avg / Max':'کمینه / میانگین / بیشینه',`${fmtMs(r.minMs)} / ${fmtMs(r.avgMs)} / ${fmtMs(r.maxMs)}`])}${k([currentLanguage==='en'?'Loss':'از دست رفتن',r.loss!=null?`${r.loss}%`:'—'])}</div>`).join('')||`<div class="notice">${esc(t('noResults'))}</div>`}catch(e){out.innerHTML=`<div class="code">${esc(e.message)}</div>`}};
}
function guideToolV7(){
  inputTool(t('guide'),[],async()=>{
    const d=await j('/api/guide');
    const en=currentLanguage==='en';
    const sections=en?[
      ['1. Proxy scanner','The scanner downloads the public JSON inventory from Proxifly only. Each displayed proxy IP is measured via Globalping only; no Shodan, Netlas, Tavily, HProxy or ProxyScrape search is used. Use the Next batch button to scan additional entries.'],
      ['2. Country and organization','Country/city may come from Proxifly or best-effort IP metadata. The displayed organization/ASN may identify an ISP or network owner, not necessarily the physical datacenter.'],
      ['3. Copy and export','Copy the IP or IP:port for one row, copy all IPs in the current batch, or export the current batch as JSON or CSV.'],
      ['4. Globalping quota','Only the current batch is pinged; the app does not automatically fire tens of thousands of tests. An unavailable result is shown as unknown and is never replaced by a local ping or another ping provider.'],
      ['5. Other network tools','Speed, HTTP, DNS and allowlisted active-target tools remain separate utilities. Their response times or TCP port timings are not presented as proxy ping; all fields explicitly named ping use Globalping.'],
      ['6. Proxy safety','Public proxies can be dead, slow, intercept traffic, or log requests. A successful IP ping proves network reachability, not that the proxy protocol is usable or safe.']
    ]:[
      ['۱. اسکنر پروکسی','اسکنر فقط فهرست JSON عمومی Proxifly را دریافت می‌کند. پینگ هر IP نمایش‌داده‌شده فقط از Globalping گرفته می‌شود؛ برای کشف IP از Shodan، Netlas، Tavily، HProxy یا ProxyScrape استفاده نمی‌شود. برای ادامه فهرست، «دسته بعدی» را بزن.'],
      ['۲. کشور و سازمان','کشور/شهر ممکن است از Proxifly یا اطلاعات تکمیلی IP به دست بیاید. نام سازمان یا ASN ممکن است نام شرکت ارائه‌دهنده شبکه باشد و لزوماً نام دقیق دیتاسنتر فیزیکی نیست.'],
      ['۳. کپی و خروجی','می‌توانی IP یا IP:port یک ردیف، همه IPهای دسته فعلی، یا خروجی JSON و CSV همان دسته را کپی/ذخیره کنی.'],
      ['۴. سهمیه Globalping','فقط دسته فعلی پینگ می‌شود و برنامه به‌طور خودکار ده‌ها هزار تست را یک‌باره اجرا نمی‌کند. اگر Globalping نتیجه ندهد، وضعیت نامشخص نمایش داده می‌شود و پینگ محلی یا سرویس پینگ دیگری جایگزین نمی‌شود.'],
      ['۵. ابزارهای شبکه دیگر','ابزارهای سرعت، HTTP، DNS و اسکن مجاز همچنان ابزارهای جداگانه‌اند. زمان پاسخ HTTP یا زمان اتصال TCP به‌عنوان پینگ پروکسی معرفی نمی‌شود؛ هر فیلدی که صراحتاً پینگ است از Globalping می‌آید.'],
      ['۶. ایمنی پروکسی','پروکسی عمومی ممکن است از کار افتاده، کند، ناامن یا ثبت‌کننده درخواست‌ها باشد. پاسخ پینگ IP فقط دسترسی شبکه را نشان می‌دهد و سلامت پروتکل پروکسی را ثابت نمی‌کند.']
    ];
    const sourceRows=Object.entries(d.sources||{}).map(([key,value])=>`<div class="kv"><span>${esc(key)}</span><span>${esc(value)}</span></div>`).join('');
    return `<div class="guide-stack">${sections.map(([h,body])=>`<section class="guide-card"><b>${esc(h)}</b><p>${esc(body)}</p></section>`).join('')}<details><summary>${en?'Reference endpoints':'منابع مرجع'}</summary><div class="result">${sourceRows}</div></details></div>`;
  })
}
function ipInfoToolV7(){inputTool(t('ipInfo'),[{id:'ip',ph:'1.1.1.1'}],async({ip})=>{const d=await j('/api/ip/lookup?ip='+encodeURIComponent(ip));return `${k(['IP',d.ip])}${k([currentLanguage==='en'?'Country':'کشور',d.country||'—'])}${k([currentLanguage==='en'?'City':'شهر',d.city||'—'])}${k([currentLanguage==='en'?'Network':'شبکه',d.name||'—'])}${k(['ASN',d.asn?`AS${d.asn}`:'—'])}${k([currentLanguage==='en'?'Ports':'پورت‌ها',(d.openPorts||[]).join(', ')||'—'])}<details><summary>JSON</summary><div class="code">${esc(JSON.stringify(d,null,2))}</div></details>`})}
function githubLiveToolV7(){
  openModal(t('githubLive'),`<div class="mini-note">${currentLanguage==='en'?'The only proxy-list source is Proxifly JSON.':'تنها منبع فهرست پروکسی‌ها، JSON رسمی Proxifly است.'}</div><div class="config-actions"><button id="ghRun" class="primary">${esc(t('search'))}</button><button id="ghJson" class="secondary">JSON</button></div><div id="ghOut" class="result">${esc(t('ready'))}</div>`);
  const load=async()=>{const out=$('#ghOut');setLoading(out);try{const d=await j('/api/github/live');const rows=d.proxies||[];out.innerHTML=`${k(['Source','Proxifly JSON'])}${k([currentLanguage==='en'?'Loaded entries':'ورودی‌های دریافت‌شده',d.count||0])}${k(['Updated',d.fetchedAt||'—'])}<div class="code">${esc(rows.slice(0,100).map(x=>`${x.protocol?x.protocol+'://':''}${x.ip}:${x.port}`).join('\n'))}</div>`}catch(e){out.innerHTML=`<div class="code">${esc(e.message)}</div>`}};
  $('#ghRun').onclick=load;$('#ghJson').onclick=async()=>{try{const d=await j('/api/github/live');downloadBlob(JSON.stringify(d,null,2),'proxifly-proxies.json','application/json')}catch(e){toast(e.message)}};
}
function countriesToolV7(){switchView('countries')}
function ispsToolV7(){
  openModal(t('isps'),`<label class="modal-label">${currentLanguage==='en'?'Country':'کشور'}<select id="ispCountry" class="field">${countryOptionsV7()}</select></label><div class="mini-note">${currentLanguage==='en'?'Organizations are derived from saved Proxifly scan results.':'این فهرست از سازمان‌هایی ساخته می‌شود که در نتایج قبلی Proxifly دیده شده‌اند.'}</div><div id="ispOut" class="result">${esc(t('ready'))}</div>`);
  const load=async()=>{const cc=$('#ispCountry').value;try{const d=await j('/api/isp/list?country='+encodeURIComponent(cc));$('#ispOut').innerHTML=(d.providers||[]).map(p=>`<button class="row-btn isp-row" data-provider="${esc(p.name||p)}">🏢 ${esc(p.name||p)}<small>${esc((p.searchTerms||[]).join(' · '))}</small></button>`).join('')||t('noResults');$('#ispOut').querySelectorAll('[data-provider]').forEach(b=>b.onclick=()=>{const provider=b.dataset.provider;selectedWorldCountries=new Set([cc]);storageSet(WORLD_SELECTION_KEY,JSON.stringify([cc]));switchView('scanner');renderWorldCountryPickersV6();updateWorldSelectionUI();syncWorldMapV6();const inp=$('#worldProvider');if(inp)inp.value='';toast(currentLanguage==='en'?`Showing Proxifly proxies in ${cc}; use the country filter for inventory.`:`نمایش فهرست Proxifly برای ${cc}؛ منبع بر اساس کشور فیلتر شد.`);runWorldDiscoveryV6();});}catch(e){$('#ispOut').innerHTML=`<div class="code">${esc(e.message)}</div>`}};$('#ispCountry').onchange=load;load();}
function countryIpToolV7(){openModal(t('countryIp'),`<label class="modal-label">${currentLanguage==='en'?'Country':'کشور'}<select id="cipCountry" class="field">${countryOptionsV7()}</select></label><label class="modal-label">${currentLanguage==='en'?'Max results':'حداکثر نتیجه'}<select id="cipLimit" class="field"><option>4</option><option selected>8</option><option>12</option></select></label><button id="cipRun" class="primary">${esc(t('search'))}</button><div id="cipOut" class="result">${esc(t('ready'))}</div>`);$('#cipRun').onclick=async()=>{const c=$('#cipCountry').value,limit=$('#cipLimit').value;const out=$('#cipOut');setLoading(out);try{const d=await j(`/api/world-discovery?countries=${c}&ports=80,443&limit=${limit}`);out.innerHTML=(d.countries||[]).flatMap(g=>(g.results||[]).map(r=>`<div class="result"><div class="kv"><span>${flag(c)} <code>${esc(r.ip)}</code></span><span>${r.ping?.avgMs!=null?fmtMs(r.ping.avgMs):'—'}</span></div>${k(['Provider',r.provider||r.asName||'—'])}${k(['ASN',r.asn?`AS${r.asn}`:'—'])}${k(['Location',r.city?`${r.city} (${r.lat??'—'}, ${r.lon??'—'})`:'—'])}${k(['Ports',[...(r.confirmedPorts||[]),...(r.observedPorts||[])].join(', ')||'—'])}</div>`)).join('')||t('noResults')}catch(e){out.innerHTML=`<div class="code">${esc(e.message)}</div>`}}}
function portToolV7(){
  const defaults=[...selectedWorldCountries].slice(0,3);openModal(t('port'),`<label class="modal-label">${currentLanguage==='en'?'IP / hostname':'IP یا hostname'}<input id="pcHost" class="field" placeholder="1.1.1.1"></label><label class="modal-label">Port<input id="pcPort" class="field" value="443"></label><div class="subsection-head"><b>${currentLanguage==='en'?'Ping countries':'کشورهای Ping'}</b></div><div class="form-grid">${multiCountryCheckboxesV7(new Set(defaults.length?defaults:['DE','FR','NL']))}</div><button id="pcRun" class="primary">${esc(t('search'))}</button><div id="pcOut" class="result">${esc(t('ready'))}</div>`);$('#pcRun').onclick=async()=>{const host=$('#pcHost').value.trim(),port=$('#pcPort').value.trim(),out=$('#pcOut');setLoading(out);try{const countries=readMultiCountriesV7();const d=await j(`/api/port-check?host=${encodeURIComponent(host)}&port=${encodeURIComponent(port)}&countries=${encodeURIComponent(countries.join(','))}`);let html=`${k(['Host',d.host])}${k(['Resolved',d.resolvedAddress||'—'])}${k(['Port',d.port])}${k(['Service',d.service])}${k(['State',d.open?'OPEN':String(d.state||'CLOSED').toUpperCase()])}${k(['TCP latency',fmtMs(d.latencyMs)])}`;if(d.globalping?.results?.length)html+='<div class="subsection-head"><b>Globalping</b></div>'+d.globalping.results.map(r=>`<div class="kv"><span>${flag(r.country)} ${esc(r.countryName)} · ${esc(r.city||'—')}</span><span>${fmtMs(r.avgMs)}</span></div>`).join('');out.innerHTML=html}catch(e){out.innerHTML=`<div class="code">${esc(e.message)}</div>`}}}
function httpToolV7(){inputTool(t('http'),[{id:'url',ph:'https://example.com'}],async({url})=>{const d=await j('/api/http-check?url='+encodeURIComponent(url));return `${k(['Status',`${d.status||'—'} ${d.statusText||''}`])}${k([currentLanguage==='en'?'Latency':'تاخیر',fmtMs(d.latencyMs)])}${k([currentLanguage==='en'?'Final URL':'URL نهایی',d.finalUrl||'—'])}${k([currentLanguage==='en'?'Redirects':'ریدایرکت‌ها',(d.redirects||[]).length])}${k(['Server',d.headers?.server||'—'])}<details><summary>Headers</summary><div class="code">${esc(JSON.stringify(d.headers||{},null,2))}</div></details>`})}

Object.assign(TOOL_I18N,{
  'proxy-best':['بهترین IP پروکسی پرسرعت','پروکسی‌های عمومی مرتب‌شده بر اساس latency','Fast Proxy IP','Public proxies sorted by latency'],
  'proxy-v4':['پروکسی‌های IPv4','فهرست زنده IPv4','IPv4 Proxies','Live IPv4 proxy list'],
  'proxy-v6':['پروکسی‌های IPv6','فهرست زنده IPv6','IPv6 Proxies','Live IPv6 proxy list'],
  global:['چک پینگ','پینگ از چند کشور با Globalping','Ping Check','Multi-country ping with Globalping'],
  guide:['راهنما','نحوه کار منابع و ابزارها','Guide','How the tools and sources work'],
  'ip-info':['اطلاعات IP','کشور، شهر، شبکه، ASN و پورت‌ها','IP Information','Country, city, network, ASN and ports'],
  'github-live':['فهرست Proxifly','خواندن لیست‌های زنده عمومی GitHub','Live from GitHub','Read public live GitHub lists'],
  countries:['فهرست کشورها','انتخاب کشور و جستجوی IP','Countries','Select a country and discover IPs'],
  isps:['سازمان‌های مشاهده‌شده','دیتاسنترهای منتخب هر کشور و جستجویشان','Observed organizations','Country provider targets and discovery'],
  speed:['تست سرعت','Download / Upload / Ping','Speed Test','Download / Upload / Ping'],
  'country-ip':['IP کشورهای مختلف','کشف زنده IPهای کشور منتخب','Country IPs','Live discovery for a selected country'],
  port:['Port Check','IP + port + global ping','Port Check','IP + port + global ping'],
  http:['HTTP Checker','Status، latency و redirect امن','HTTP Checker','Status, latency and safe redirects']
});
function proxyBestTool(){return bestProxyOpen()}function proxyV4Tool(){return proxyV4Open()}function proxyV6Tool(){return proxyV6Open()}
const replacementToolsV7=[
 {id:'proxy-best',icon:'⚡',name:'بهترین IP پروکسی پرسرعت',desc:'پروکسی‌های عمومی با latency پایین',open:proxyBestTool},
 {id:'proxy-v4',icon:'◉',name:'پروکسی‌های IPv4',desc:'فهرست زنده IPv4',open:proxyV4Tool},
 {id:'proxy-v6',icon:'◌',name:'پروکسی‌های IPv6',desc:'فهرست زنده IPv6',open:proxyV6Tool},
 {id:'global',icon:'◈',name:'چک پینگ',desc:'Globalping از چند کشور',open:multiPingToolV7},
 {id:'guide',icon:'?',name:'راهنما',desc:'منابع و روش استفاده',open:guideToolV7},
 {id:'ip-info',icon:'◉',name:'اطلاعات IP',desc:'Geo، ASN، شبکه و پورت',open:ipInfoToolV7},
 {id:'github-live',icon:'●',name:'فهرست Proxifly',desc:'نمایش پروکسی‌های منبع Proxifly',open:githubLiveToolV7},
 {id:'countries',icon:'🌍',name:'فهرست کشورها',desc:'کشورهای فعال برای جستجوی زنده',open:countriesToolV7},
 {id:'isps',icon:'🏢',name:'سازمان‌های مشاهده‌شده',desc:'دیتاسنترهای منتخب کشور',open:ispsToolV7},
 {id:'ip-db',icon:'🗄️',name:'دیتابیس IP',desc:'IPهای واقعی ذخیره‌شده و پینگ Globalping',open:ipDatabaseToolV8},
 {id:'speed',icon:'⚡',name:'تست سرعت',desc:'Download / Upload / Ping',open:speedToolV6},
 {id:'country-ip',icon:'⌁',name:'IP کشورهای مختلف',desc:'کشف IP واقعی کشور',open:countryIpToolV7},
 {id:'port',icon:'⟂',name:'Port Check',desc:'IP + Port + Global Ping',open:portToolV7},
 {id:'http',icon:'↗',name:'HTTP Checker',desc:'Status، latency و redirect امن',open:httpToolV7}
];
// Replace the legacy grid entirely. The underlying legacy functions stay available only for
// compatibility with older saved links; they are no longer displayed in the tool list.
tools.splice(0,tools.length,...replacementToolsV7);

async function renderCountryCatalogPanelV7(){
  const box=$('#countryCatalogPanel'); if(!box)return;
  const rows=TOOL_COUNTRIES_V7.map(([code,en,fa])=>`<button class="country-picker active" data-catalog-country="${code}">${flag(code)} <b>${esc(currentLanguage==='en'?en:fa)}</b><small>${code}</small></button>`).join('');
  box.innerHTML=`<div class="country-pickers">${rows}</div><div class="mini-note">${esc(currentLanguage==='en'?'Click a country to select it in the scanner and run live IP discovery. Countries with zero live results are not shown in the results.':'روی کشور بزن تا در Scanner فقط همان کشور انتخاب شود و جستجوی زنده IP اجرا شود. کشور بدون نتیجه در خروجی نمایش داده نمی‌شود.')}</div>`;
  box.querySelectorAll('[data-catalog-country]').forEach(b=>b.onclick=()=>{const cc=b.dataset.catalogCountry;selectedWorldCountries=new Set([cc]);storageSet(WORLD_SELECTION_KEY,JSON.stringify([cc]));switchView('scanner');renderWorldCountryPickersV6();updateWorldSelectionUI();syncWorldMapV6();runWorldDiscoveryV6();});
}
const oldSwitchView=switchView;
switchView=function(view){oldSwitchView(view);if(view==='countries')renderCountryCatalogPanelV7();if(view==='server')loadServer();};

const oldApplyLanguage=applyLanguage;
applyLanguage=function(lang=currentLanguage){oldApplyLanguage(lang);renderCountryCatalogPanelV7();renderToolGridLocalized('#toolGrid');renderToolGridLocalized('#toolGrid2');};

// Start with all ten countries selected, but only show selected markers/labels on the map.
// Keep the legacy handlers from the original UI, but replace only these openers with the working v6 implementations.
/* replaced by replacementToolsV7 */

function initTelegramMiniAppV6(){
  try{
    const tg=window.Telegram?.WebApp; if(!tg)return;
    tg.ready(); tg.expand();
    if(tg.initData) j('/api/telegram/auth',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({initData:tg.initData})}).then(()=>{}).catch(()=>{});
  }catch(_){ }
}
async function loadTelegramStatusV6(){
  const state=$('#telegramState'),info=$('#telegramInfo'); if(!state)return;
  try{const d=await j('/api/telegram/status');state.textContent=d.configured?'ON':'OFF';state.className='badge '+(d.configured?'ok':'neutral');if(info)info.textContent=d.configured?(currentLanguage==='en'?`Connected as @${d.botUsername||'Mahdiarscanner_Bot'}. /start opens the Mini App.`:`ربات @${d.botUsername||'Mahdiarscanner_Bot'} متصل است؛ /start لینک Mini App را می‌فرستد.`):(currentLanguage==='en'?'Bot UI is active; server token is not loaded yet.': 'رابط ربات آماده است؛ توکن سمت سرور هنوز لود نشده است.');
  }catch(e){if(info)info.textContent=e.message}
}
async function saveTelegramV6(){
  const token=$('#telegramBotToken').value.trim(), key=$('#telegramSetupKey').value.trim(), appUrl=$('#telegramAppUrl').value.trim()||location.origin+'/';
  if(!token||!key)return toast(currentLanguage==='en'?'Bot token and setup key are required.':'توکن ربات و Setup Key الزامی است.');
  try{const d=await j('/api/telegram/config',{method:'POST',headers:{'content-type':'application/json','x-setup-key':key},body:JSON.stringify({botToken:token,appUrl,setupKey:key})});$('#telegramBotToken').value='';toast(currentLanguage==='en'?`Connected to @${d.bot?.username||'bot'}. Send /start in Telegram.`:`به @${d.bot?.username||'bot'} وصل شد؛ در تلگرام /start را بزن.`);loadTelegramStatusV6()}catch(e){toast(e.message)}
}
async function testTelegramV6(){
  const key=$('#telegramSetupKey').value.trim(), chatId=$('#telegramChatId').value.trim(), appUrl=$('#telegramAppUrl').value.trim()||location.origin+'/';
  if(!key||!chatId)return toast(currentLanguage==='en'?'Setup key and chat ID are required.':'Setup Key و Chat ID الزامی است.');
  try{await j('/api/telegram/test',{method:'POST',headers:{'content-type':'application/json','x-setup-key':key},body:JSON.stringify({chatId,appUrl,setupKey:key})});toast(currentLanguage==='en'?'Test message sent.':'پیام تست ارسال شد.')}catch(e){toast(e.message)}
}

// Ensure browser public IP is never replaced by the server's own public IP in the hero card.
async function getBrowserPublicIpV6(){ return getBrowserPublicIp(); }
function netLooksPublic(ip){const s=String(ip||'').trim();if(!s||netLikeIPv4Private(s))return false;return /^(?:\d{1,3}\.){3}\d{1,3}$/.test(s)||/^[0-9a-f:]+$/i.test(s)}
function netLikeIPv4Private(ip){const p=String(ip).split('.').map(Number);if(p.length!==4||p.some(x=>!Number.isFinite(x)))return false;return p[0]===10||p[0]===127||(p[0]===172&&p[1]>=16&&p[1]<=31)||(p[0]===192&&p[1]===168)||p[0]===0}
async function refreshHeroPublicIpV6(){try{const ip=await getBrowserPublicIpV6();$('#heroIp').textContent=ip||'—';const sub=$('.hero-ip .subtle');if(sub)sub.textContent=currentLanguage==='en'?'Your public IP':'IP عمومی شما'}catch(_){}}

// Rebind world legacy elements safely and initialize the new layer.
setTimeout(async()=>{
  try{applyLanguage(currentLanguage);}catch(_){}
  if($('#languageSelect'))$('#languageSelect').value=currentLanguage;
  try{await loadWorldCountriesV6();}catch(_){}
  try{initTelegramMiniAppV6();}catch(_){}
  try{loadTelegramStatusV6();}catch(_){}
  try{refreshHeroPublicIpV6();}catch(_){}
  try{loadServer();}catch(_){}
  try{renderCountryCatalogPanelV7();}catch(_){}
},0);


function ipToolV6(){
  openModal(currentLanguage==='en'?'My public IP':'IP من',`<div class="result" id="ipResult">${currentLanguage==='en'?'Detecting your public IP…':'در حال تشخیص IP عمومی شما…'}</div>`);
  getBrowserPublicIpV6().then(ip=>{
    if(!ip){const out=$('#ipResult');if(!out)return;out.innerHTML=`<div class="notice">${currentLanguage==='en'?'Your public IP could not be detected.':'IP عمومی شما تشخیص داده نشد.'}</div>`;return;}
    j('/api/ip/lookup?ip='+encodeURIComponent(ip)).then(x=>{const out=$('#ipResult');if(!out)return;out.innerHTML=`<div class="ip-card"><div class="ip-card-top"><code>${esc(ip)}</code><span class="mini-badge">${esc(x.country||'—')}</span></div>${k([currentLanguage==='en'?'Network':'شبکه',x.name||'—'])}${k([currentLanguage==='en'?'Range':'بازه',`${x.startAddress||'—'} → ${x.endAddress||'—'}`])}</div>`}).catch(()=>{const out=$('#ipResult');if(!out)return;out.innerHTML=`<div class="ip-card"><div class="ip-card-top"><code>${esc(ip)}</code></div><div class="muted">${currentLanguage==='en'?'Public IP detected; metadata lookup unavailable.':'IP عمومی پیدا شد؛ جزئیات شبکه در دسترس نیست.'}</div></div>`});
  }).catch(e=>{const out=$('#ipResult');if(out)out.innerHTML=`<div class="code">${esc(e.message)}</div>`});
}
/* public-IP button uses the dashboard card; no legacy ip tool is exposed */

// Fix dashboard 'Open Scanner' button: scanner is a view, not a toolkit item.
document.querySelector('[data-open="scanner"]')?.addEventListener('click',(ev)=>{ev.preventDefault();switchView('scanner');setTimeout(()=>{loadWorldCountriesV6();window.scrollTo({top:0,behavior:'smooth'});},0);});
