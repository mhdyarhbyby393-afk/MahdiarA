const express = require('express');
const dns = require('node:dns').promises;
const net = require('node:net');
const tls = require('node:tls');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');

const execFileAsync = promisify(execFile);

// Botkeep stores managed Environment/Secret values in the runtime .env file for
// application profiles. Load that file before reading process.env, while never
// overriding values already injected directly into the runtime.
const managedEnvKeys = new Set();
function loadManagedEnv() {
  const candidates = [
    path.join(__dirname, '.env'),
    path.join(process.cwd(), '.env')
  ];
  const seen = new Set();
  for (const file of candidates) {
    const resolved = path.resolve(file);
    if (seen.has(resolved) || !fs.existsSync(resolved)) continue;
    seen.add(resolved);
    try {
      const text = fs.readFileSync(resolved, 'utf8').replace(/^\uFEFF/, '');
      for (const rawLine of text.split(/\r?\n/)) {
        const line = rawLine.trim();
        if (!line || line.startsWith('#')) continue;
        const withoutExport = line.startsWith('export ') ? line.slice(7).trim() : line;
        const eq = withoutExport.indexOf('=');
        if (eq <= 0) continue;
        const key = withoutExport.slice(0, eq).trim();
        if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key) || process.env[key] != null) continue;
        let value = withoutExport.slice(eq + 1).trim();
        if ((value.startsWith('\"') && value.endsWith('\"')) || (value.startsWith("'") && value.endsWith("'"))) {
          value = value.slice(1, -1);
        }
        value = value.replace(/\\n/g, '\n').replace(/\\r/g, '\r');
        process.env[key] = value;
        managedEnvKeys.add(key);
      }
    } catch (_) {
      // Keep startup resilient; direct runtime environment variables still work.
    }
  }
}
loadManagedEnv();

const app = express();
app.use('/api', (_req,res,next)=>{ res.setHeader('Cache-Control','no-store, no-cache, must-revalidate'); next(); });
app.set('trust proxy', true);
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: false, limit: '256kb' }));

const PORT = Number(process.env.PORT || process.env.SERVER_PORT || 3000);
const APP_VERSION = '6.7.4';
const HISTORY_FILE = path.join(__dirname, 'data', 'history.json');
const WORLD_RESULTS_FILE = path.join(__dirname, 'data', 'world-results.json');
const AUTO_DISCOVERY_STATE_FILE = path.join(__dirname, 'data', 'auto-discovery.json');
const startedAt = Date.now();
const counters = { requests: 0, success: 0, errors: 0 };
const requestTimes = [];
const recentEvents = [];
const serverProblems = new Map();
const rateMap = new Map();
const speedSessions = new Map();
let speedTestRunning = false;
let speedTestLastAt = 0;
let speedTestLastResult = null;
const scanJobs = new Map();
const countryRangeCache = new Map();

const MAX_HISTORY = 500;
const MAX_TARGET_LENGTH = 253;
const MAX_SCAN_HOSTS = 1024;
const MAX_SCAN_PORTS = 128;
const MAX_SCAN_JOBS = 2;
const SAFE_DNS_TYPES = new Set(['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA', 'SRV', 'CAA', 'PTR']);
const DEFAULT_HTTP_TIMEOUT = 8000;
const DEFAULT_TCP_TIMEOUT = 3000;
const SCAN_HOST_CONCURRENCY = 12;
const SCAN_PORT_CONCURRENCY = 8;
const PRIVATE_HOST_RE = /^(localhost|.*\.local)$/i;
const SCAN_ALLOWED_TARGETS = String(process.env.SCAN_ALLOWED_TARGETS || '')
  .split(',').map(v => v.trim().toLowerCase()).filter(Boolean);
let TAVILY_API_KEY = '';
let CHECK_HOST_API_KEY = '';
let SHODAN_API_KEY = '';
let NETLAS_API_KEY = '';
let ZOOMEYE_API_KEY = '';
let CENSYS_API_TOKEN = '';
let PROXYSCAPE_API_TOKEN = '';
let IPINFO_TOKEN = '';
let ABUSEIPDB_API_KEY = '';

function refreshProviderSecrets() {
  loadManagedEnv();
  // Legacy IP-discovery and alternate proxy-list providers are intentionally disabled.
  // The public proxy inventory comes only from Proxifly; all ping measurements come from Globalping.
  TAVILY_API_KEY = '';
  SHODAN_API_KEY = '';
  NETLAS_API_KEY = '';
  ZOOMEYE_API_KEY = '';
  CENSYS_API_TOKEN = '';
  PROXYSCAPE_API_TOKEN = '';
  // These optional keys remain for non-discovery utilities, not for the proxy inventory or ping path.
  CHECK_HOST_API_KEY = String(process.env.CHECK_HOST_API_KEY || '').trim();
  IPINFO_TOKEN = String(process.env.IPINFO_TOKEN || '').trim();
  ABUSEIPDB_API_KEY = String(process.env.ABUSEIPDB_API_KEY || '').trim();
}
refreshProviderSecrets();

function envState(value, key) {
  const configured = Boolean(String(value || '').trim());
  return {
    configured,
    source: configured ? (managedEnvKeys.has(key) ? '.env' : 'runtime environment') : 'none'
  };
}

const CHECK_HOST_LOCATIONS_CACHE_TTL = 30 * 60 * 1000;
const worldDiscoveryCache = new Map();
const autoDiscoveryIntervalMs = Math.floor(24 * 60 * 60 * 1000 / 32);
let autoDiscoveryRunning = false;
let checkHostLocationsCache = { at: 0, data: null };

const PORT_GROUPS = {
  web: [80, 443, 3000, 5000, 8000, 8008, 8080, 8081, 8443, 8888],
  remote: [22, 3389, 5900],
  mail: [25, 110, 143, 465, 587, 993, 995],
  dns: [53, 853],
  database: [1433, 1521, 3306, 50000, 5432, 6379, 9200, 9300, 11211, 27017],
  common: [21, 22, 25, 53, 80, 110, 135, 139, 143, 443, 445, 587, 993, 995, 1433, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 9200, 27017]
};

const SCAN_PROFILES = {
  quick: {
    label: 'Quick',
    description: 'Fast common web/admin ports',
    ports: [22, 53, 80, 443, 8080, 8443]
  },
  web: {
    label: 'Web',
    description: 'HTTP/HTTPS and common web ports',
    ports: [80, 443, 3000, 5000, 8000, 8008, 8080, 8081, 8443, 8888]
  },
  common: {
    label: 'Common',
    description: 'Typical infrastructure/service ports',
    ports: [21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443, 445, 587, 993, 995, 1433, 1521, 2049, 2375, 3000, 3306, 3389, 5000, 5432, 5900, 6379, 8000, 8080, 8443, 9200, 27017]
  },
  remote: {
    label: 'Remote',
    description: 'SSH, RDP and VNC endpoints',
    ports: [22, 3389, 5900]
  },
  mail: {
    label: 'Mail',
    description: 'SMTP, POP3 and IMAP endpoints',
    ports: [25, 110, 143, 465, 587, 993, 995]
  },
  database: {
    label: 'Database',
    description: 'Common database/cache endpoints',
    ports: [1433, 1521, 3306, 50000, 5432, 6379, 9200, 9300, 11211, 27017]
  },
  custom: {
    label: 'Custom',
    description: 'Only your selected ports',
    ports: []
  }
};

const COUNTRY_CODES = {
  US:'United States', CA:'Canada', MX:'Mexico', BR:'Brazil', AR:'Argentina', CL:'Chile', CO:'Colombia', PE:'Peru', VE:'Venezuela',
  GB:'United Kingdom', IE:'Ireland', FR:'France', DE:'Germany', NL:'Netherlands', BE:'Belgium', ES:'Spain', PT:'Portugal', IT:'Italy', CH:'Switzerland', AT:'Austria',
  SE:'Sweden', NO:'Norway', DK:'Denmark', FI:'Finland', IS:'Iceland', PL:'Poland', CZ:'Czechia', SK:'Slovakia', HU:'Hungary', RO:'Romania', BG:'Bulgaria',
  GR:'Greece', UA:'Ukraine', TR:'Türkiye', RU:'Russia', IL:'Israel', SA:'Saudi Arabia', AE:'United Arab Emirates', QA:'Qatar', KW:'Kuwait', BH:'Bahrain',
  IR:'Iran', IQ:'Iraq', JO:'Jordan', LB:'Lebanon', EG:'Egypt', MA:'Morocco', TN:'Tunisia', DZ:'Algeria', ZA:'South Africa', NG:'Nigeria', KE:'Kenya',
  IN:'India', PK:'Pakistan', BD:'Bangladesh', LK:'Sri Lanka', NP:'Nepal', CN:'China', JP:'Japan', KR:'South Korea', TW:'Taiwan', HK:'Hong Kong',
  SG:'Singapore', MY:'Malaysia', TH:'Thailand', VN:'Vietnam', ID:'Indonesia', PH:'Philippines', AU:'Australia', NZ:'New Zealand', AZ:'Azerbaijan',
  AM:'Armenia', GE:'Georgia', KZ:'Kazakhstan', UZ:'Uzbekistan', AF:'Afghanistan', MN:'Mongolia', KH:'Cambodia', MM:'Myanmar',
  BR:'Brazil', AT:'Austria', EE:'Estonia', LV:'Latvia', LT:'Lithuania', SI:'Slovenia', HR:'Croatia', RS:'Serbia', BA:'Bosnia and Herzegovina',
  CL:'Chile', CR:'Costa Rica', PA:'Panama', DO:'Dominican Republic', PR:'Puerto Rico',
  AD:'Andorra', AL:'Albania', BA:'Bosnia and Herzegovina', BY:'Belarus', CY:'Cyprus',
  LI:'Liechtenstein', LU:'Luxembourg', MT:'Malta', MC:'Monaco', MD:'Moldova', ME:'Montenegro',
  MK:'North Macedonia', SM:'San Marino', VA:'Vatican City', IS:'Iceland',
  BS:'Bahamas', BB:'Barbados', BZ:'Belize', BO:'Bolivia', CU:'Cuba', DM:'Dominica', GD:'Grenada',
  GT:'Guatemala', GY:'Guyana', HT:'Haiti', HN:'Honduras', JM:'Jamaica', NI:'Nicaragua',
  PY:'Paraguay', SR:'Suriname', TT:'Trinidad and Tobago', UY:'Uruguay',
  AG:'Antigua and Barbuda', KN:'Saint Kitts and Nevis', LC:'Saint Lucia', VC:'Saint Vincent and the Grenadines',
  AE:'United Arab Emirates', OM:'Oman', YE:'Yemen', SY:'Syria', PS:'Palestine',
  BH:'Bahrain', QA:'Qatar', KW:'Kuwait',
  TM:'Turkmenistan', TJ:'Tajikistan', KG:'Kyrgyzstan', AZ:'Azerbaijan', AM:'Armenia', GE:'Georgia',
  MN:'Mongolia', BT:'Bhutan', MV:'Maldives', MM:'Myanmar', KH:'Cambodia', LA:'Laos',
  BN:'Brunei', TL:'Timor-Leste', FJ:'Fiji', PG:'Papua New Guinea', WS:'Samoa', TO:'Tonga',
  VU:'Vanuatu', SB:'Solomon Islands', FM:'Micronesia', MH:'Marshall Islands', PW:'Palau',
  NR:'Nauru', KI:'Kiribati', TV:'Tuvalu', NC:'New Caledonia', PF:'French Polynesia', GU:'Guam',
  AF:'Afghanistan', DZ:'Algeria', AO:'Angola', BJ:'Benin', BW:'Botswana', BF:'Burkina Faso',
  BI:'Burundi', CM:'Cameroon', CV:'Cabo Verde', CF:'Central African Republic', TD:'Chad', KM:'Comoros',
  CG:'Republic of the Congo', CD:'Democratic Republic of the Congo', CI:'Côte d’Ivoire', DJ:'Djibouti',
  GQ:'Equatorial Guinea', ER:'Eritrea', SZ:'Eswatini', ET:'Ethiopia', GA:'Gabon', GM:'Gambia', GH:'Ghana',
  GN:'Guinea', GW:'Guinea-Bissau', LR:'Liberia', LY:'Libya', MG:'Madagascar', MW:'Malawi', ML:'Mali',
  MR:'Mauritania', MU:'Mauritius', MZ:'Mozambique', NA:'Namibia', NE:'Niger', RW:'Rwanda',
  ST:'Sao Tome and Principe', SC:'Seychelles', SL:'Sierra Leone', SO:'Somalia', SS:'South Sudan',
  SD:'Sudan', TZ:'Tanzania', TG:'Togo', UG:'Uganda', ZM:'Zambia', ZW:'Zimbabwe',
  LS:'Lesotho', SZ:'Eswatini',
  BS:'Bahamas', BB:'Barbados',
  KP:'North Korea', MO:'Macao',
  AS:'American Samoa', VI:'U.S. Virgin Islands', PR:'Puerto Rico', MP:'Northern Mariana Islands',
  AQ:'Antarctica'
};

const SERVICE_MAP = {
  21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS', 80: 'HTTP',
  110: 'POP3', 111: 'RPCbind', 135: 'MSRPC', 139: 'NetBIOS', 143: 'IMAP',
  443: 'HTTPS', 445: 'SMB', 465: 'SMTPS', 587: 'SMTP Submission', 853: 'DNS-over-TLS', 993: 'IMAPS', 995: 'POP3S',
  1433: 'MSSQL', 1521: 'Oracle', 2049: 'NFS', 2375: 'Docker', 3000: 'HTTP-alt',
  3306: 'MySQL', 3389: 'RDP', 5000: 'HTTP-alt', 5432: 'PostgreSQL', 5900: 'VNC',
  6379: 'Redis', 8000: 'HTTP-alt', 8080: 'HTTP-proxy', 8081: 'HTTP-alt', 8443: 'HTTPS-alt',
  8888: 'HTTP-alt', 9200: 'Elasticsearch', 9300: 'Elasticsearch transport',
  11211: 'Memcached', 27017: 'MongoDB'
};

function ensureDataDir() {
  const dir = path.dirname(HISTORY_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(HISTORY_FILE)) fs.writeFileSync(HISTORY_FILE, '[]');
}
ensureDataDir();

function readHistory() {
  try { return JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8')); }
  catch { return []; }
}
function writeHistory(items) {
  try { fs.writeFileSync(HISTORY_FILE, JSON.stringify(items.slice(-MAX_HISTORY), null, 2)); }
  catch (_) {}
}
function saveEvent(type, target, ok, summary = '') {
  const event = {
    id: crypto.randomUUID(),
    at: new Date().toISOString(),
    type,
    target: String(target || '').slice(0, 180),
    ok: Boolean(ok),
    summary: String(summary || '').slice(0, 300)
  };
  recentEvents.unshift(event);
  recentEvents.splice(50);
  if (!['health', 'status'].includes(type)) {
    const history = readHistory();
    history.push(event);
    writeHistory(history);
  }
}

function recordServerProblem(source, message, severity = 'error') {
  const name = String(source || 'Unknown').trim().slice(0, 80) || 'Unknown';
  const key = name.toLowerCase();
  const previous = serverProblems.get(key);
  serverProblems.set(key, {
    source: name,
    message: String(message || 'Unknown provider error').replace(/[\r\n]+/g, ' ').slice(0, 500),
    severity: severity === 'warning' ? 'warning' : 'error',
    at: new Date().toISOString(),
    occurrences: Number(previous?.occurrences || 0) + 1
  });
  while (serverProblems.size > 20) serverProblems.delete(serverProblems.keys().next().value);
}
function clearServerProblem(source) {
  serverProblems.delete(String(source || '').trim().toLowerCase());
}
function currentServerProblems() {
  return [...serverProblems.values()].sort((a, b) => Date.parse(b.at) - Date.parse(a.at)).slice(0, 20);
}


function readWorldResults() {
  ensureDataDir();
  try {
    const raw = fs.readFileSync(WORLD_RESULTS_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) { return []; }
}
function writeWorldResults(items) {
  ensureDataDir();
  const trimmed = (Array.isArray(items) ? items : []).slice(-WORLD_RESULTS_MAX);
  const tempFile = `${WORLD_RESULTS_FILE}.tmp`;
  try {
    fs.writeFileSync(tempFile, JSON.stringify(trimmed, null, 2));
    fs.renameSync(tempFile, WORLD_RESULTS_FILE);
  } catch (error) {
    try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (_) {}
    console.error('[database] Could not persist world IP results:', error.message);
  }
}
const priorWorldResults = readWorldResults();
let persistedWorldResults = priorWorldResults
  .filter(row => Array.isArray(row?.sources) && row.sources.some(source => /proxifly/i.test(String(source))))
  .map(row => ({ ...row, sources: ['Proxifly'], ping: row.ping?.source === 'Globalping' ? row.ping : null, pingSource: row.ping?.source === 'Globalping' ? 'Globalping' : null }));
if (persistedWorldResults.length !== priorWorldResults.length) writeWorldResults(persistedWorldResults);
function recordWorldDiscovery(data) {
  const now = new Date().toISOString();
  const incoming = [];
  for (const group of (data?.countries || [])) {
    const cc = proxyCountryCode(group?.country);
    if (!cc) continue;
    for (const row of (group?.results || [])) {
      if (!isValidIP(row?.ip) || isBlockedIP(row.ip)) continue;
      incoming.push({
        ip: row.ip,
        port: Number(row.port || row.observedPorts?.[0] || 0) || null,
        protocol: String(row.protocol || '').toLowerCase() || null,
        datacenterName: row.datacenterName || row.provider || row.asName || '',
        countryCode: cc,
        country: group.countryName || SUPPORTED_WORLD_COUNTRIES[cc]?.name || COUNTRY_CODES[cc] || cc,
        provider: row.provider || row.asName || '',
        asName: row.asName || '',
        asn: row.asn || null,
        city: row.city || '',
        lat: finiteGeo(row.lat),
        lon: finiteGeo(row.lon),
        prefix: row.prefix || '',
        confirmedPorts: Array.isArray(row.confirmedPorts) ? row.confirmedPorts.map(Number).filter(Number.isInteger) : [],
        observedPorts: Array.isArray(row.observedPorts) ? row.observedPorts.map(Number).filter(Number.isInteger) : [],
        services: Array.isArray(row.services) ? row.services.slice(0,20) : [],
        ping: row.ping || null,
        pingSource: row.ping?.source || 'Globalping',
        sources: Array.isArray(row.sources) ? row.sources.slice(0,8) : [],
        lastSeen: row.lastSeen || now,
        discoveredAt: now
      });
    }
  }
  const rowKey = row => `${row.ip}|${Number(row.port||row.observedPorts?.[0]||0)}|${String(row.protocol||'').toLowerCase()}`;
  const byIp = new Map(persistedWorldResults.map(x => [rowKey(x), x]));
  for (const row of incoming) {
    const key = rowKey(row);
    const prev = byIp.get(key);
    byIp.set(key, prev ? {
      ...prev, ...row,
      confirmedPorts: [...new Set([...(prev.confirmedPorts||[]), ...(row.confirmedPorts||[])])].sort((a,b)=>a-b),
      observedPorts: [...new Set([...(prev.observedPorts||[]), ...(row.observedPorts||[])])].sort((a,b)=>a-b),
      services: [...(prev.services||[]), ...(row.services||[])].filter(Boolean).filter((v,i,a)=>a.findIndex(x=>JSON.stringify(x)===JSON.stringify(v))===i).slice(0,20),
      ping: row.ping || prev.ping || null,
      lastSeen: row.lastSeen || prev.lastSeen || now,
      sources: ['Proxifly']
    } : row);
  }
  persistedWorldResults = [...byIp.values()].sort((a,b)=>String(a.discoveredAt).localeCompare(String(b.discoveredAt))).slice(-WORLD_RESULTS_MAX);
  writeWorldResults(persistedWorldResults);
  return incoming.length;
}
function storedResults(country='') {
  const cc = safeWorldCountryCode(country);
  return persistedWorldResults.filter(x => !cc || x.countryCode === cc);
}
function readManualScanResults(){ensureDataDir();try{const p=JSON.parse(fs.readFileSync(MANUAL_RESULTS_FILE,'utf8'));return Array.isArray(p)?p:[]}catch(_){return []}}
function writeManualScanResults(items) {
  ensureDataDir();
  const tempFile = `${MANUAL_RESULTS_FILE}.tmp`;
  try {
    fs.writeFileSync(tempFile, JSON.stringify((Array.isArray(items) ? items : []).slice(-10000), null, 2));
    fs.renameSync(tempFile, MANUAL_RESULTS_FILE);
  } catch (error) {
    try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (_) {}
    console.error('[database] Could not persist manual scan results:', error.message);
  }
}
let persistedManualScanResults=readManualScanResults();
function recordManualScanResults(job){
  const incoming=(job?.results||[]).filter(r=>isValidIP(r?.ip)).map(r=>({ip:r.ip,hostname:r.hostname||'',online:Boolean(r.online),ping:r.ping||null,openPorts:Array.isArray(r.openPorts)?r.openPorts.map(x=>({port:Number(x.port)||0,open:Boolean(x.open),state:x.state||'',latencyMs:x.latencyMs != null && x.latencyMs !== '' && Number.isFinite(Number(x.latencyMs))?Number(x.latencyMs):null})).filter(x=>x.port):[],target:job.target,source:'Authorized manual scan',discoveredAt:new Date().toISOString(),lastSeen:new Date().toISOString()}));
  const byIp=new Map(persistedManualScanResults.map(x=>[x.ip,x]));
  for(const row of incoming){const prev=byIp.get(row.ip);byIp.set(row.ip,prev?{...prev,...row,openPorts:[...new Map([...(prev.openPorts||[]),...(row.openPorts||[])].map(x=>[x.port,x])).values()]}:row)}
  persistedManualScanResults=[...byIp.values()].slice(-10000);writeManualScanResults(persistedManualScanResults);
  return incoming.length;
}

function latencyValue(row) {
  const raw = row?.ping?.avgMs ?? row?.ping?.latencyMs;
  if (raw == null || raw === '') return null;
  const x = Number(raw);
  return Number.isFinite(x) && x >= 0 ? x : null;
}
function uniqueLiveCountries(rows) { return new Set(rows.filter(r => isValidIP(r.ip)).map(r => r.countryCode).filter(Boolean)).size; }
function providerNormalized(name) { return String(name||'').trim().toLowerCase().replace(/[^a-z0-9]+/g,' '); }
function providerMatches(row, provider) {
  const want=providerNormalized(provider); if(!want) return true;
  const text=providerNormalized(`${row.provider||''} ${row.asName||''}`);
  return text.includes(want);
}
function normalizedTarget(raw) {
  const value = String(raw || '').trim().replace(/^https?:\/\//i, '');
  return value.split('/')[0].replace(/[?#].*$/, '').slice(0, MAX_TARGET_LENGTH);
}
function isIPv4(v) { return net.isIP(String(v)) === 4; }
function isIPv6(v) { return net.isIP(String(v)) === 6; }
function isValidIP(v) { return net.isIP(String(v)) !== 0; }
function ipToInt(ip) {
  if (!isIPv4(ip)) return null;
  return ip.split('.').map(Number).reduce((n, oct) => ((n * 256) + oct) >>> 0, 0);
}
function intToIPv4(value) {
  return [24, 16, 8, 0].map(shift => (value >>> shift) & 255).join('.');
}
function cidrContains(cidr, ip) {
  const [base, bitsText] = String(cidr).split('/');
  const bits = Number(bitsText);
  const a = ipToInt(base), b = ipToInt(ip);
  if (a === null || b === null || !Number.isInteger(bits) || bits < 0 || bits > 32) return false;
  const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
  return (a & mask) === (b & mask);
}
function ipv4CidrBounds(cidr) {
  const [base, bitsText] = String(cidr).split('/');
  const bits = Number(bitsText);
  const baseInt = ipToInt(base);
  if (baseInt === null || !Number.isInteger(bits) || bits < 0 || bits > 32) return null;
  const size = 2 ** (32 - bits);
  const network = bits === 0 ? 0 : (baseInt >>> (32 - bits)) * size;
  return { start: network >>> 0, end: (network + size - 1) >>> 0, bits };
}
function isPrivateIPv4(ip) {
  if (!isIPv4(ip)) return false;
  const p = ip.split('.').map(Number);
  return p[0] === 10 || p[0] === 127 || (p[0] === 169 && p[1] === 254) ||
    (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
    (p[0] === 192 && p[1] === 168) ||
    (p[0] === 100 && p[1] >= 64 && p[1] <= 127) ||
    p[0] === 0 || (p[0] === 198 && p[1] === 18) || (p[0] === 198 && p[1] === 19) ||
    (p[0] === 192 && p[1] === 0 && p[2] === 0);
}
function isBlockedIP(ip) {
  if (isIPv4(ip)) return isPrivateIPv4(ip) || ip === '255.255.255.255';
  if (isIPv6(ip)) {
    const normalized = ip.toLowerCase();
    return normalized === '::' || normalized === '::1' || normalized.startsWith('fc') || normalized.startsWith('fd') || normalized.startsWith('fe8') || normalized.startsWith('fe9') || normalized.startsWith('fea') || normalized.startsWith('feb');
  }
  return true;
}
function isBlockedHost(host) {
  // Distinguish hostnames from IP literals. isBlockedIP intentionally rejects
  // non-IP input, so calling it unconditionally here incorrectly blocked every
  // normal domain (google.com, youtube.com, etc.). Hostnames are resolved and
  // their resulting addresses are checked by safeResolvedExternalHost() before
  // any outbound request is made.
  let h = normalizedTarget(host).trim().toLowerCase();
  if (h.startsWith('[') && h.endsWith(']')) h = h.slice(1, -1);
  if (!h || h.length > MAX_TARGET_LENGTH) return true;
  if (PRIVATE_HOST_RE.test(h) || /\.(?:localhost|local|internal|test|invalid|example)$/i.test(h)) return true;
  if (net.isIP(h)) return isBlockedIP(h);
  // Accept syntactically valid DNS names only; DNS resolution is separately
  // checked to ensure the destination does not resolve to a private address.
  const dnsName = h.endsWith('.') ? h.slice(0, -1) : h;
  if (!dnsName || dnsName.length > 253) return true;
  const labels = dnsName.split('.');
  if (labels.some(label => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(label))) return true;
  return false;
}
function targetMatchesAllowlist(target) {
  const value = normalizedTarget(target).toLowerCase();
  if (!value) return false;
  return SCAN_ALLOWED_TARGETS.some(rule => rule === value || (rule.includes('/') && cidrContains(rule, value)));
}
function scanAuthorized(target) {
  return SCAN_ALLOWED_TARGETS.length > 0 && targetMatchesAllowlist(target);
}
function rangeWithinAllowlist(startIp, endIp) {
  const s = ipToInt(startIp), e = ipToInt(endIp);
  if (s === null || e === null || e < s) return false;
  return SCAN_ALLOWED_TARGETS.some(rule => {
    const bounds = ipv4CidrBounds(rule);
    if (bounds) return s >= bounds.start && e <= bounds.end;
    return isIPv4(rule) && s === e && rule === startIp;
  });
}
function parsePorts(raw, profile = 'common') {
  const source = String(raw || '').trim();
  const values = source ? source.split(',').flatMap(part => {
    const p = part.trim();
    if (!p) return [];
    if (/^\d+$/.test(p)) return [Number(p)];
    const m = p.match(/^(\d+)\s*-\s*(\d+)$/);
    if (!m) return [];
    const a = Number(m[1]), b = Number(m[2]);
    if (b < a || b - a > MAX_SCAN_PORTS - 1) return [];
    return Array.from({ length: b - a + 1 }, (_, i) => a + i);
  }) : [...(SCAN_PROFILES[profile]?.ports || SCAN_PROFILES.common.ports)];
  const unique = [...new Set(values)].filter(p => Number.isInteger(p) && p >= 1 && p <= 65535);
  return unique.slice(0, MAX_SCAN_PORTS);
}
function parseIPv4Spec(raw) {
  const value = String(raw || '').trim();
  const exact = value.match(/^((?:\d{1,3}\.){3}\d{1,3})$/);
  if (exact && isIPv4(exact[1])) return { type: 'ip', start: exact[1], end: exact[1], count: 1 };
  const cidr = ipv4CidrBounds(value);
  if (cidr) {
    return { type: 'range', start: intToIPv4(cidr.start), end: intToIPv4(cidr.end), count: cidr.end - cidr.start + 1 };
  }
  const range = value.match(/^((?:\d{1,3}\.){3}\d{1,3})\s*-\s*((?:\d{1,3}\.){3}\d{1,3})$/);
  if (range && isIPv4(range[1]) && isIPv4(range[2])) {
    const a = ipToInt(range[1]), b = ipToInt(range[2]);
    if (b < a) return null;
    return { type: 'range', start: range[1], end: range[2], count: b - a + 1 };
  }
  return null;
}
function expandRange(start, end, max = MAX_SCAN_HOSTS) {
  const a = ipToInt(start), b = ipToInt(end);
  if (a === null || b === null || b < a || b - a + 1 > max) return [];
  return Array.from({ length: b - a + 1 }, (_, i) => intToIPv4((a + i) >>> 0));
}
function clientIp(req) {
  // Prefer the real client address supplied by the production reverse proxy
  // (Cloudflare first), then standard proxy headers, then Express/socket data.
  const candidates = [
    req.headers['cf-connecting-ip'],
    req.headers['true-client-ip'],
    req.headers['x-real-ip'],
    req.headers['x-client-ip'],
    (() => { const f=String(req.headers['forwarded']||''); const m=f.match(/(?:^|;)\s*for=\"?([^;\"]+)\"?/i); return m ? m[1].replace(/^\[|\]$/g,'') : ''; })(),
    String(req.headers['x-forwarded-for'] || '').split(',')[0].trim(),
    req.ip,
    req.socket?.remoteAddress
  ];
  for (const candidate of candidates) {
    const ip = String(candidate || '').trim().replace(/^::ffff:/, '');
    if (net.isIP(ip)) return ip;
  }
  return '';
}
function rateLimit(req, res, next) {
  const key = clientIp(req) || 'unknown';
  const now = Date.now();
  const arr = rateMap.get(key) || [];
  const fresh = arr.filter(t => now - t < 60000);
  if (fresh.length >= 60) return res.status(429).json({ ok: false, error: 'Rate limit reached. Try again in a minute.' });
  fresh.push(now);
  rateMap.set(key, fresh);
  next();
}
app.use('/api', rateLimit);
app.use((req, res, next) => {
  counters.requests++;
  const t = Date.now();
  res.on('finish', () => {
    requestTimes.push(Date.now() - t);
    requestTimes.splice(200);
    if (res.statusCode < 400) counters.success++; else counters.errors++;
  });
  next();
});

function jsonError(res, message, status = 400) { return res.status(status).json({ ok: false, error: message }); }
async function withTimeout(promise, ms, label = 'Operation timed out') {
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(label)), ms); });
  try { return await Promise.race([promise, timeout]); } finally { clearTimeout(timer); }
}
async function fetchText(url, opts = {}, timeout = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  const upstreamSignal = opts.signal;
  try {
    if (upstreamSignal) {
      if (upstreamSignal.aborted) controller.abort(upstreamSignal.reason);
      else upstreamSignal.addEventListener('abort', () => controller.abort(upstreamSignal.reason), { once: true });
    }
    const fetchOpts = { redirect: 'follow', ...opts, signal: controller.signal };
    if (fetchOpts.body && typeof fetchOpts.body === 'object' && !(fetchOpts.body instanceof ArrayBuffer) && !(typeof Blob !== 'undefined' && fetchOpts.body instanceof Blob) && !Buffer.isBuffer(fetchOpts.body) && !(fetchOpts.body instanceof URLSearchParams)) {
      fetchOpts.body = JSON.stringify(fetchOpts.body);
      const headers = new Headers(fetchOpts.headers || {});
      if (!headers.has('content-type')) headers.set('content-type','application/json');
      fetchOpts.headers = headers;
    }
    return await fetch(url, fetchOpts);
  } catch (e) {
    if (e?.name === 'AbortError') throw new Error('Request timed out');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
async function resolveAllAddresses(host) {
  if (isValidIP(host)) return [{ address: host, family: net.isIP(host) }];
  const addresses = await dns.lookup(host, { all: true, verbatim: true });
  return [...new Map(addresses.map(x => [x.address, x])).values()];
}
async function reverseDns(ip) {
  try { return (await dns.reverse(ip))[0] || null; } catch (_) { return null; }
}
async function getNeighborMac(ip) {
  if (!isIPv4(ip)) return null;
  const commands = os.platform() === 'win32'
    ? [['arp', ['-a', ip]]]
    : [['ip', ['neigh', 'show', ip]], ['arp', ['-n', ip]]];
  for (const [command, args] of commands) {
    try {
      const { stdout } = await execFileAsync(command, args, { timeout: 1200, windowsHide: true, maxBuffer: 16 * 1024 });
      const match = String(stdout).match(/\b([0-9a-f]{2}[:-]){5}[0-9a-f]{2}\b/i);
      if (match) return match[0].replace(/-/g, ':').toUpperCase();
    } catch (_) {}
  }
  return null;
}
async function macVendor(mac) {
  if (!mac) return null;
  try {
    const r = await fetchText(`https://api.macvendors.com/${encodeURIComponent(mac)}`, { headers: { accept: 'text/plain' } }, 4500);
    if (!r.ok) return null;
    return (await r.text()).trim() || null;
  } catch (_) { return null; }
}

function tcpCheck(host, port, timeout = DEFAULT_TCP_TIMEOUT) {
  return new Promise(resolve => {
    const socket = net.createConnection({ host, port });
    const started = Date.now();
    let done = false;
    const finish = result => {
      if (done) return;
      done = true;
      try { socket.destroy(); } catch (_) {}
      resolve(result);
    };
    socket.setTimeout(timeout);
    socket.on('connect', () => finish({ open: true, state: 'open', latencyMs: Date.now() - started }));
    socket.on('timeout', () => finish({ open: false, state: 'filtered', latencyMs: Date.now() - started, error: 'timeout' }));
    socket.on('error', err => {
      const state = err?.code === 'ECONNREFUSED' ? 'closed' : (['ETIMEDOUT','EHOSTUNREACH','ENETUNREACH'].includes(err?.code) ? 'filtered' : 'error');
      finish({ open: false, state, latencyMs: Date.now() - started, error: err.code || err.message });
    });
  });
}
async function probeBanner(host, port, timeout = 1400) {
  return new Promise(resolve => {
    const socket = net.createConnection({ host, port });
    let data = '';
    let finished = false;
    const finish = banner => {
      if (finished) return;
      finished = true;
      try { socket.destroy(); } catch (_) {}
      resolve(banner || null);
    };
    socket.setTimeout(timeout);
    socket.on('data', chunk => {
      data += chunk.toString('utf8');
      if (data.length >= 512) finish(data.slice(0, 512));
    });
    socket.on('connect', () => {
      if ([25, 587].includes(port)) {
        try { socket.write('EHLO mahdiar.local\r\n'); } catch (_) {}
      }
    });
    socket.on('timeout', () => finish(data.slice(0, 512)));
    socket.on('end', () => finish(data.slice(0, 512)));
    socket.on('error', () => finish(data.slice(0, 512)));
  });
}
async function httpProbe(host, port) {
  const scheme = port === 443 || port === 8443 ? 'https' : 'http';
  const url = `${scheme}://${host}:${port}/`;
  const start = Date.now();
  try {
    const r = await fetchText(url, {
      method: 'GET',
      headers: { 'user-agent': 'Mahdiar-Scanner/5.0', accept: 'text/html,text/plain;q=0.8,*/*;q=0.2' },
      signal: AbortSignal.timeout(5000)
    }, 5500);
    const type = String(r.headers.get('content-type') || '');
    let title = null;
    if (/text\/html/i.test(type)) {
      const body = await withTimeout(r.text(), 3500, 'Body read timed out');
      const match = body.match(/<title[^>]*>([^<]{1,160})<\/title>/i);
      title = match ? match[1].replace(/\s+/g, ' ').trim() : null;
    }
    return { ok: true, status: r.status, statusText: r.statusText, url: r.url, latencyMs: Date.now() - start, title, contentType: type, server: r.headers.get('server') || null, poweredBy: r.headers.get('x-powered-by') || null };
  } catch (e) {
    return { ok: false, error: e.message, latencyMs: Date.now() - start };
  }
}
async function tlsProbe(host, port, address = host) {
  return new Promise(resolve => {
    const socket = tls.connect({ host: address, port, servername: host, rejectUnauthorized: false });
    const started = Date.now();
    let done = false;
    const finish = result => {
      if (done) return;
      done = true;
      try { socket.end(); socket.destroy(); } catch (_) {}
      resolve(result);
    };
    socket.setTimeout(5500);
    socket.on('secureConnect', () => {
      const c = socket.getPeerCertificate(true) || {};
      const validTo = c.valid_to ? Date.parse(c.valid_to) : null;
      const validFrom = c.valid_from ? Date.parse(c.valid_from) : null;
      finish({
        ok: true,
        latencyMs: Date.now() - started,
        tlsVersion: socket.getProtocol() || null,
        cipher: socket.getCipher()?.name || null,
        authorized: socket.authorized,
        authorizationError: socket.authorizationError || null,
        subject: c.subject || null,
        issuer: c.issuer || null,
        validFrom,
        validTo,
        daysLeft: validTo ? Math.floor((validTo - Date.now()) / 86400000) : null,
        serialNumber: c.serialNumber || '',
        fingerprint256: c.fingerprint256 || '',
        subjectAltName: c.subjectaltname || ''
      });
    });
    socket.on('timeout', () => finish({ ok: false, error: 'timeout' }));
    socket.on('error', e => finish({ ok: false, error: e.code || e.message }));
  });
}
async function pingHost(host, timeoutMs = 1200) {
  // All ping measurements in this project must use Globalping only.
  try {
    const result = await globalWorldPing(host, ['DE', 'FR', 'NL']);
    const latencyMs = Number.isFinite(Number(result?.avgMs)) ? Number(result.avgMs) : null;
    return {
      online: Boolean(result?.ok && latencyMs != null),
      latencyMs,
      method: 'Globalping',
      source: 'Globalping',
      details: result || null,
      error: result?.ok ? null : (result?.error || 'No usable Globalping result.')
    };
  } catch (error) {
    return { online: false, latencyMs: null, method: 'Globalping', source: 'Globalping', error: String(error?.message || error) };
  }
}

async function traceRouteHost(host) {
  const candidates = [
    ['mtr', ['-r', '-n', '-c', '4', '-w', host]],
    ['traceroute', ['-n', '-m', '12', '-w', '1', host]],
    ['tracepath', ['-n', host]]
  ];
  for (const [command, args] of candidates) {
    try {
      const { stdout } = await execFileAsync(command, args, { timeout: 16000, maxBuffer: 128 * 1024, windowsHide: true });
      const lines = String(stdout || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean);
      const hops = [];
      for (const line of lines) {
        const hop = line.match(/^(\d+)\.?\s+(?:\?\s*)?(?:(\d{1,3}(?:\.\d{1,3}){3})\s+)?(?:<?)([0-9.]+)\s*ms/i);
        if (hop) hops.push({ hop: Number(hop[1]), ip: hop[2] || null, latencyMs: Number(hop[3]) });
        else {
          const simple = line.match(/^(\d+)\s+.*?(\d{1,3}(?:\.\d{1,3}){3}).*?(\d+(?:\.\d+)?)\s*ms/i);
          if (simple) hops.push({ hop: Number(simple[1]), ip: simple[2], latencyMs: Number(simple[3]) });
        }
      }
      return { ok: true, command, hops, raw: lines.slice(0, 80).join('\n') };
    } catch (e) {
      if (!['ENOENT','EACCES'].includes(e?.code)) continue;
    }
  }
  return { ok: false, error: 'MTR/traceroute is not available on this server.' };
}

async function scanOneHost(ip, ports, options = {}) {
  const started = Date.now();
  const [reverse, ping] = await Promise.all([reverseDns(ip), pingHost(ip, options.pingTimeout || 1200)]);
  let probes;
  if (options.pingOnly) probes = [];
  else probes = await runLimited(ports, Math.min(SCAN_PORT_CONCURRENCY, 12), p => tcpCheck(ip, p, options.portTimeout || 2200).then(r => ({ port: p, service: SERVICE_MAP[p] || 'Unknown', ...r })));
  probes.sort((a, b) => a.port - b.port);
  const open = probes.filter(x => x.open);
  const measuredPing = ping; // Never substitute TCP latency for a Globalping measurement.
  const bannerTargets = open.filter(x => [21, 22, 23, 25, 110, 143, 587].includes(x.port)).slice(0, 4);
  const banners = await Promise.all(bannerTargets.map(async x => ({ port: x.port, banner: await probeBanner(ip, x.port) })));
  const webPorts = open.filter(x => [80, 443, 3000, 5000, 8000, 8008, 8080, 8081, 8443, 8888].includes(x.port)).slice(0, 4);
  const http = await Promise.all(webPorts.map(async x => ({ port: x.port, details: await httpProbe(ip, x.port) })));
  const tlsPorts = open.filter(x => [443, 8443].includes(x.port)).slice(0, 2);
  const tlsInfo = await Promise.all(tlsPorts.map(async x => ({ port: x.port, details: await tlsProbe(ip, x.port) })));
  const mac = await getNeighborMac(ip);
  const vendor = await macVendor(mac);
  const hostOnline = ping.online || open.length > 0;
  return {
    ip,
    hostname: reverse,
    mac,
    vendor,
    online: hostOnline,
    ping: measuredPing,
    openPorts: open,
    totalPortsChecked: probes.length,
    banners,
    http,
    tls: tlsInfo,
    elapsedMs: Date.now() - started
  };
}
async function runLimited(items, concurrency, fn, onProgress) {
  const results = [];
  let cursor = 0;
  const worker = async () => {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      results[index] = await fn(items[index], index);
      if (onProgress) onProgress(index + 1, items.length, results[index]);
    }
  };
  const count = Math.min(concurrency, Math.max(items.length, 1));
  await Promise.all(Array.from({ length: count }, worker));
  return results;
}
async function resolveScanTargets(target) {
  const range = parseIPv4Spec(target);
  if (range) {
    if (range.count > MAX_SCAN_HOSTS) throw new Error(`Scan range is too large. Maximum is ${MAX_SCAN_HOSTS} IPv4 addresses.`);
    if (!rangeWithinAllowlist(range.start, range.end)) throw Object.assign(new Error('This IP range is not fully covered by the optional SCAN_ALLOWED_TARGETS allowlist.'), { statusCode: 403 });
    return { kind: 'range', addresses: expandRange(range.start, range.end) };
  }
  if (!scanAuthorized(target)) throw Object.assign(new Error('Target is not in the optional SCAN_ALLOWED_TARGETS allowlist.'), { statusCode: 403 });
  const addresses = await resolveAllAddresses(target);
  const allowed = addresses.filter(x => isIPv4(x.address) ? targetMatchesAllowlist(x.address) || scanAuthorized(target) : scanAuthorized(target));
  if (!allowed.length) throw Object.assign(new Error('Resolved address is not authorized by the optional allowlist.'), { statusCode: 403 });
  return { kind: 'host', addresses: allowed.map(x => x.address) };
}
function publicJob(job) {
  return JSON.parse(JSON.stringify(job));
}
function activeJobCount() { return [...scanJobs.values()].filter(j => ['queued', 'running'].includes(j.status)).length; }
async function executeScanJob(job) {
  try {
    job.status = 'running';
    job.startedAt = new Date().toISOString();
    job.phase = 'Resolving target';
    const resolved = await resolveScanTargets(job.target);
    job.addresses = resolved.addresses;
    job.totalHosts = resolved.addresses.length;
    job.progress = 4;
    job.phase = 'Checking hosts';
    const rows = await runLimited(resolved.addresses, Math.min(SCAN_HOST_CONCURRENCY, 32), ip => scanOneHost(ip, job.ports, job.options), (done, total) => {
      job.progress = Math.min(88, 4 + Math.round((done / total) * 84));
      job.completedHosts = done;
    });
    job.phase = 'Finalizing';
    const uniqueMacs = [...new Set(rows.map(x => x.mac).filter(Boolean))];
    job.results = rows;
    job.summary = {
      found: rows.length,
      online: rows.filter(x => x.online).length,
      offline: rows.filter(x => !x.online).length,
      openPorts: rows.reduce((n, x) => n + x.openPorts.length, 0),
      uniqueMacs: uniqueMacs.length,
      webServices: rows.reduce((n, x) => n + x.http.filter(h => h.details?.ok).length, 0),
      tlsServices: rows.reduce((n, x) => n + x.tls.filter(h => h.details?.ok).length, 0),
      avgLatencyMs: (() => { const values = rows.map(x => x.ping?.latencyMs).filter(Number.isFinite); return values.length ? Math.round(values.reduce((a,b)=>a+b,0)/values.length) : null; })(),
      serviceCounts: rows.flatMap(x => x.openPorts || []).reduce((map, p) => { const key = p.service || `Port ${p.port}`; map[key] = (map[key] || 0) + 1; return map; }, {}),
      durationMs: Date.now() - new Date(job.createdAt).getTime()
    };
    job.progress = 100;
    job.phase = 'Done';
    job.status = 'done';
    job.finishedAt = new Date().toISOString();
    recordManualScanResults(job);
    saveEvent('network-scan', job.target, true, `${job.summary.online} online / ${job.summary.openPorts} open ports`);
  } catch (e) {
    job.status = 'error';
    job.error = e.message;
    job.errorStatus = e.statusCode || 500;
    job.finishedAt = new Date().toISOString();
    saveEvent('network-scan', job.target, false, e.message);
  }
}
setInterval(() => {
  const cutoff = Date.now() - 15 * 60 * 1000;
  for (const [id, job] of scanJobs) {
    if (new Date(job.createdAt).getTime() < cutoff && ['done', 'error'].includes(job.status)) scanJobs.delete(id);
  }
}, 60 * 1000).unref();

// Public world-discovery helpers. This path does not require SCAN_ALLOWED_TARGETS.
// Active target/range scanning remains separately protected by the optional allowlist.
const CHECK_HOST_BASE = String(process.env.CHECK_HOST_BASE || 'https://api.check-host.cc').replace(/\/$/, '');
const SHODAN_BASE = String(process.env.SHODAN_BASE_URL || 'https://api.shodan.io').replace(/\/$/, '');
const NETLAS_BASE = String(process.env.NETLAS_BASE_URL || 'https://app.netlas.io/api').replace(/\/$/, '');
const ZOOMEYE_BASE = String(process.env.ZOOMEYE_API_BASE_URL || 'https://api.zoomeye.ai').replace(/\/$/, '');
const CENSYS_BASE = String(process.env.CENSYS_API_BASE_URL || 'https://api.platform.censys.io').replace(/\/$/, '');
const CENSYS_ORGANIZATION_ID = String(process.env.CENSYS_ORGANIZATION_ID || '').trim();
const TAVILY_BASE = String(process.env.TAVILY_BASE_URL || 'https://api.tavily.com').replace(/\/$/, '');
const TELEGRAM_API_BASE = String(process.env.TELEGRAM_API_BASE_URL || 'https://api.telegram.org').replace(/\/$/, '');
const SPEEDTEST_TIMEOUT_MS = Math.min(Math.max(Number(process.env.SPEEDTEST_TIMEOUT_MS || 90000), 30000), 180000);
const SPEEDTEST_CACHE_TTL = Math.min(Math.max(Number(process.env.SPEEDTEST_CACHE_TTL_MS || 60000), 10000), 300000);
const WORLD_PING_PER_COUNTRY = Math.min(Math.max(Number(process.env.WORLD_PING_PER_COUNTRY || 1), 1), 3);
const TELEGRAM_SETUP_KEY = String(process.env.TELEGRAM_SETUP_KEY || '').trim();
const TELEGRAM_BOT_TOKEN = String(process.env.TELEGRAM_BOT_TOKEN || '').trim();
const TELEGRAM_CONFIG_FILE = path.join(__dirname, 'data', 'telegram.json');
const APP_PUBLIC_URL = String(process.env.APP_PUBLIC_URL || '').trim();
const GLOBALPING_BASE = String(process.env.GLOBALPING_BASE_URL || 'https://api.globalping.io/v1').replace(/\/$/, '');
// Proxifly publishes frequently refreshed TXT files split by protocol and country.
const PROXIFLY_SOURCE_BASE_URL = String(process.env.PROXIFLY_SOURCE_BASE_URL || 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main').replace(/\/$/, '').trim();
const PROXIFLY_JSON_URL = `${PROXIFLY_SOURCE_BASE_URL}/proxies/all/data.json`;
// Persistent last-known-good snapshot: successful live downloads replace this file atomically.
const PROXIFLY_LOCAL_JSON_FILE = path.join(__dirname, 'data', 'proxifly-data.json');
const PROXIFLY_JSON_MAX_BYTES = 25 * 1024 * 1024;
const PROXIFLY_FETCH_TIMEOUT_MS = Math.min(Math.max(Number(process.env.PROXIFLY_FETCH_TIMEOUT_MS || 15000), 5000), 60000);
const PROXIFLY_JSON_CACHE_TTL = Math.min(Math.max(Number(process.env.PROXIFLY_JSON_CACHE_TTL_MS || 240000), 30000), 600000);
const PROXIFLY_PING_CACHE_TTL = Math.min(Math.max(Number(process.env.PROXIFLY_PING_CACHE_TTL_MS || 900000), 60000), 3600000);
let proxiflyJsonCache = { at: 0, fetchedAt: null, rows: [], sourceMode: null, localSnapshotAvailable: false };
let proxiflyJsonInFlight = null;
const proxiflyScanCache = new Map();
const proxiflyScanInFlight = new Map();
const PROXIFLY_PROTOCOLS = new Set(['http', 'https', 'socks4', 'socks5']);
let netlasQuotaBlockedUntil = 0;
let netlasQuotaBlockReason = '';
let netlasQuotaNoticeEmitted = false;
const GITHUB_API_BASE = String(process.env.GITHUB_API_BASE_URL || 'https://api.github.com').replace(/\/$/, '');
const GITHUB_LIVE_REPO = String(process.env.GITHUB_LIVE_REPO || 'proxyscrape/free-proxy-list').trim();
const GITHUB_TOKEN = String(process.env.GITHUB_TOKEN || '').trim();
const GLOBALPING_API_KEY = String(process.env.GLOBALPING_API_KEY || '').trim();
const GLOBALPING_TIMEOUT_MS = Math.min(Math.max(Number(process.env.GLOBALPING_TIMEOUT_MS || 45000), 15000), 90000);
const PROXY_CACHE_TTL = Math.min(Math.max(Number(process.env.PROXY_CACHE_TTL_MS || 60000), 15000), 300000);
const globalPingCache = new Map();
const proxyCache = new Map();
const CONNECTIVITY_HTTP_CACHE_TTL_MS = Math.min(Math.max(Number(process.env.CONNECTIVITY_HTTP_CACHE_TTL_MS || 300000), 60000), 900000);
const CONNECTIVITY_UPSTREAM_MAX_PER_HOUR = Math.min(Math.max(Number(process.env.CONNECTIVITY_UPSTREAM_MAX_PER_HOUR || 180), 25), 225);
const connectivityHttpCache = new Map();
const connectivityHttpInFlight = new Map();
const connectivityHttpRateTimes = [];

console.log(`[config] proxy-inventory=Proxifly-JSON ping=Globalping legacy-discovery=disabled Telegram=${Boolean(TELEGRAM_BOT_TOKEN)}`);
const SUPPORTED_WORLD_COUNTRIES = {
  TR: { name: 'Turkey', fa: 'ترکیه', lat: 38.9637, lon: 35.2433 },
  FR: { name: 'France', fa: 'فرانسه', lat: 46.2276, lon: 2.2137 },
  DE: { name: 'Germany', fa: 'آلمان', lat: 51.1657, lon: 10.4515 },
  US: { name: 'United States', fa: 'آمریکا', lat: 37.0902, lon: -95.7129 },
  NL: { name: 'Netherlands', fa: 'هلند', lat: 52.1326, lon: 5.2913 },
  GB: { name: 'United Kingdom', fa: 'انگلستان', lat: 55.3781, lon: -3.4360 },
  AE: { name: 'United Arab Emirates', fa: 'امارات', lat: 23.4241, lon: 53.8478 },
  CH: { name: 'Switzerland', fa: 'سوئیس', lat: 46.8182, lon: 8.2275 },
  CA: { name: 'Canada', fa: 'کانادا', lat: 56.1304, lon: -106.3468 },
  IR: { name: 'Iran', fa: 'ایران', lat: 32.4279, lon: 53.6880 },
  JP: { name: 'Japan', fa: 'ژاپن', lat: 36.2048, lon: 138.2529 },
  SG: { name: 'Singapore', fa: 'سنگاپور', lat: 1.3521, lon: 103.8198 },
  AU: { name: 'Australia', fa: 'استرالیا', lat: -25.2744, lon: 133.7751 },
  IN: { name: 'India', fa: 'هند', lat: 20.5937, lon: 78.9629 },
  PL: { name: 'Poland', fa: 'لهستان', lat: 51.9194, lon: 19.1451 },
  ES: { name: 'Spain', fa: 'اسپانیا', lat: 40.4637, lon: -3.7492 },
  IT: { name: 'Italy', fa: 'ایتالیا', lat: 41.8719, lon: 12.5674 },
  SE: { name: 'Sweden', fa: 'سوئد', lat: 60.1282, lon: 18.6435 },
  NO: { name: 'Norway', fa: 'نروژ', lat: 60.4720, lon: 8.4689 },
  FI: { name: 'Finland', fa: 'فنلاند', lat: 61.9241, lon: 25.7482 },
  AT: { name: 'Austria', fa: 'اتریش', lat: 47.5162, lon: 14.5501 },
  BE: { name: 'Belgium', fa: 'بلژیک', lat: 50.5039, lon: 4.4699 },
  RU: { name: 'Russia', fa: 'روسیه', lat: 61.5240, lon: 105.3188 },
  BR: { name: 'Brazil', fa: 'برزیل', lat: -14.2350, lon: -51.9253 },
  MX: { name: 'Mexico', fa: 'مکزیک', lat: 23.6345, lon: -102.5528 },
  HK: { name: 'Hong Kong', fa: 'هنگ‌کنگ', lat: 22.3193, lon: 114.1694 },
  KR: { name: 'South Korea', fa: 'کره جنوبی', lat: 35.9078, lon: 127.7669 },
  IL: { name: 'Israel', fa: 'اسرائیل', lat: 31.0461, lon: 34.8516 },
  SA: { name: 'Saudi Arabia', fa: 'عربستان سعودی', lat: 23.8859, lon: 45.0792 },
  ZA: { name: 'South Africa', fa: 'آفریقای جنوبی', lat: -30.5595, lon: 22.9375 },
  EG: { name: 'Egypt', fa: 'مصر', lat: 26.8206, lon: 30.8025 },
  PT: { name: 'Portugal', fa: 'پرتغال', lat: 39.3999, lon: -8.2245 },
  CZ: { name: 'Czechia', fa: 'جمهوری چک', lat: 49.8175, lon: 15.4730 },
  RO: { name: 'Romania', fa: 'رومانی', lat: 45.9432, lon: 24.9668 }
};
const DEFAULT_SELECTED_WORLD_COUNTRIES = ['TR','FR','DE','US','NL','GB','AE','CH','CA','IR','FI','ES'];
const WORLD_COUNTRY_CODES = DEFAULT_SELECTED_WORLD_COUNTRIES.slice();
const WORLD_RESULTS_MAX = Math.min(Math.max(Number(process.env.WORLD_RESULTS_MAX || 50000), 5000), 100000);
const AUTO_DISCOVERY_DEFAULT_ENABLED = false;
const MANUAL_RESULTS_FILE = path.join(__dirname, 'data', 'manual-scan-results.json');
const AUTO_DISCOVERY_RUNS_PER_DAY = 32;
const AUTO_DISCOVERY_COUNTRIES_PER_RUN = Math.min(Math.max(Number(process.env.AUTO_DISCOVERY_COUNTRIES_PER_RUN || 1), 1), 1);
const AUTO_DISCOVERY_SIZE_PER_COUNTRY = Math.min(Math.max(Number(process.env.AUTO_DISCOVERY_SIZE_PER_COUNTRY || 50), 20), 80);
const AUTO_DISCOVERY_PROBE_PER_COUNTRY = Math.min(Math.max(Number(process.env.AUTO_DISCOVERY_PROBE_PER_COUNTRY || 4), 0), 8);

const WORLD_PORT_FILTERS = [80,443,8080,2053,2082,2083,2086,2087,2095,2096,8443,8880,8000,8008,8081,8888,3000,5000,53,22];
const WORLD_DISCOVERY_CONCURRENCY = 2;
const WORLD_DISCOVERY_PER_COUNTRY = Math.min(Math.max(Number(process.env.WORLD_DISCOVERY_PER_COUNTRY || 4), 2), 8);
const WORLD_ENRICH_PER_COUNTRY = 3;
const WORLD_DISCOVERY_CACHE_TTL = 15 * 60 * 1000;
const WORLD_PROVIDER_WORDS = [
  'amazon', 'aws', 'google cloud', 'microsoft', 'azure', 'ovh', 'hetzner', 'digitalocean',
  'vultr', 'linode', 'akamai', 'leaseweb', 'contabo', 'equinix', 'oracle', 'alibaba',
  'tencent', 'ionos', 'scaleway', 'upcloud', 'rackspace', 'kamatera', 'phoenixnap',
  'choopa', 'cloud', 'hosting', 'host', 'datacenter', 'data center', 'server', 'colo'
];
const DATACENTER_PROVIDERS_BY_COUNTRY = {
  TR: ['Turk Telekom','Turkcell','Radore','Equinix','Leaseweb','Vodafone Turkey','Millenicom','KoçSistem'],
  FR: ['OVHcloud','Scaleway','Online.net','Leaseweb','Equinix','Orange','Iliad','Data4','Gandi'],
  DE: ['Hetzner','IONOS','Contabo','Leaseweb','OVHcloud','Equinix','netcup','PlusServer','dogado'],
  US: ['Amazon Web Services','Google Cloud','Microsoft Azure','DigitalOcean, LLC','Vultr','Akamai','Equinix','Oracle Cloud','Linode','PhoenixNAP','Liquid Web','Rackspace'],
  NL: ['WorldStream','Leaseweb','DigitalOcean, LLC','Equinix','NForce','Vultr','Akamai','Serverius','i3D.net','TransIP','Argeweb'],
  GB: ['OVHcloud','Amazon Web Services','Microsoft Azure','DigitalOcean, LLC','Leaseweb','Equinix','iomart','Pulsant','Fasthosts','Linode'],
  AE: ['Amazon Web Services','Microsoft Azure','Oracle Cloud','Equinix','Khazna','e&','du','Gulf Data Hub'],
  CH: ['Infomaniak','Exoscale','Equinix','Amazon Web Services','Oracle Cloud','Swisscom','Green.ch','Data4'],
  CA: ['OVHcloud','Amazon Web Services','Microsoft Azure','Google Cloud','DigitalOcean, LLC','Equinix','Cologix','Bell Canada','Rogers','Canadian Web Hosting'],
  IR: ['AbrArvan','ParsPack','Iran Telecommunication Company','Asiatech','Fanavaran Nicsepehr','Saman System','MobinNet','Respina','TIC Data Center'],
  JP: ['Amazon Web Services','Microsoft Azure','Google Cloud','Sakura Internet','Vultr','Equinix'],
  SG: ['Amazon Web Services','Microsoft Azure','Google Cloud','DigitalOcean, LLC','Equinix','Vultr'],
  AU: ['Amazon Web Services','Microsoft Azure','Google Cloud','Equinix','Vultr'],
  IN: ['Amazon Web Services','Microsoft Azure','Google Cloud','DigitalOcean, LLC','NTT'],
  PL: ['OVHcloud','Hetzner','Atman','Beyond.pl','Equinix'],
  ES: ['OVHcloud','Amazon Web Services','Microsoft Azure','Equinix','DigitalOcean, LLC'],
  IT: ['Aruba','Amazon Web Services','Microsoft Azure','OVHcloud','Equinix'],
  SE: ['Bahnhof','GleSYS','Amazon Web Services','Microsoft Azure','Equinix'],
  NO: ['Green Mountain','DigiPlex','Amazon Web Services','Microsoft Azure','Equinix'],
  FI: ['Hetzner','UpCloud','Equinix','Amazon Web Services','Google Cloud'],
  AT: ['A1 Telekom Austria','Digital Realty','Equinix','Amazon Web Services','Microsoft Azure'],
  BE: ['OVHcloud','Combell','Equinix','Amazon Web Services','DigitalOcean, LLC'],
  RU: ['Selectel','Yandex Cloud','VK Cloud','Rostelecom','DataLine'],
  BR: ['Amazon Web Services','Microsoft Azure','Google Cloud','Equinix','Ascenty'],
  MX: ['Amazon Web Services','Google Cloud','KIO Networks','Microsoft Azure','Equinix'],
  HK: ['Amazon Web Services','Microsoft Azure','Google Cloud','Equinix','PCCW'],
  KR: ['Amazon Web Services','Microsoft Azure','Google Cloud','KT','NAVER Cloud'],
  IL: ['Amazon Web Services','Google Cloud','Microsoft Azure','Bezeq','Equinix'],
  SA: ['STC','Amazon Web Services','Oracle Cloud','Microsoft Azure','Alibaba Cloud'],
  ZA: ['Amazon Web Services','Microsoft Azure','Teraco','Dimension Data','Equinix'],
  EG: ['Telecom Egypt','Raya','Amazon Web Services','Orange','Equinix'],
  PT: ['Altice Portugal','Colt','Amazon Web Services','Equinix','OVHcloud'],
  CZ: ['Master Internet','VSHosting','O2 Czech Republic','OVHcloud','Equinix'],
  RO: ['NXDATA','GTS Telecom','Hosterion','OVHcloud','Telekom Romania']
};


// Provider search aliases. These are only search targets for live passive sources;
// the scanner never invents IPs for a provider.
const DATACENTER_PROVIDER_SEARCH = {
  'Hetzner':['hetzner'], 'OVHcloud':['ovh','ovhcloud'], 'WorldStream':['worldstream'],
  'Turk Telekom':['turk telekom','ttnet'], 'Turkcell':['turkcell'], 'Radore':['radore'],
  'Leaseweb':['leaseweb'], 'Scaleway':['scaleway'], 'Online.net':['online.net','online s.a.s'], 'Orange':['orange'], 'Iliad':['iliad','scaleway'], 'Data4':['data4'], 'Gandi':['gandi'], 'IONOS':['ionos'],
  'Contabo':['contabo'], 'netcup':['netcup'], 'PlusServer':['plusserver'], 'dogado':['dogado'], 'Equinix':['equinix'], 'Amazon Web Services':['amazon','aws'],
  'Google Cloud':['google cloud','google'], 'Microsoft Azure':['microsoft','azure'], 'Linode':['linode','akamai'], 'PhoenixNAP':['phoenixnap'], 'Liquid Web':['liquid web'], 'Rackspace':['rackspace'],
  'DigitalOcean, LLC':['digitalocean','digital ocean'], 'Vultr':['vultr'], 'Akamai':['akamai'],
  'Oracle Cloud':['oracle'], 'Infomaniak':['infomaniak'], 'Exoscale':['exoscale'],
  'Sakura Internet':['sakura','sakura internet'], 'UpCloud':['upcloud'], 'GleSYS':['glesys'],
  'Bahnhof':['bahnhof'], 'Green Mountain':['green mountain'], 'DigiPlex':['digiplex'],
  'Atman':['atman'], 'Beyond.pl':['beyond.pl'], 'Aruba':['aruba'], 'Ascenty':['ascenty'],
  'NForce':['nforce'], 'Serverius':['serverius'], 'i3D.net':['i3d','i3d.net'], 'TransIP':['transip'], 'Argeweb':['argeweb'], 'KIO Networks':['kio','kio networks'], 'PCCW':['pccw'], 'KT':['kt corporation','korea telecom'],
  'NAVER Cloud':['naver'], 'iomart':['iomart'], 'Pulsant':['pulsant'], 'Fasthosts':['fasthosts'], 'Linode':['linode'], 'STC':['stc'], 'Teraco':['teraco'], 'Dimension Data':['dimension data','nnt'],
  'Telecom Egypt':['telecom egypt','te data'], 'Raya':['raya'], 'Altice Portugal':['altice'], 'Colt':['colt'],
  'Master Internet':['master internet'], 'VSHosting':['vshosting'], 'O2 Czech Republic':['o2'],
  'NXDATA':['nxdata'], 'GTS Telecom':['gts telecom'], 'Hosterion':['hosterion'], 'Telekom Romania':['telekom'],
  'AbrArvan':['arvan','ابر آروان'], 'ParsPack':['parspack','پارس پک'],
  'Iran Telecommunication Company':['telecommunication','mci','tic'], 'Asiatech':['asiatech'],
  'Fanavaran Nicsepehr':['nicsepehr','fanavaran'], 'Saman System':['saman system'],
  'A1 Telekom Austria':['a1 telekom','a1 austria'], 'Digital Realty':['digital realty'],
  'Rostelecom':['rostelecom'], 'Selectel':['selectel'], 'Yandex Cloud':['yandex'], 'VK Cloud':['vk cloud'], 'DataLine':['dataline'],
  'Aruba Italia':['aruba'], 'NTT':['ntt'], 'Bezeq':['bezeq'], 'Alibaba Cloud':['alibaba'], 'Khazna':['khazna'],
  'Combell':['combell']
};
function providerSearchTerms(provider){
  const raw=String(provider||'').trim();
  const terms=DATACENTER_PROVIDER_SEARCH[raw]||[raw];
  return terms.filter(Boolean).slice(0,4);
}
function providerLooksLike(providerText, providerName){
  const hay=String(providerText||'').toLowerCase();
  return providerSearchTerms(providerName).some(term=>hay.includes(String(term).toLowerCase()));
}

function safeWorldCountryCode(value) {
  const code = String(value || '').trim().toUpperCase();
  return WORLD_COUNTRY_CODES.includes(code) ? code : null;
}

const WORLD_COUNTRY_NAME_TO_CODE = Object.fromEntries(
  Object.entries(SUPPORTED_WORLD_COUNTRIES).flatMap(([code, info]) => [
    [String(code).toUpperCase(), code],
    [String(info.name || '').toUpperCase(), code],
    [String(info.fa || ''), code]
  ]).filter(([k]) => k)
);
function normaliseWorldCountryCode(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  const direct = safeWorldCountryCode(raw);
  if (direct) return direct;
  return WORLD_COUNTRY_NAME_TO_CODE[raw.toUpperCase()] || '';
}

function finiteGeo(value) {
  const n = Number(value);
  return Number.isFinite(n) && n >= -180 && n <= 180 ? n : null;
}

function isLikelyWorldProvider(name) {
  const text = String(name || '').toLowerCase();
  return WORLD_PROVIDER_WORDS.some(word => text.includes(word));
}

function normaliseWorldServicePorts(ports) {
  return [...new Set((ports || []).map(Number).filter(Number.isInteger).filter(p => p > 0 && p <= 65535))]
    .sort((a, b) => a - b);
}

async function fetchJsonUrl(url, opts = {}, timeout = 10000) {
  const response = await fetchText(url, {
    ...opts,
    headers: { accept: 'application/json', ...(opts.headers || {}) }
  }, timeout);
  const raw = await response.text();
  let data = null;
  try { data = raw ? JSON.parse(raw) : null; } catch (_) {}
  if (!response.ok) {
    const detail = data?.error || data?.message || raw || `HTTP ${response.status}`;
    throw Object.assign(new Error(String(detail).slice(0, 300)), { statusCode: response.status });
  }
  return data;
}

async function shodanApi(pathname, params = {}, timeout = 15000) {
  if (!SHODAN_API_KEY) throw new Error('SHODAN_API_KEY is not configured.');
  const url = new URL(`${SHODAN_BASE}${pathname}`);
  url.searchParams.set('key', SHODAN_API_KEY);
  for (const [key, value] of Object.entries(params || {})) {
    if (value != null && value !== '') url.searchParams.set(key, String(value));
  }
  return fetchJsonUrl(url.href, { headers: { accept: 'application/json' } }, timeout);
}

function netlasPayloadError(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return null;
  const errorObject = data.error && typeof data.error === 'object' ? data.error : {};
  const type = String(data.type || errorObject.type || '');
  const title = String(data.title || errorObject.title || '');
  const detail = String(data.detail || data.message || (typeof data.error === 'string' ? data.error : '') || errorObject.detail || errorObject.message || '');
  const combined = `${type} ${title} ${detail}`;
  const quotaOrAuth = /daily[_ -]?request[_ -]?limit|request limit exceeded|quota exceeded|credits exhausted|rate limit|unauthori[sz]ed|forbidden|invalid api key|token expired|authentication failed/i.test(combined);
  const errorShaped = /error|exceeded|limit|quota|unauthori[sz]ed|forbidden|invalid/i.test(`${type} ${title}`) || Boolean(data.errors || data.error);
  if (!quotaOrAuth && !errorShaped) return null;
  let message = '';
  try { message = JSON.stringify(data).slice(0, 300); } catch (_) { message = combined.slice(0, 300); }
  const statusCode = /unauthori[sz]ed|invalid api key|token expired|authentication failed/i.test(combined) ? 401
    : /forbidden/i.test(combined) ? 403
    : quotaOrAuth ? 429 : 400;
  return { message: message || 'Netlas returned an error payload.', statusCode, quotaOrAuth };
}

async function netlasApi(pathname, params = {}, timeout = 15000) {
  if (!NETLAS_API_KEY) throw new Error('NETLAS_API_KEY is not configured.');
  const cacheKey = pathname === '/responses/' ? JSON.stringify([pathname, Object.entries(params || {}).sort(([a],[b]) => a.localeCompare(b))]) : '';
  if (cacheKey) {
    const cached = netlasQueryCache[cacheKey];
    if (cached && Date.now() - Number(cached.at) < NETLAS_QUERY_CACHE_TTL && cached.data) return cached.data;
    if (netlasQueryInFlight.has(cacheKey)) return netlasQueryInFlight.get(cacheKey);
  }
  const request = (async () => {
    const url = new URL(`${NETLAS_BASE}${pathname}`);
    for (const [key, value] of Object.entries(params || {})) {
      if (value != null && value !== '') url.searchParams.set(key, String(value));
    }
    const data = await fetchJsonUrl(url.href, { headers: { accept: 'application/json', authorization: `Bearer ${NETLAS_API_KEY}` } }, timeout);
    const payloadError = netlasPayloadError(data);
    if (payloadError) throw Object.assign(new Error(payloadError.message), { statusCode: payloadError.statusCode, quotaOrAuth: payloadError.quotaOrAuth });
    if (cacheKey) {
      const now = Date.now();
      netlasQueryCache[cacheKey] = { at: now, data };
      netlasQueryCache = Object.fromEntries(Object.entries(netlasQueryCache)
        .filter(([, entry]) => entry && entry.data && now - Number(entry.at) < NETLAS_QUERY_CACHE_TTL)
        .sort((a,b) => Number(b[1].at) - Number(a[1].at)).slice(0, 250));
      writeSmallCache(NETLAS_QUERY_CACHE_FILE, netlasQueryCache);
    }
    return data;
  })();
  if (!cacheKey) return request;
  netlasQueryInFlight.set(cacheKey, request);
  try { return await request; } finally { netlasQueryInFlight.delete(cacheKey); }
}

function netlasAsnNumber(value) {
  if (Array.isArray(value)) value = value[0];
  const m = String(value ?? '').match(/(?:AS)?(\d{1,10})/i);
  return m ? Number(m[1]) : null;
}

function netlasItems(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.items)) return data.items;
  if (Array.isArray(data?.results)) return data.results;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.data?.items)) return data.data.items;
  if (Array.isArray(data?.data?.results)) return data.data.results;
  return [];
}

function netlasWorldPortRows(data) {
  const items = netlasItems(data);
  const rows = [];
  for (const item of items) {
    const source = item?.data && typeof item.data === 'object' ? item.data : item;
    const ip = source?.ip || item?.ip || '';
    if (!isIPv4(ip)) continue;

    const ports = new Set();
    const addPort = value => {
      const n = Number(value?.port ?? value);
      if (Number.isInteger(n) && n > 0 && n <= 65535) ports.add(n);
    };
    addPort(source?.port);
    for (const p of Array.isArray(source?.ports) ? source.ports : []) addPort(p);

    const geo = source?.geo || source?.location || {};
    const geoLocation = geo?.location || source?.location || source?.geo?.location || {};
    const whois = source?.whois || {};
    const netInfo = whois?.net || source?.net || source?.network || {};
    const asnInfo = whois?.asn || source?.asn || source?.autonomous_system || {};
    const asn = netlasAsnNumber(asnInfo?.number ?? asnInfo?.asn ?? asnInfo?.id ?? netInfo?.asn);
    const countryRaw = geo?.country_code || geo?.countryCode || geo?.country || whois?.net?.country || netInfo?.country || '';
    const countryCode = normaliseWorldCountryCode(countryRaw);
    const lat = finiteGeo(geoLocation?.lat ?? geoLocation?.latitude ?? source?.latitude);
    const lon = finiteGeo(geoLocation?.lon ?? geoLocation?.lng ?? geoLocation?.longitude ?? source?.longitude);
    const provider = String(
      source?.organization || source?.org || source?.isp ||
      whois?.net?.organization || whois?.net?.name || netInfo?.organization || netInfo?.name || ''
    ).trim();
    const asName = String(asnInfo?.name || source?.as_name || provider || '').trim();
    const cidr = Array.isArray(netInfo?.cidr) ? netInfo.cidr[0] : (netInfo?.cidr || source?.bgp?.prefix || '');
    const protocol = String(source?.protocol || source?.prot7 || '').toLowerCase();
    const transport = String(source?.prot4 || 'tcp').toLowerCase();
    const serviceRows = [...ports].map(port => ({
      port,
      transport,
      serviceName: SERVICE_MAP[port] || protocol || source?.prot7 || null,
      protocol: protocol || null,
      product: source?.product || null,
      version: source?.version || null
    }));
    rows.push({
      ip,
      asn,
      asName,
      provider: provider || asName,
      countryCode,
      country: COUNTRY_CODES[countryCode] || (typeof geo?.country === 'string' ? geo.country : countryCode),
      city: geo?.city || netInfo?.city || '',
      lat,
      lon,
      prefix: cidr,
      observedPorts: [...ports],
      confirmedPorts: [...ports],
      lastSeen: source?.last_updated || source?.last_updated_at || source?.timestamp || '',
      services: serviceRows,
    });
  }
  return rows;
}

async function netlasHostDetails(ip) {
  if (!NETLAS_API_KEY || !isValidIP(ip) || netlasQuotaIsBlocked()) return null;
  try {
    const data = await netlasApi(`/host/${encodeURIComponent(ip)}/`, { public_indices_only: 'true' }, 14000);
    const geo = data?.geo || {};
    const geoLocation = geo?.location || data?.location || {};
    const whois = data?.whois || {};
    const netInfo = whois?.net || {};
    const asnInfo = whois?.asn || {};
    const ports = Array.isArray(data?.ports) ? data.ports.map(x => Number(x?.port ?? x)).filter(p => Number.isInteger(p) && p > 0 && p <= 65535) : [];
    const services = Array.isArray(data?.ports) ? data.ports.map(x => ({
      port: Number(x?.port ?? 0),
      transport: x?.prot4 || 'tcp',
      serviceName: SERVICE_MAP[Number(x?.port)] || x?.protocol || x?.prot7 || null,
      protocol: x?.protocol || null,
      product: x?.product || null,
      version: x?.version || null
    })).filter(x => x.port) : [];
    const cidr = Array.isArray(netInfo?.cidr) ? netInfo.cidr[0] : (netInfo?.cidr || '');
    return {
      ip: data?.ip || ip,
      asn: netlasAsnNumber(asnInfo?.number ?? asnInfo?.asn),
      asName: asnInfo?.name || '',
      provider: data?.organization || netInfo?.organization || netInfo?.name || '',
      countryCode: normaliseWorldCountryCode(geo?.country_code || geo?.country || netInfo?.country || ''),
      country: COUNTRY_CODES[normaliseWorldCountryCode(geo?.country_code || geo?.country || netInfo?.country || '')] || geo?.country || '',
      city: geo?.city || netInfo?.city || '',
      lat: finiteGeo(geoLocation?.lat ?? geoLocation?.latitude ?? data?.latitude),
      lon: finiteGeo(geoLocation?.lon ?? geoLocation?.lng ?? geoLocation?.longitude ?? data?.longitude),
      prefix: cidr,
      ports,
      services,
      lastSeen: whois?.['@timestamp'] || data?.last_updated || ''
    };
  } catch (error) {
    markNetlasQuotaBlocked(error);
    return null;
  }
}

function netlasQuotaIsBlocked() {
  return Date.now() < netlasQuotaBlockedUntil;
}
function markNetlasQuotaBlocked(error, reported = false) {
  const message = String(error?.message || error || 'Netlas quota unavailable');
  const status = Number(error?.statusCode || error?.status || 0);
  const quotaLike = [401, 402, 403, 429].includes(status) || /daily[_ ]request[_ ]limit|request limit exceeded|quota exceeded|credits exhausted|rate limit/i.test(message);
  if (!quotaLike) return false;
  const wasAlreadyBlocked = netlasQuotaIsBlocked();
  // Daily-limit responses are cached locally for a day to avoid repeating calls
  // that the provider will reject anyway. Authentication/billing errors get the same cooldown.
  netlasQuotaBlockedUntil = Math.max(netlasQuotaBlockedUntil, Date.now() + 24 * 60 * 60 * 1000);
  netlasQuotaBlockReason = message.slice(0, 220);
  netlasQuotaNoticeEmitted = wasAlreadyBlocked ? netlasQuotaNoticeEmitted : Boolean(reported);
  writeSmallCache(NETLAS_QUOTA_STATE_FILE, { until: netlasQuotaBlockedUntil, reason: netlasQuotaBlockReason });
  return true;
}
function takeNetlasQuotaNotice() {
  if (netlasQuotaNoticeEmitted) return [];
  netlasQuotaNoticeEmitted = true;
  const until = new Date(netlasQuotaBlockedUntil).toISOString();
  return [`Netlas paused until ${until} after quota/auth response: ${netlasQuotaBlockReason}`];
}

async function netlasWorldDiscovery(countryCode, ports, providerQuery = '', limit = 16) {
  if (!NETLAS_API_KEY) return { enabled: false, candidates: new Map(), sources: [], errors: [] };
  if (netlasQuotaIsBlocked()) return { enabled: true, candidates: new Map(), sources: ['Netlas quota cooldown'], errors: takeNetlasQuotaNotice() };
  const cc = safeWorldCountryCode(countryCode);
  const candidates = new Map();
  const errors = [];
  const queryPorts = normaliseWorldServicePorts(ports);
  const requestedPorts = queryPorts.length ? queryPorts.slice(0, 4) : [80, 443];
  const provider = String(providerQuery || '').trim().replace(/[^\w .:+&()\/-]/g, '').slice(0, 80);
  const portExpr = requestedPorts.length === 1 ? `port:${requestedPorts[0]}` : `(${requestedPorts.map(p => `port:${p}`).join(' OR ')})`;
  const queries = [];
  const providerTerms = providerSearchTerms(provider);
  if(providerTerms.length){
    const orgTerms=[...new Set(providerTerms)].map(term=>`whois.net.organization:"${String(term).replace(/"/g,'')}"`).join(' OR ');
    const nameTerms=[...new Set(providerTerms)].map(term=>`whois.net.name:"${String(term).replace(/"/g,'')}"`).join(' OR ');
    const ispTerms=[...new Set(providerTerms)].map(term=>`isp:"${String(term).replace(/"/g,'')}"`).join(' OR ');
    const providerExpr=`(${orgTerms} OR ${nameTerms} OR ${ispTerms})`;
    queries.push(`geo.country:${cc} AND host_type:ip AND (${portExpr}) AND ${providerExpr}`);
    queries.push(`geo.country:${cc} AND host_type:ip AND ${providerExpr}`);
  } else {
    const catalogTerms = (DATACENTER_PROVIDERS_BY_COUNTRY[cc] || []).flatMap(providerSearchTerms).slice(0, 8);
    if(catalogTerms.length){
      const orgTerms=[...new Set(catalogTerms)].map(term=>`whois.net.organization:"${String(term).replace(/"/g,'')}"`).join(' OR ');
      const nameTerms=[...new Set(catalogTerms)].map(term=>`whois.net.name:"${String(term).replace(/"/g,'')}"`).join(' OR ');
      const ispTerms=[...new Set(catalogTerms)].map(term=>`isp:"${String(term).replace(/"/g,'')}"`).join(' OR ');
      queries.push(`geo.country:${cc} AND host_type:ip AND (${portExpr}) AND (${orgTerms} OR ${nameTerms} OR ${ispTerms})`);
    }
    queries.push(`geo.country:${cc} AND host_type:ip AND ${portExpr}`);
    queries.push(`geo.country:${cc} AND host_type:ip`);
  }
  const fields = [
    'ip','port','protocol','prot4','prot7','geo.country','geo.city','geo.location.lat','geo.location.lon',
    'isp','whois.asn.name','whois.asn.number','whois.net.name','whois.net.organization','last_updated','uri','http.title'
  ].join(',');
  for (let qi = 0; qi < Math.min(queries.length, 2) && candidates.size < limit; qi++) {
    const q = queries[qi];
    try {
      const data = await netlasApi('/responses/', { q, start: 0, size: 20, fields }, 16000);
      const before = candidates.size;
      for (const row of netlasWorldPortRows(data)) {
        if (row.countryCode && row.countryCode !== cc) continue;
        addWorldCandidate(candidates, {
          ...row,
          countryCode: row.countryCode || '', country: row.country || '',
          notes: provider && providerLooksLike(`${row.provider||''} ${row.asName||''}`, provider) ? [`Provider match: ${provider}`] : [],
          sources: [`Netlas response search${provider && qi===0 ? ' (provider query)' : qi===1 ? ' (country+port)' : ' (country fallback)'}`]
        });
      }
      if (candidates.size === before && qi === 0) errors.push(`Netlas returned no matching hosts for ${cc} with ${requestedPorts.join(',')}.`);
    } catch (e) {
      const blocked = markNetlasQuotaBlocked(e, true);
      errors.push(blocked ? `Netlas paused to protect API quota: ${e.message}` : `Netlas query ${qi + 1}: ${e.message}`);
      if (blocked) break;
    }
  }
  return { enabled: true, candidates, sources: ['Netlas response search'], errors };
}

async function ipinfoLiteLookup(ip) {
  if (!IPINFO_TOKEN || !isValidIP(ip)) return null;
  try {
    return await fetchJsonUrl(`https://api.ipinfo.io/lite/${encodeURIComponent(ip)}?token=${encodeURIComponent(IPINFO_TOKEN)}`, {
      headers: { accept: 'application/json' }
    }, 7000);
  } catch (_) { return null; }
}

async function abuseIpDbCheck(ip) {
  if (!ABUSEIPDB_API_KEY || !isIPv4(ip)) return null;
  try {
    const u = new URL('https://api.abuseipdb.com/api/v2/check');
    u.searchParams.set('ipAddress', ip);
    u.searchParams.set('maxAgeInDays', '90');
    const data = await fetchJsonUrl(u.href, { headers: { accept: 'application/json', Key: ABUSEIPDB_API_KEY } }, 9000);
    return data?.data || null;
  } catch (_) { return null; }
}

async function checkHostInfo(ip) {
  if (!isValidIP(ip)) return null;
  try { return await checkHostApi(`/info/${encodeURIComponent(ip)}`, { timeout: 9000 }); }
  catch (_) { return null; }
}

async function checkHostIntelligence(ip) {
  if (!isValidIP(ip)) return null;
  try { return await checkHostApi(`/ip/${encodeURIComponent(ip)}`, { timeout: 10000 }); }
  catch (_) { return null; }
}

async function getCheckHostLocations() {
  if (checkHostLocationsCache.data && Date.now() - checkHostLocationsCache.at < CHECK_HOST_LOCATIONS_CACHE_TTL) return checkHostLocationsCache.data;
  try {
    const data = await checkHostApi('/locations', { timeout: 10000 });
    const rows = Array.isArray(data?.locationlist) ? data.locationlist.filter(x => x?.locationname && Number(x.monitoring_allowed) !== 0) : [];
    checkHostLocationsCache = { at: Date.now(), data: rows };
    return rows;
  } catch (_) { return []; }
}

async function chooseCheckHostRegions(countryCodes = [], maxNodes = 8) {
  const rows = await getCheckHostLocations();
  if (!rows.length) return [];
  const chosen = [];
  const wanted = [...new Set((countryCodes || []).map(x => String(x || '').toUpperCase()).filter(x => /^[A-Z]{2}$/.test(x)))];
  for (const cc of wanted) {
    const hit = rows.find(x => String(x.countryCode || x.country_code || '').toUpperCase() === cc);
    if (hit && !chosen.some(x => x.locationname === hit.locationname)) chosen.push(hit);
  }
  for (const row of rows) {
    if (chosen.length >= maxNodes) break;
    if (!chosen.some(x => x.locationname === row.locationname)) chosen.push(row);
  }
  return chosen.slice(0, maxNodes).map(x => x.locationname);
}

async function checkHostMonitor(kind, body = {}, options = {}) {
  const created = await checkHostApi(`/${kind}`, { method: 'POST', body, timeout: options.timeout || 12000 });
  const uuid = created?.uuid || created?.request_id || created?.id;
  if (!uuid) throw new Error(`Check-Host ${kind} job did not return a UUID.`);
  let report = null;
  for (let attempt = 0; attempt < (options.attempts || 14); attempt++) {
    await new Promise(resolve => setTimeout(resolve, attempt === 0 ? 450 : 650));
    try {
      report = await checkHostApi(`/report/${encodeURIComponent(uuid)}`, { timeout: options.reportTimeout || 9000 });
      const data = report?.data || report?.results || null;
      if (data && Object.keys(data).length) break;
    } catch (_) {}
  }
  return { uuid, report, data: report?.data || report?.results || {} };
}

function extractCheckHostChecks(payload) {
  if (!payload || typeof payload !== 'object') return [];
  if (Array.isArray(payload.checks)) return payload.checks.filter(x => x && typeof x === 'object');
  if (payload.check && typeof payload.check === 'object') return [payload.check];
  return [];
}

async function checkHostApi(pathname, options = {}) {
  const method = String(options.method || 'GET').toUpperCase();
  const init = { method, headers: { accept: 'application/json', ...(CHECK_HOST_API_KEY ? { authorization: `Bearer ${CHECK_HOST_API_KEY}` } : {}) } };
  if (options.body != null) {
    init.headers['content-type'] = 'application/json';
    init.body = JSON.stringify(options.body);
  }
  return fetchJsonUrl(`${CHECK_HOST_BASE}${pathname}`, init, options.timeout || 12000);
}

function normaliseWorldLatency(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0 || n > 60000) return null;
  return n < 1 ? n * 1000 : n;
}

function extractWorldPingLatency(value, out = []) {
  if (value == null) return out;
  if (Array.isArray(value)) {
    for (const item of value) extractWorldPingLatency(item, out);
    return out;
  }
  if (typeof value === 'object') {
    const checks = extractCheckHostChecks(value);
    for (const check of checks) {
      const ms = normaliseWorldLatency(check.connectiontime ?? check.latencyMs ?? check.rtt ?? check.response_time);
      if (Number(check.status) === 1 && ms != null) out.push(ms);
    }
    for (const [key, item] of Object.entries(value)) {
      if (key === 'checks' || key === 'check') continue;
      if (/latency|rtt|response[_-]?time|time_ms|connectiontime/i.test(key)) {
        const candidate = normaliseWorldLatency(item);
        if (candidate != null) out.push(candidate);
      }
      if (item && typeof item === 'object') extractWorldPingLatency(item, out);
    }
  }
  return out;
}

async function globalWorldPing(ip, probeCountries = ['IR', 'DE', 'FR', 'AZ']) {
  try {
    const gp = await globalpingMeasure(ip, probeCountries, 2);
    return {
      ok: (gp?.results || []).some(x => x?.avgMs != null && Number.isFinite(Number(x.avgMs))),
      source: 'Globalping',
      measurementId: gp?.measurementId || null,
      probeCountries,
      reportedNodes: gp?.results?.length || 0,
      measuredNodes: (gp?.results || []).filter(x => Number.isFinite(x.avgMs)).length,
      minMs: (gp?.results || []).map(x=>x.minMs).filter(Number.isFinite).length ? Math.round(Math.min(...gp.results.map(x=>x.minMs).filter(Number.isFinite))) : null,
      avgMs: (gp?.results || []).map(x=>x.avgMs).filter(Number.isFinite).length ? Math.round(gp.results.map(x=>x.avgMs).filter(Number.isFinite).reduce((a,b)=>a+b,0)/gp.results.map(x=>x.avgMs).filter(Number.isFinite).length) : null,
      nodes: (gp?.results || []).map(x=>({country:x.country,countryName:x.countryName,city:x.city,asn:x.asn,network:x.network,status:x.status,latencyMs:x.avgMs,minMs:x.minMs,maxMs:x.maxMs,loss:x.loss})),
      error: gp?.ok ? null : 'No Globalping probe returned a usable ping result.'
    };
  } catch (error) {
    return { ok: false, source: 'Globalping', probeCountries, error: String(error?.message || error) };
  }
}

function extractWorldTavilyIPs(text) {
  const matches = String(text || '').match(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g) || [];
  return [...new Set(matches.filter(isIPv4))];
}
function extractWorldTavilyASNs(text) {
  const matches = String(text || '').match(/\bAS\s*(\d{1,10})\b/gi) || [];
  return [...new Set(matches.map(x => Number(x.replace(/[^0-9]/g, '') || 0)).filter(n => Number.isInteger(n) && n > 0))];
}

async function tavilyWorldDiscoveryUncached(countryName, countryCode, ports, providerQuery = '') {
  if (!TAVILY_API_KEY) return { enabled: false, ips: [], asns: [], sources: [] };
  const portText = ports.length ? ` ports ${ports.join(', ')}` : '';
  const queries = [
    `data center hosting ASN IP ranges ${countryName} ${countryCode}${portText}`,
    `VPS cloud datacenter IP addresses ASN ${countryName} ${providerQuery}`.trim()
  ];
  const sources = [];
  const errors = [];
  const ips = new Set();
  const asns = new Set();
  for (const query of queries) {
    try {
      const data = await fetchJsonUrl(`${TAVILY_BASE}/search`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${TAVILY_API_KEY}`
        },
        body: {
          api_key: TAVILY_API_KEY,
          query,
          search_depth: query === queries[0] ? 'basic' : 'advanced',
          topic: 'general',
          max_results: 4,
          include_answer: false,
          include_raw_content: false
        }
      }, 15000);
      for (const item of Array.isArray(data?.results) ? data.results : []) {
        const blob = [item?.title, item?.content, item?.raw_content, item?.url].filter(Boolean).join('\n');
        for (const ip of extractWorldTavilyIPs(blob)) ips.add(ip);
        for (const asn of extractWorldTavilyASNs(blob)) asns.add(asn);
        if (item?.title || item?.url) {
          sources.push({ title: String(item.title || 'Tavily result').slice(0, 180), url: String(item.url || '').slice(0, 500) });
        }
      }
      if (ips.size) break;
    } catch (error) { errors.push(`Tavily search failed: ${error.message}`); }
  }
  return { enabled: true, ran: true, ips: [...ips].slice(0, 12), asns: [...asns].slice(0, 12), sources: sources.slice(0, 12), errors };
}

async function tavilyWorldDiscovery(countryName, countryCode, ports, providerQuery = '') {
  if (!TAVILY_API_KEY) return { enabled: false, ran: false, ips: [], asns: [], sources: [], errors: [] };
  const key = JSON.stringify([String(countryCode || '').toUpperCase(), normaliseWorldServicePorts(ports), String(providerQuery || '').trim().toLowerCase()]);
  const cached = tavilySearchCache[key];
  if (cached && cached.data && Date.now() - Number(cached.at) < Number(cached.ttl || TAVILY_SEARCH_CACHE_TTL)) return { ...cached.data, cached: true };
  if (tavilySearchInFlight.has(key)) return tavilySearchInFlight.get(key);
  const pending = (async () => {
    const result = await tavilyWorldDiscoveryUncached(countryName, countryCode, ports, providerQuery);
    const ttl = result?.errors?.length ? 60 * 60 * 1000 : TAVILY_SEARCH_CACHE_TTL;
    const now = Date.now();
    tavilySearchCache[key] = { at: now, ttl, data: result };
    tavilySearchCache = Object.fromEntries(Object.entries(tavilySearchCache)
      .filter(([, entry]) => entry && entry.data && now - Number(entry.at) < Number(entry.ttl || TAVILY_SEARCH_CACHE_TTL))
      .sort((a,b) => Number(b[1].at) - Number(a[1].at)).slice(0, 120));
    writeSmallCache(TAVILY_SEARCH_CACHE_FILE, tavilySearchCache);
    return result;
  })();
  tavilySearchInFlight.set(key, pending);
  try { return await pending; } finally { tavilySearchInFlight.delete(key); }
}

function addWorldCandidate(map, input) {
  const ip = String(input?.ip || '').trim();
  if (!isIPv4(ip) || isBlockedIP(ip)) return;
  const existing = map.get(ip) || {
    ip,
    country: input.country || '',
    countryCode: input.countryCode || '',
    asn: input.asn || null,
    asName: input.asName || '',
    provider: input.provider || input.asName || '',
    prefix: input.prefix || '',
    city: input.city || '',
    lat: finiteGeo(input.lat),
    lon: finiteGeo(input.lon),
    confirmedPorts: new Set(),
    observedPorts: new Set(),
    sources: new Set(),
    lastSeen: input.lastSeen || '',
    ping: null,
    notes: [],
    services: []
  };
  if (input.asn != null) existing.asn = Number(input.asn) || existing.asn;
  existing.asName ||= input.asName || '';
  existing.provider ||= input.provider || input.asName || '';
  existing.country ||= input.country || '';
  existing.countryCode ||= input.countryCode || '';
  existing.prefix ||= input.prefix || '';
  existing.city ||= input.city || '';
  if (existing.lat == null) existing.lat = finiteGeo(input.lat);
  if (existing.lon == null) existing.lon = finiteGeo(input.lon);
  existing.lastSeen ||= input.lastSeen || '';
  for (const port of input.confirmedPorts || []) existing.confirmedPorts.add(Number(port));
  for (const port of input.observedPorts || []) existing.observedPorts.add(Number(port));
  for (const source of input.sources || []) existing.sources.add(String(source));
  for (const note of input.notes || []) if (note && !existing.notes.includes(note)) existing.notes.push(note);
  for (const service of input.services || []) {
    if (!service || typeof service !== 'object') continue;
    const key = `${service.port || ''}|${service.transport || ''}|${service.product || ''}|${service.serviceName || ''}`;
    if (!existing.services.some(x => `${x.port || ''}|${x.transport || ''}|${x.product || ''}|${x.serviceName || ''}` === key)) existing.services.push(service);
  }
  if (input.ping) existing.ping = input.ping;
  map.set(ip, existing);
}

function finalizeWorldCandidates(map, ports, limit) {
  return [...map.values()]
    .map(row => ({
      ...row,
      confirmedPorts: [...row.confirmedPorts].filter(Boolean).sort((a, b) => a - b),
      observedPorts: [...row.observedPorts].filter(Boolean).sort((a, b) => a - b),
      sources: [...row.sources].filter(Boolean),
      notes: row.notes || [],
      services: Array.isArray(row.services) ? row.services : []
    }))
    .sort((a, b) => {
      const aCountry = safeWorldCountryCode(a.countryCode);
      const bCountry = safeWorldCountryCode(b.countryCode);
      const aProviders = DATACENTER_PROVIDERS_BY_COUNTRY[aCountry] || [];
      const bProviders = DATACENTER_PROVIDERS_BY_COUNTRY[bCountry] || [];
      const aProviderText = String(a.provider || a.asName || '').toLowerCase();
      const bProviderText = String(b.provider || b.asName || '').toLowerCase();
      const aDc = aProviders.some(p => aProviderText.includes(String(p).toLowerCase())) ? 1 : 0;
      const bDc = bProviders.some(p => bProviderText.includes(String(p).toLowerCase())) ? 1 : 0;
      if (aDc !== bDc) return bDc - aDc;
      const aConfirmed = ports.filter(p => a.confirmedPorts.includes(p)).length;
      const bConfirmed = ports.filter(p => b.confirmedPorts.includes(p)).length;
      if (aConfirmed !== bConfirmed) return bConfirmed - aConfirmed;
      const aObserved = ports.filter(p => a.observedPorts.includes(p)).length;
      const bObserved = ports.filter(p => b.observedPorts.includes(p)).length;
      if (aObserved !== bObserved) return bObserved - aObserved;
      if (Boolean(a.ping?.ok) !== Boolean(b.ping?.ok)) return Number(Boolean(b.ping?.ok)) - Number(Boolean(a.ping?.ok));
      return String(a.provider || a.asName || '').localeCompare(String(b.provider || b.asName || ''));
    })
    .slice(0, limit);
}

function shodanIpFromMatch(match) {
  if (isIPv4(match?.ip_str)) return match.ip_str;
  if (Number.isInteger(Number(match?.ip)) && Number(match.ip) >= 0) return intToIPv4(Number(match.ip) >>> 0);
  return '';
}

function shodanAsnNumber(value) {
  const m = String(value || '').match(/(?:AS)?(\d{1,10})/i);
  return m ? Number(m[1]) : null;
}

function shodanServiceRows(data) {
  const rows = [];
  for (const item of Array.isArray(data?.data) ? data.data : []) {
    const port = Number(item?.port);
    if (!Number.isInteger(port) || port < 1 || port > 65535) continue;
    const http = item?.http || {};
    const ssl = item?.ssl || {};
    const subject = ssl?.cert?.subject?.CN || ssl?.cert?.subject?.cn || null;
    rows.push({
      port,
      transport: String(item?.transport || 'tcp').toLowerCase(),
      serviceName: SERVICE_MAP[port] || null,
      product: item?.product || null,
      version: item?.version || null,
      module: item?._shodan?.module || item?.module || null,
      httpStatus: Number.isInteger(Number(http?.status)) ? Number(http.status) : null,
      httpTitle: http?.title || null,
      sslSubject: subject,
      banner: String(item?.data || '').slice(0, 700),
      timestamp: item?.timestamp || null
    });
  }
  return rows;
}

async function shodanHostDetails(ip) {
  if (!SHODAN_API_KEY) return null;
  try {
    const data = await shodanApi(`/shodan/host/${encodeURIComponent(ip)}`, { minify: 'false' }, 14000);
    return {
      ip: data?.ip_str || ip,
      asn: shodanAsnNumber(data?.asn),
      asName: data?.org || data?.isp || '',
      provider: data?.org || data?.isp || '',
      countryCode: data?.country_code || '',
      country: data?.country_name || '',
      city: data?.city || data?.location?.city || '',
      lat: finiteGeo(data?.latitude ?? data?.location?.latitude),
      lon: finiteGeo(data?.longitude ?? data?.location?.longitude),
      lastSeen: data?.last_update || '',
      ports: Array.isArray(data?.ports) ? data.ports.map(Number).filter(Boolean) : [],
      services: shodanServiceRows(data),
      raw: data
    };
  } catch (_) { return null; }
}

const SHODAN_SEARCH_CACHE_FILE = path.join(__dirname, 'data', 'shodan-search-cache.json');
const SHODAN_SEARCH_CACHE_TTL = 24 * 60 * 60 * 1000;
const shodanSearchInFlight = new Map();
function readSmallCache(file) {
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (_) { return {}; }
}
function writeSmallCache(file, value) {
  ensureDataDir();
  const tempFile = `${file}.tmp`;
  try {
    fs.writeFileSync(tempFile, JSON.stringify(value));
    fs.renameSync(tempFile, file);
  } catch (error) {
    try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (_) {}
    console.warn(`[cache] Could not persist ${path.basename(file)}: ${error.message}`);
  }
}
let shodanSearchCache = readSmallCache(SHODAN_SEARCH_CACHE_FILE);
for (const [key, entry] of Object.entries(shodanSearchCache)) {
  if (!entry || !Array.isArray(entry.rows) || !Number.isFinite(Number(entry.at)) || Date.now() - Number(entry.at) > SHODAN_SEARCH_CACHE_TTL) delete shodanSearchCache[key];
}
const NETLAS_QUERY_CACHE_FILE = path.join(__dirname, 'data', 'netlas-query-cache.json');
const NETLAS_QUERY_CACHE_TTL = 24 * 60 * 60 * 1000;
let netlasQueryCache = readSmallCache(NETLAS_QUERY_CACHE_FILE);
for (const [key, entry] of Object.entries(netlasQueryCache)) {
  if (!entry || !entry.data || !Number.isFinite(Number(entry.at)) || Date.now() - Number(entry.at) > NETLAS_QUERY_CACHE_TTL) delete netlasQueryCache[key];
}
const netlasQueryInFlight = new Map();
const STRUCTURED_PROVIDER_CACHE_TTL = 12 * 60 * 60 * 1000;
const ZOOMEYE_SEARCH_CACHE_FILE = path.join(__dirname, 'data', 'zoomeye-search-cache.json');
const CENSYS_SEARCH_CACHE_FILE = path.join(__dirname, 'data', 'censys-search-cache.json');
let zoomeyeSearchCache = readSmallCache(ZOOMEYE_SEARCH_CACHE_FILE);
let censysSearchCache = readSmallCache(CENSYS_SEARCH_CACHE_FILE);
for (const cache of [zoomeyeSearchCache, censysSearchCache]) {
  for (const [key, entry] of Object.entries(cache)) {
    const ttl = Number(entry?.ttl || STRUCTURED_PROVIDER_CACHE_TTL);
    if (!entry || !Number.isFinite(Number(entry.at)) || Date.now() - Number(entry.at) > ttl || (!Array.isArray(entry.rows) && !entry.error)) delete cache[key];
  }
}
const zoomeyeSearchInFlight = new Map();
const censysSearchInFlight = new Map();
let zoomeyeRequestQueue = Promise.resolve();
let censysRequestQueue = Promise.resolve();
function runZoomEyeSerial(task) {
  const next = zoomeyeRequestQueue.then(task, task);
  zoomeyeRequestQueue = next.catch(() => null);
  return next;
}
function runCensysSerial(task) {
  const next = censysRequestQueue.then(task, task);
  censysRequestQueue = next.catch(() => null);
  return next;
}
const STRUCTURED_PROVIDER_STATE_FILES = {
  ZoomEye: path.join(__dirname, 'data', 'zoomeye-provider-state.json'),
  Censys: path.join(__dirname, 'data', 'censys-provider-state.json')
};
const structuredProviderStates = {
  ZoomEye: readSmallCache(STRUCTURED_PROVIDER_STATE_FILES.ZoomEye),
  Censys: readSmallCache(STRUCTURED_PROVIDER_STATE_FILES.Censys)
};
function structuredProviderCredentialHash(provider) {
  const secret = provider === 'ZoomEye' ? ZOOMEYE_API_KEY : CENSYS_API_TOKEN;
  return secret ? crypto.createHash('sha256').update(secret).digest('hex').slice(0, 16) : '';
}
function getStructuredProviderCooldown(provider) {
  const state = structuredProviderStates[provider];
  if (!state || state.credentialHash !== structuredProviderCredentialHash(provider)) return null;
  return Number(state.until) > Date.now() ? state : null;
}
function markStructuredProviderCooldown(provider, error) {
  const status = Number(error?.statusCode || error?.status || 0);
  const message = String(error?.message || 'Provider quota/authentication unavailable');
  const quotaOrAuth = [401, 402, 403, 429].includes(status) || /quota|credit|points? exhausted|rate.?limit|unauthori[sz]ed|forbidden|api.?key|token/i.test(message);
  if (!quotaOrAuth || !STRUCTURED_PROVIDER_STATE_FILES[provider]) return;
  const state = {
    until: Date.now() + 24 * 60 * 60 * 1000,
    reason: message.replace(/[\r\n]+/g, ' ').slice(0, 260),
    credentialHash: structuredProviderCredentialHash(provider)
  };
  structuredProviderStates[provider] = state;
  writeSmallCache(STRUCTURED_PROVIDER_STATE_FILES[provider], state);
}
function ensureStructuredProviderAvailable(provider) {
  const cooldown = getStructuredProviderCooldown(provider);
  if (cooldown) {
    const until = new Date(Number(cooldown.until)).toISOString();
    throw Object.assign(new Error(`${provider} paused until ${until} after a quota/authentication response: ${cooldown.reason}`), { statusCode: 429, providerCooldown: true });
  }
}
const NETLAS_QUOTA_STATE_FILE = path.join(__dirname, 'data', 'netlas-quota-state.json');
const persistedNetlasQuota = readSmallCache(NETLAS_QUOTA_STATE_FILE);
if (Number(persistedNetlasQuota.until) > Date.now()) {
  netlasQuotaBlockedUntil = Number(persistedNetlasQuota.until);
  netlasQuotaBlockReason = String(persistedNetlasQuota.reason || 'Netlas quota cooldown');
}
const TAVILY_SEARCH_CACHE_FILE = path.join(__dirname, 'data', 'tavily-search-cache.json');
const TAVILY_SEARCH_CACHE_TTL = 12 * 60 * 60 * 1000;
let tavilySearchCache = readSmallCache(TAVILY_SEARCH_CACHE_FILE);
for (const [key, entry] of Object.entries(tavilySearchCache)) {
  if (!entry || !entry.data || !Number.isFinite(Number(entry.at)) || Date.now() - Number(entry.at) > Number(entry.ttl || TAVILY_SEARCH_CACHE_TTL)) delete tavilySearchCache[key];
}
const tavilySearchInFlight = new Map();
let shodanDiscoveryState = { at: 0, usable: null, queryCredits: null };
async function shodanDiscoveryUsable() {
  if (!SHODAN_API_KEY) return false;
  if (Date.now() - shodanDiscoveryState.at < 10 * 60 * 1000 && shodanDiscoveryState.usable != null) return shodanDiscoveryState.usable;
  try {
    const data = await shodanApi('/api-info', {}, 9000);
    const credits = data?.query_credits;
    shodanDiscoveryState = { at: Date.now(), usable: credits == null ? true : Number(credits) > 0, queryCredits: credits == null ? null : Number(credits) };
  } catch (_) {
    // Do not spend host-search credits when the account's remaining quota is unknown.
    shodanDiscoveryState = { at: Date.now(), usable: false, queryCredits: null };
  }
  return shodanDiscoveryState.usable;
}

function shodanRowsFromMatches(matches, countryCode, query) {
  const rows = [];
  for (const match of Array.isArray(matches) ? matches : []) {
    const ip = shodanIpFromMatch(match);
    if (!ip) continue;
    const actualCountry = String(match?.location?.country_code || match?.country_code || '').toUpperCase();
    if (actualCountry && actualCountry !== countryCode) continue;
    const port = Number(match?.port);
    rows.push({
      ip,
      asn: shodanAsnNumber(match?.asn),
      asName: match?.org || match?.isp || '',
      provider: match?.org || match?.isp || '',
      countryCode: actualCountry,
      country: match?.location?.country_name || (actualCountry ? COUNTRY_CODES[actualCountry] || actualCountry : ''),
      city: match?.location?.city || '',
      lat: finiteGeo(match?.location?.latitude),
      lon: finiteGeo(match?.location?.longitude),
      observedPorts: [port].filter(p => Number.isInteger(p) && p > 0),
      confirmedPorts: [port].filter(p => Number.isInteger(p) && p > 0),
      lastSeen: match?.timestamp || '',
      sources: [`Shodan host search (${port || query})`],
      notes: [match?.product ? `Product: ${match.product}${match.version ? ` ${match.version}` : ''}` : null].filter(Boolean)
    });
  }
  return rows;
}

function providerSearchCacheTrim(cache, file, maxEntries = 80) {
  const now = Date.now();
  const entries = Object.entries(cache)
    .filter(([, entry]) => entry && Number.isFinite(Number(entry.at)) && now - Number(entry.at) < Number(entry.ttl || STRUCTURED_PROVIDER_CACHE_TTL))
    .sort((a, b) => Number(b[1].at) - Number(a[1].at))
    .slice(0, maxEntries);
  for (const key of Object.keys(cache)) delete cache[key];
  for (const [key, entry] of entries) cache[key] = entry;
  writeSmallCache(file, cache);
}

async function runCachedStructuredSearch({ provider, cache, inFlight, file, key, fetchRows }) {
  const providerCooldown = getStructuredProviderCooldown(provider);
  if (providerCooldown) {
    const until = new Date(Number(providerCooldown.until)).toISOString();
    return { rows: [], errors: [`${provider} paused until ${until}: ${providerCooldown.reason}`], cached: true };
  }
  const now = Date.now();
  const cached = cache[key];
  if (cached && now - Number(cached.at) < Number(cached.ttl || STRUCTURED_PROVIDER_CACHE_TTL)) {
    return { rows: Array.isArray(cached.rows) ? cached.rows : [], errors: cached.error ? [`${provider}: ${cached.error}`] : [], cached: true };
  }
  if (inFlight.has(key)) return inFlight.get(key);
  const pending = (async () => {
    try {
      const rows = await fetchRows();
      if (STRUCTURED_PROVIDER_STATE_FILES[provider]) {
        structuredProviderStates[provider] = {};
        writeSmallCache(STRUCTURED_PROVIDER_STATE_FILES[provider], {});
      }
      cache[key] = { at: Date.now(), ttl: STRUCTURED_PROVIDER_CACHE_TTL, rows: Array.isArray(rows) ? rows : [] };
      providerSearchCacheTrim(cache, file);
      clearServerProblem(provider);
      return { rows: Array.isArray(rows) ? rows : [], errors: [], cached: false };
    } catch (error) {
      const status = Number(error?.statusCode || error?.status || 0);
      const quotaOrAuth = [401, 402, 403, 429].includes(status) || /quota|credit|rate.?limit|unauthori[sz]ed|forbidden|api.?key|token/i.test(String(error?.message || ''));
      const ttl = quotaOrAuth ? 24 * 60 * 60 * 1000 : 60 * 60 * 1000;
      const message = String(error?.message || 'Provider request failed').replace(/[\r\n]+/g, ' ').slice(0, 300);
      if (!error?.providerCooldown) markStructuredProviderCooldown(provider, error);
      cache[key] = { at: Date.now(), ttl, rows: [], error: message };
      providerSearchCacheTrim(cache, file);
      recordServerProblem(provider, message, quotaOrAuth ? 'warning' : 'error');
      return { rows: [], errors: [`${provider}: ${message}`], cached: false };
    }
  })();
  inFlight.set(key, pending);
  try { return await pending; } finally { inFlight.delete(key); }
}

function zoomEyeHitRows(data, countryCode) {
  const possible = [data?.matches, data?.data?.matches, data?.result?.matches, data?.data?.list, data?.data, data?.result?.data, data?.results];
  const hits = possible.find(Array.isArray) || [];
  const rows = [];
  for (const hit of hits) {
    const ip = String(hit?.ip || hit?.ip_str || hit?.ip_addr || hit?.ip_address || hit?.host?.ip || '').trim();
    if (!isIPv4(ip)) continue;
    const geo = hit?.geoinfo || hit?.geo || hit?.location || hit?.host?.location || {};
    const asinfo = hit?.asinfo || hit?.autonomous_system || hit?.host?.autonomous_system || {};
    const portInfo = hit?.portinfo || hit?.port_info || {};
    const portValues = [hit?.port, portInfo?.port, ...(Array.isArray(hit?.ports) ? hit.ports : []), ...(Array.isArray(portInfo?.ports) ? portInfo.ports : [])];
    const ports = [...new Set(portValues.map(v => Number(v?.port ?? v)).filter(v => Number.isInteger(v) && v > 0 && v <= 65535))];
    const rawCountry = geo?.country_code || geo?.countryCode || geo?.country || hit?.country || '';
    const actualCountry = normaliseWorldCountryCode(rawCountry);
    if (actualCountry && actualCountry !== countryCode) continue;
    const asn = netlasAsnNumber(asinfo?.asn ?? asinfo?.number ?? hit?.asn);
    const provider = String(asinfo?.organization || asinfo?.org || asinfo?.name || hit?.organization || hit?.org || hit?.isp || '').trim();
    const countryName = typeof rawCountry === 'string' && rawCountry.length > 2 ? rawCountry : (COUNTRY_CODES[actualCountry] || actualCountry);
    const services = ports.map(port => ({
      port,
      transport: String(portInfo?.transport || portInfo?.protocol || 'tcp').toLowerCase(),
      serviceName: SERVICE_MAP[port] || portInfo?.service || portInfo?.app || null,
      protocol: portInfo?.service || portInfo?.app || null,
      product: portInfo?.app || null,
      version: portInfo?.version || null
    }));
    rows.push({
      ip, asn, asName: String(asinfo?.organization || asinfo?.name || provider), provider,
      countryCode: actualCountry, country: countryName || '', city: geo?.city || geo?.subdivisions || '',
      lat: finiteGeo(geo?.latitude ?? geo?.lat), lon: finiteGeo(geo?.longitude ?? geo?.lon),
      prefix: asinfo?.prefix || hit?.cidr || '', observedPorts: ports, confirmedPorts: ports,
      lastSeen: hit?.timestamp || hit?.last_seen || hit?.last_update || '', services,
      sources: ['ZoomEye host search']
    });
  }
  return rows;
}

async function zoomEyeWorldDiscovery(countryCode, ports, providerQuery = '', limit = 16) {
  if (!ZOOMEYE_API_KEY) return { enabled: false, candidates: new Map(), sources: [], errors: [] };
  const cc = safeWorldCountryCode(countryCode);
  if (!cc) return { enabled: true, candidates: new Map(), sources: ['ZoomEye host search'], errors: ['Unsupported ZoomEye country.'] };
  const requestedPorts = normaliseWorldServicePorts(ports).slice(0, 4);
  const portExpr = (requestedPorts.length ? requestedPorts : [80, 443]).map(port => `port="${port}"`).join(' || ');
  const query = `country="${cc}" && (${portExpr})`;
  const key = `${query}|credential:${structuredProviderCredentialHash('ZoomEye')}`;
  const result = await runCachedStructuredSearch({
    provider: 'ZoomEye', cache: zoomeyeSearchCache, inFlight: zoomeyeSearchInFlight, file: ZOOMEYE_SEARCH_CACHE_FILE, key,
    fetchRows: async () => {
      const data = await runZoomEyeSerial(async () => {
        ensureStructuredProviderAvailable('ZoomEye');
        try {
          const result = await fetchJsonUrl(`${ZOOMEYE_BASE}/v2/search`, {
            method: 'POST',
            headers: { 'API-KEY': ZOOMEYE_API_KEY, 'content-type': 'application/json', accept: 'application/json' },
            body: JSON.stringify({ qbase64: Buffer.from(query, 'utf8').toString('base64'), page: 1, pagesize: 20 })
          }, 15000);
          if (result?.code != null && Number(result.code) !== 60000) {
            throw Object.assign(new Error(String(result?.message || `ZoomEye API code ${result.code}`).slice(0, 250)), { statusCode: /auth|key|quota|point|limit|permission/i.test(String(result?.message || '')) ? 403 : 502 });
          }
          return result;
        } catch (error) {
          markStructuredProviderCooldown('ZoomEye', error);
          throw error;
        }
      });
      return zoomEyeHitRows(data, cc);
    }
  });
  const candidates = new Map();
  for (const row of result.rows) addWorldCandidate(candidates, row);
  return { enabled: true, candidates, sources: ['ZoomEye host search'], errors: result.errors };
}

function censysHitRows(data, countryCode) {
  const hits = data?.result?.hits || data?.result?.resources || data?.hits || [];
  const rows = [];
  for (const hit of Array.isArray(hits) ? hits : []) {
    const host = hit?.resource?.host || hit?.host || hit?.resource || hit;
    const ip = String(host?.ip || hit?.ip || host?.host_id || '').trim();
    if (!isIPv4(ip)) continue;
    const location = host?.location || host?.geo || {};
    const autonomous = host?.autonomous_system || host?.autonomousSystem || {};
    const whois = host?.whois || {};
    const organization = whois?.organization || {};
    const network = whois?.network || {};
    const rawCountry = location?.country_code || location?.countryCode || location?.country || autonomous?.country_code || '';
    const actualCountry = normaliseWorldCountryCode(rawCountry);
    if (actualCountry && actualCountry !== countryCode) continue;
    const matched = hit?.matched_services;
    const matchedServiceRows = Array.isArray(matched)
      ? matched
      : (Array.isArray(matched?.['host.services'])
          ? matched['host.services']
          : (matched && typeof matched === 'object' ? Object.values(matched).flatMap(value => Array.isArray(value) ? value : []) : []));
    const services = Array.isArray(host?.services) ? host.services : matchedServiceRows;
    const portSet = new Set();
    for (const service of services) {
      const port = Number(service?.port);
      if (Number.isInteger(port) && port > 0 && port <= 65535) portSet.add(port);
    }
    const portList = [...portSet];
    const asn = netlasAsnNumber(autonomous?.asn ?? autonomous?.number);
    const provider = String(organization?.name || network?.name || autonomous?.name || autonomous?.description || host?.organization || '').trim();
    const coords = location?.coordinates || {};
    const countryName = typeof rawCountry === 'string' && rawCountry.length > 2 ? rawCountry : (COUNTRY_CODES[actualCountry] || actualCountry);
    rows.push({
      ip, asn, asName: String(autonomous?.name || autonomous?.description || provider), provider,
      countryCode: actualCountry, country: countryName || '', city: location?.city || '',
      lat: finiteGeo(coords?.latitude ?? location?.latitude), lon: finiteGeo(coords?.longitude ?? location?.longitude),
      prefix: autonomous?.bgp_prefix || network?.cidr || '', observedPorts: portList, confirmedPorts: portList,
      lastSeen: services.map(service => service?.scan_time || service?.last_updated).filter(Boolean).sort().pop() || host?.last_updated || '',
      services: services.map(service => ({
        port: Number(service?.port), transport: service?.transport_protocol || 'tcp',
        serviceName: SERVICE_MAP[Number(service?.port)] || service?.protocol || service?.service_name || null,
        protocol: service?.protocol || service?.service_name || null,
        product: service?.software?.product || service?.software?.uniform_resource_identifier || null,
        version: service?.software?.version || null
      })).filter(service => Number.isInteger(service.port) && service.port > 0),
      sources: ['Censys Platform search']
    });
  }
  return rows;
}

async function censysWorldDiscovery(countryCode, ports, providerQuery = '', limit = 16) {
  if (!CENSYS_API_TOKEN) return { enabled: false, candidates: new Map(), sources: [], errors: [] };
  const cc = safeWorldCountryCode(countryCode);
  if (!cc) return { enabled: true, candidates: new Map(), sources: ['Censys Platform search'], errors: ['Unsupported Censys country.'] };
  const requestedPorts = normaliseWorldServicePorts(ports).slice(0, 4);
  const countryName = SUPPORTED_WORLD_COUNTRIES[cc]?.name || cc;
  const portExpr = (requestedPorts.length ? requestedPorts : [80, 443]).map(port => `host.services.port = "${port}"`).join(' or ');
  const query = `host.location.country = "${countryName}" and (${portExpr})`;
  const key = `${query}|org:${CENSYS_ORGANIZATION_ID || 'free'}|credential:${structuredProviderCredentialHash('Censys')}`;
  const result = await runCachedStructuredSearch({
    provider: 'Censys', cache: censysSearchCache, inFlight: censysSearchInFlight, file: CENSYS_SEARCH_CACHE_FILE, key,
    fetchRows: async () => {
      const url = new URL(`${CENSYS_BASE}/v3/global/search/query`);
      if (CENSYS_ORGANIZATION_ID) url.searchParams.set('organization_id', CENSYS_ORGANIZATION_ID);
      const headers = { accept: 'application/json', 'content-type': 'application/json', authorization: `Bearer ${CENSYS_API_TOKEN}` };
      const data = await runCensysSerial(async () => {
        ensureStructuredProviderAvailable('Censys');
        try {
          return await fetchJsonUrl(url.href, {
            method: 'POST', headers,
            body: JSON.stringify({
              query, page_size: 20,
              fields: ['host.ip','host.location.country','host.location.country_code','host.location.city','host.location.coordinates.latitude','host.location.coordinates.longitude','host.autonomous_system.asn','host.autonomous_system.name','host.autonomous_system.description','host.autonomous_system.bgp_prefix','host.whois.organization.name','host.whois.network.name','host.services.port','host.services.protocol','host.services.transport_protocol','host.services.scan_time','host.services.software.product','host.services.software.version']
            })
          }, 18000);
        } catch (error) {
          markStructuredProviderCooldown('Censys', error);
          throw error;
        }
      });
      if (data?.error || data?.detail) {
        const error = Object.assign(new Error(String(data?.detail || data?.error || 'Censys API returned an error').slice(0, 280)), { statusCode: Number(data?.status || data?.status_code || 0) || undefined });
        markStructuredProviderCooldown('Censys', error);
        throw error;
      }
      return censysHitRows(data, cc);
    }
  });
  const candidates = new Map();
  for (const row of result.rows) addWorldCandidate(candidates, row);
  return { enabled: true, candidates, sources: ['Censys Platform search'], errors: result.errors };
}

async function shodanWorldDiscovery(countryCode, ports, providerQuery = '', limit = 16) {
  if (!SHODAN_API_KEY) return { enabled: false, candidates: new Map(), sources: [], errors: [] };
  const cc = safeWorldCountryCode(countryCode);
  if (!cc) return { enabled: true, candidates: new Map(), sources: [], errors: ['Unsupported Shodan country.'] };

  // Shodan ORs comma-separated filter values. One query covers common HTTP/HTTPS
  // ports instead of spending one query credit on port 443 and another on port 80.
  let query = `country:${cc} port:443,80`;
  const provider = String(providerQuery || '').trim().replace(/[^\w .:+&()\/-]/g, '').slice(0, 80);
  if (provider) query += ` org:"${provider.replace(/"/g, '')}"`;
  const cached = shodanSearchCache[query];
  let rows = null;
  if (cached && Date.now() - Number(cached.at) < SHODAN_SEARCH_CACHE_TTL && Array.isArray(cached.rows)) {
    rows = cached.rows;
  } else if (shodanSearchInFlight.has(query)) {
    const result = await shodanSearchInFlight.get(query);
    if (result?.error) return { enabled: true, skipped: true, candidates: new Map(), sources: [], errors: [result.error] };
    rows = result?.rows || [];
  } else {
    const pending = (async () => {
      if (!(await shodanDiscoveryUsable())) {
        const reason = shodanDiscoveryState.queryCredits === 0
          ? 'Shodan host search skipped because query credits are exhausted.'
          : 'Shodan host search skipped because remaining query credits could not be confirmed.';
        recordServerProblem('Shodan', reason, 'warning');
        return { rows: null, error: reason };
      }
      const data = await shodanApi('/shodan/host/search', { query, page: 1, minify: 'true' }, 15000);
      clearServerProblem('Shodan');
      return { rows: shodanRowsFromMatches(data?.matches, cc, '443,80'), error: null };
    })();
    shodanSearchInFlight.set(query, pending);
    try {
      const result = await pending;
      if (result.error) return { enabled: true, skipped: true, candidates: new Map(), sources: [], errors: [result.error] };
      rows = result.rows || [];
      const now = Date.now();
      shodanSearchCache[query] = { at: now, rows };
      const fresh = Object.entries(shodanSearchCache)
        .filter(([, entry]) => entry && Array.isArray(entry.rows) && now - Number(entry.at) <= SHODAN_SEARCH_CACHE_TTL)
        .sort((a, b) => Number(b[1].at) - Number(a[1].at))
        .slice(0, 80);
      shodanSearchCache = Object.fromEntries(fresh);
      writeSmallCache(SHODAN_SEARCH_CACHE_FILE, shodanSearchCache);
    } catch (error) {
      recordServerProblem('Shodan', `Shodan search: ${error.message}`);
      return { enabled: true, candidates: new Map(), sources: ['Shodan host search'], errors: [`Shodan search: ${error.message}`] };
    } finally {
      shodanSearchInFlight.delete(query);
    }
  }

  const candidates = new Map();
  for (const row of rows || []) addWorldCandidate(candidates, row);
  return { enabled: true, candidates, sources: ['Shodan host search'], errors: [] };
}

async function netlasDownload(query, size = AUTO_DISCOVERY_SIZE_PER_COUNTRY, fields = []) {
  if (!NETLAS_API_KEY) throw new Error('NETLAS_API_KEY is not configured.');
  if (netlasQuotaIsBlocked()) throw Object.assign(new Error(netlasQuotaBlockReason || 'Netlas quota cooldown is active.'), { statusCode: 429 });
  const normalizedSize = Math.min(Math.max(Number(size) || AUTO_DISCOVERY_SIZE_PER_COUNTRY, 1), 100);
  const cacheKey = `download:${JSON.stringify([String(query || ''), normalizedSize, [...(fields || [])].sort()])}`;
  const cached = netlasQueryCache[cacheKey];
  if (cached && cached.data && Date.now() - Number(cached.at) < NETLAS_QUERY_CACHE_TTL) return cached.data;
  if (netlasQueryInFlight.has(cacheKey)) return netlasQueryInFlight.get(cacheKey);
  const pending = (async () => {
    const payload = { query, size: normalizedSize };
    if (Array.isArray(fields) && fields.length) payload.fields = fields;
    const response = await fetchText(`${NETLAS_BASE}/responses/download/`, {
      method: 'POST',
      headers: { accept: 'application/json', authorization: `Bearer ${NETLAS_API_KEY}`, 'content-type': 'application/json' },
      body: JSON.stringify(payload)
    }, 20000);
    const raw = await response.text();
    if (!response.ok) {
      let detail = raw; try { const x = JSON.parse(raw); detail = x?.detail || x?.error || x?.message || raw; } catch (_) {}
      throw Object.assign(new Error(`Netlas download HTTP ${response.status}: ${String(detail).slice(0,220)}`), { statusCode: response.status });
    }
    let parsed;
    try { parsed = raw ? JSON.parse(raw) : []; } catch (_) { return []; }
    const payloadError = netlasPayloadError(parsed);
    if (payloadError) throw Object.assign(new Error(payloadError.message), { statusCode: payloadError.statusCode, quotaOrAuth: payloadError.quotaOrAuth });
    const now = Date.now();
    netlasQueryCache[cacheKey] = { at: now, data: parsed };
    netlasQueryCache = Object.fromEntries(Object.entries(netlasQueryCache)
      .filter(([, entry]) => entry && entry.data && now - Number(entry.at) < NETLAS_QUERY_CACHE_TTL)
      .sort((a,b) => Number(b[1].at) - Number(a[1].at)).slice(0, 250));
    writeSmallCache(NETLAS_QUERY_CACHE_FILE, netlasQueryCache);
    return parsed;
  })();
  netlasQueryInFlight.set(cacheKey, pending);
  try { return await pending; } finally { netlasQueryInFlight.delete(cacheKey); }
}

async function netlasBulkCountryDiscovery(countryCode, providerQuery = '', size = AUTO_DISCOVERY_SIZE_PER_COUNTRY) {
  const cc = safeWorldCountryCode(countryCode);
  if (!cc || !NETLAS_API_KEY) return { candidates: new Map(), errors: [], queriesTried: 0 };
  if (netlasQuotaIsBlocked()) return { candidates: new Map(), errors: takeNetlasQuotaNotice(), queriesTried: 0 };
  const candidates = new Map();
  const errors = [];
  const fields = ['ip','port','prot4','prot7','protocol','geo.country','geo.city','geo.continent','geo.location.lat','geo.location.lon','isp','whois.asn.name','whois.asn.number','whois.net.name','whois.net.organization','last_updated','http.title'];
  const sizeN = Math.min(Math.max(Number(size) || 50, 20), 80);
  const provider = String(providerQuery || '').trim();
  const terms = providerSearchTerms(provider).map(x => String(x).replace(/["]+/g, '').trim()).filter(Boolean).slice(0, 3);
  // One provider-focused query first, then one country-wide fallback. This keeps the
  // 32-runs/day collector useful while minimizing Netlas Community API consumption.
  const queries = [];
  if (terms.length) {
    const orgExpr = terms.map(t => `whois.net.organization:"${t}"`).join(' OR ');
    const ispExpr = terms.map(t => `isp:"${t}"`).join(' OR ');
    queries.push(`geo.country:${cc} AND host_type:ip AND ((${orgExpr}) OR (${ispExpr}))`);
  }
  queries.push(`geo.country:${cc} AND host_type:ip`);
  let queriesTried = 0;
  for (const q of queries.slice(0, 2)) {
    queriesTried++;
    try {
      const data = await netlasDownload(q, sizeN, fields);
      for (const row of netlasWorldPortRows(data)) {
        if (row.countryCode && row.countryCode !== cc) continue;
        addWorldCandidate(candidates, {
          ...row,
          countryCode: row.countryCode || '',
          country: row.country || '',
          sources: [`Netlas Download${provider && q.includes('whois.net.organization') ? ' provider search' : ' country search'}`]
        });
        if (candidates.size >= sizeN) break;
      }
      if (candidates.size >= sizeN) break;
    } catch (e) {
      const blocked = markNetlasQuotaBlocked(e, true);
      errors.push(blocked ? `Netlas paused to protect API quota: ${e.message}` : e.message);
      if (blocked || [401,402,403,429].includes(Number(e.statusCode))) break;
    }
  }
  return { candidates, errors, queriesTried };
}
async function probeDiscoveredRows(rows, maxRows = AUTO_DISCOVERY_PROBE_PER_COUNTRY) {
  const selected = Array.isArray(rows) ? rows.slice(0, maxRows) : [];
  const out = [];
  await runLimited(selected, 3, async row => {
    let measured = null;
    try {
      const result = await globalWorldPing(row.ip, ['DE', 'FR', 'NL']);
      if (result?.ok) measured = { ...result, source: 'Globalping' };
    } catch (_) {}
    out.push({ ...row, ping: measured || row.ping || null, lastSeen: new Date().toISOString(), sources: [...new Set([...(row.sources||[]), ...(measured ? ['Globalping'] : [])])] });
  });
  const byIp = new Map(out.map(x => [x.ip, x]));
  return selected.map(x => byIp.get(x.ip) || x);
}

function loadAutoDiscoveryState(){try{const x=JSON.parse(fs.readFileSync(AUTO_DISCOVERY_STATE_FILE,'utf8'));return x&&typeof x==='object'?x:{}}catch(_){return {}}}
function saveAutoDiscoveryState(data){ensureDataDir();try{fs.writeFileSync(AUTO_DISCOVERY_STATE_FILE,JSON.stringify(data,null,2))}catch(_){}}
let autoDiscoveryState=loadAutoDiscoveryState();
let autoDiscoveryTimer=null;
let autoDiscoveryNextAt=null;
function isAutoDiscoveryEnabled(){return false}
function resetAutoDiscoveryDay(){const day=new Date().toISOString().slice(0,10);const enabled=autoDiscoveryState.enabled;if(autoDiscoveryState.day!==day)autoDiscoveryState={day,runsToday:0,lastRunAt:null,lastByCountry:{},lastError:null,enabled:enabled==null?AUTO_DISCOVERY_DEFAULT_ENABLED:Boolean(enabled),providerIndex:autoDiscoveryState.providerIndex||{},initialWarmupDone:autoDiscoveryState.initialWarmupDone||false};if(!autoDiscoveryState.lastByCountry||typeof autoDiscoveryState.lastByCountry!=='object')autoDiscoveryState.lastByCountry={};if(!autoDiscoveryState.providerIndex||typeof autoDiscoveryState.providerIndex!=='object')autoDiscoveryState.providerIndex={}}
function stopAutoDiscoveryScheduler(){if(autoDiscoveryTimer){clearTimeout(autoDiscoveryTimer);autoDiscoveryTimer=null}autoDiscoveryNextAt=null}
function setAutoDiscoveryEnabled(enabled){autoDiscoveryState.enabled=false;saveAutoDiscoveryState(autoDiscoveryState);stopAutoDiscoveryScheduler();return false}
function pickAutoDiscoveryCountries(){resetAutoDiscoveryDay();return [...DEFAULT_SELECTED_WORLD_COUNTRIES].sort((a,b)=>Number(autoDiscoveryState.lastByCountry?.[a]||0)-Number(autoDiscoveryState.lastByCountry?.[b]||0)).slice(0,1)}
function pickAutoProvider(cc){const list=DATACENTER_PROVIDERS_BY_COUNTRY[cc]||[];if(!list.length)return '';const idx=Number(autoDiscoveryState.providerIndex?.[cc]||0)%list.length;autoDiscoveryState.providerIndex[cc]=(idx+1)%list.length;return list[idx]}
const IP_GEO_CACHE_FILE = path.join(__dirname, 'data', 'ip-geo-cache.json');
const IP_GEO_USAGE_FILE = path.join(__dirname, 'data', 'ipwhois-usage.json');
const IP_GEO_ENABLED = !/^(0|false|no|off)$/i.test(String(process.env.IPWHOIS_ENABLED ?? 'true'));
const IP_GEO_BASE_URL = String(process.env.IPWHOIS_BASE_URL || 'https://ipwho.is').replace(/\/+$/, '');
const IP_GEO_TIMEOUT_MS = Math.min(Math.max(Number(process.env.IPWHOIS_TIMEOUT_MS || 7000), 3000), 20000);
const IP_GEO_CACHE_TTL = Math.min(Math.max(Number(process.env.IPWHOIS_CACHE_TTL_MS || 2592000000), 3600000), 7776000000);
const IP_GEO_FAILURE_TTL = Math.min(Math.max(Number(process.env.IPWHOIS_FAILURE_TTL_MS || 21600000), 60000), 86400000);
// The public IPWho.is endpoint documents a 1,000-request/day free limit. Keep a buffer for other traffic.
const IP_GEO_MAX_REQUESTS_PER_DAY = Math.min(Math.max(Number(process.env.IPWHOIS_MAX_REQUESTS_PER_DAY || 900), 1), 1000);
let ipGeoUsage = readSmallCache(IP_GEO_USAGE_FILE);
function reserveIpGeoRequest() {
  const today = new Date().toISOString().slice(0, 10);
  if (ipGeoUsage.day !== today) ipGeoUsage = { day: today, count: 0 };
  const used = Math.max(0, Number(ipGeoUsage.count) || 0);
  if (used >= IP_GEO_MAX_REQUESTS_PER_DAY) return false;
  ipGeoUsage = { day: today, count: used + 1, limit: IP_GEO_MAX_REQUESTS_PER_DAY, updatedAt: new Date().toISOString() };
  writeSmallCache(IP_GEO_USAGE_FILE, ipGeoUsage);
  return true;
}
let ipGeoCache = readSmallCache(IP_GEO_CACHE_FILE);
for (const [ip, entry] of Object.entries(ipGeoCache)) {
  if (!entry || !Number.isFinite(Number(entry.at)) || Date.now() - Number(entry.at) > (entry.ok ? IP_GEO_CACHE_TTL : IP_GEO_FAILURE_TTL)) delete ipGeoCache[ip];
}
const ipGeoInFlight = new Map();
async function ipGeolocation(ip) {
  if (!IP_GEO_ENABLED || !isValidIP(ip)) return null;
  const cached = ipGeoCache[ip];
  if (cached && Date.now() - Number(cached.at) < (cached.ok ? IP_GEO_CACHE_TTL : IP_GEO_FAILURE_TTL)) {
    // Existing successful cache entries were created by the same IPWho.is lookup, before the source field existed.
    return cached.ok ? { ...cached, source: cached.source || 'IPWho.is' } : null;
  }
  if (ipGeoInFlight.has(ip)) return ipGeoInFlight.get(ip);
  const pending = (async () => {
    let entry = { at: Date.now(), ok: false, countryCode: '', country: '', city: '', lat: null, lon: null, provider: '', org: '', asn: '', source: 'IPWho.is' };
    if (!reserveIpGeoRequest()) return null;
    try {
      const data = await fetchJsonUrl(`${IP_GEO_BASE_URL}/${encodeURIComponent(ip)}`, { headers: { accept: 'application/json' } }, IP_GEO_TIMEOUT_MS);
      const countryCode = String(data?.country_code || '').toUpperCase();
      if (data?.success !== false && /^[A-Z]{2}$/.test(countryCode)) {
        const connection = data?.connection || {};
        const org = String(connection.org || data?.org || '').trim();
        const provider = String(org || connection.isp || data?.isp || '').trim();
        entry = {
          at: Date.now(), ok: true, countryCode,
          country: String(data?.country || COUNTRY_CODES[countryCode] || countryCode),
          city: String(data?.city || ''),
          lat: finiteGeo(data?.latitude), lon: finiteGeo(data?.longitude),
          provider, org,
          asn: String(connection.asn ?? data?.asn ?? '').replace(/^AS/i, ''),
          source: 'IPWho.is'
        };
      }
    } catch (error) {
      entry.error = String(error?.message || error).slice(0, 180);
    }
    ipGeoCache[ip] = entry;
    const now = Date.now();
    ipGeoCache = Object.fromEntries(Object.entries(ipGeoCache)
      .filter(([, value]) => value && now - Number(value.at) <= (value.ok ? IP_GEO_CACHE_TTL : IP_GEO_FAILURE_TTL))
      .sort((a, b) => Number(b[1].at) - Number(a[1].at))
      .slice(0, 20000));
    writeSmallCache(IP_GEO_CACHE_FILE, ipGeoCache);
    return entry.ok ? entry : null;
  })();
  ipGeoInFlight.set(ip, pending);
  try { return await pending; } finally { ipGeoInFlight.delete(ip); }
}

async function verifyWorldCandidateCountries(candidateMap, expectedCountry, ports, maxCandidates = 20) {
  const cc = safeWorldCountryCode(expectedCountry);
  if (!cc || !(candidateMap instanceof Map) || !candidateMap.size) return 0;
  const toCheck = finalizeWorldCandidates(candidateMap, ports || [], Math.min(20, Math.max(12, Number(maxCandidates) || 20)));
  const verified = new Map();
  await runLimited(toCheck, 4, async row => {
    const geo = await ipGeolocation(row.ip);
    if (geo) {
      if (geo.countryCode !== cc) return;
      addWorldCandidate(verified, {
        ...row, countryCode: geo.countryCode, country: geo.country || row.country || COUNTRY_CODES[cc] || cc,
        city: geo.city || row.city || '', lat: geo.lat ?? row.lat, lon: geo.lon ?? row.lon,
        sources: [...(row.sources || []), 'IP geolocation verification']
      });
      return;
    }
    // If the independent geolocation API is unavailable, retain only rows with a
    // country explicitly reported by a structured intelligence provider. Never trust
    // search-engine-extracted IPs or an assumed requested country as proof of location.
    const structuredSource = (row.sources || []).some(source => /Shodan host search|Shodan host details|Netlas response search|Netlas Download|Netlas host details|ZoomEye host search|Censys Platform search/i.test(source));
    if (structuredSource && String(row.countryCode || '').toUpperCase() === cc) addWorldCandidate(verified, row);
  });
  candidateMap.clear();
  for (const [ip, row] of verified) candidateMap.set(ip, row);
  return verified.size;
}

async function runAutoDiscoveryCycle(reason='schedule') {
  if (!isAutoDiscoveryEnabled() || autoDiscoveryRunning) return { ok: false, skipped: true, reason: 'disabled-or-running' };
  if (!TAVILY_API_KEY) {
    const error = 'Tavily is required for discovery. Configure TAVILY_API_KEY in the server environment.';
    autoDiscoveryState.lastError = [error];
    saveAutoDiscoveryState(autoDiscoveryState);
    return { ok: false, error };
  }
  resetAutoDiscoveryDay();
  if (Number(autoDiscoveryState.runsToday || 0) >= AUTO_DISCOVERY_RUNS_PER_DAY) return { ok: false, skipped: true, reason: 'daily-limit' };
  autoDiscoveryRunning = true;
  const countries = pickAutoDiscoveryCountries();
  const groups = [];
  let newIps = 0;
  const errors = [];
  try {
    for (const cc of countries) {
      const provider = pickAutoProvider(cc);
      let result = await netlasBulkCountryDiscovery(cc, provider, AUTO_DISCOVERY_SIZE_PER_COUNTRY);
      if (!result.candidates.size) result = await netlasBulkCountryDiscovery(cc, '', Math.min(AUTO_DISCOVERY_SIZE_PER_COUNTRY, 40));

      // Tavily is mandatory for each scheduled country cycle. Its extracted IPs are
      // merged with structured-provider observations, then validated and probed below.
      try {
        const tavily = await tavilyWorldDiscovery(SUPPORTED_WORLD_COUNTRIES[cc].name, cc, [443, 80], provider);
        for (const ip of tavily.ips || []) addWorldCandidate(result.candidates, {
          ip, sources: ['Tavily Search']
        });
        if (tavily.errors?.length) result.errors.push(...tavily.errors.map(error => `Tavily: ${error}`));
        if (tavily.asns?.length && CHECK_HOST_API_KEY) {
          for (const asn of tavily.asns.slice(0, 2)) {
            try {
              const data = await checkHostApi(`/as/${asn}`, { timeout: 9000 });
              for (const sample of (data?.data?.pingable_top || []).slice(0, 2)) addWorldCandidate(result.candidates, {
                ip: sample?.ip, asn, provider: data?.data?.as_name || `AS${asn}`,
                asName: data?.data?.as_name || `AS${asn}`, sources: ['Check-Host ASN enrichment']
              });
            } catch (error) { result.errors.push(`Check-Host ASN enrichment: ${error.message}`); }
          }
        }
      } catch (error) {
        result.errors.push(`Tavily: ${error.message}`);
      }

      if (result.candidates.size < Math.min(8, AUTO_DISCOVERY_SIZE_PER_COUNTRY)) {
        const [zoomEye, censys] = await Promise.all([
          zoomEyeWorldDiscovery(cc, [443, 80], provider, Math.min(AUTO_DISCOVERY_SIZE_PER_COUNTRY, 16)),
          censysWorldDiscovery(cc, [443, 80], provider, Math.min(AUTO_DISCOVERY_SIZE_PER_COUNTRY, 16))
        ]);
        for (const row of zoomEye.candidates.values()) addWorldCandidate(result.candidates, row);
        for (const row of censys.candidates.values()) addWorldCandidate(result.candidates, row);
        result.errors.push(...(zoomEye.errors || []), ...(censys.errors || []));
      }

      if (!result.candidates.size && SHODAN_API_KEY && await shodanDiscoveryUsable()) {
        try {
          const sh = await shodanWorldDiscovery(cc, [443, 80], provider, Math.min(AUTO_DISCOVERY_SIZE_PER_COUNTRY, 16));
          for (const row of sh.candidates.values()) addWorldCandidate(result.candidates, { ...row, sources: [...(row.sources || []), 'Shodan'] });
          result.errors.push(...(sh.errors || []));
        } catch (error) { result.errors.push(error.message); }
      }
      await verifyWorldCandidateCountries(result.candidates, cc, [443, 80], 20);
      const rows = [...result.candidates.values()];
      const probed = await probeDiscoveredRows(rows, AUTO_DISCOVERY_PROBE_PER_COUNTRY);
      groups.push({ country: cc, countryName: COUNTRY_CODES[cc] || cc, provider, results: probed, summary: { found: probed.length } });
      if (result.errors?.length) errors.push(...result.errors.map(error => `${cc}: ${error}`));
      autoDiscoveryState.lastByCountry[cc] = Date.now();
    }
    newIps = recordWorldDiscovery({ countries: groups });
    autoDiscoveryState.runsToday = Number(autoDiscoveryState.runsToday || 0) + 1;
    autoDiscoveryState.lastRunAt = new Date().toISOString();
    autoDiscoveryState.lastReason = reason;
    autoDiscoveryState.lastCountries = countries;
    autoDiscoveryState.lastNewIps = newIps;
    autoDiscoveryState.lastError = errors.slice(0, 8);
    saveAutoDiscoveryState(autoDiscoveryState);
    return { ok: true, countries, groups, newIps, runsToday: autoDiscoveryState.runsToday, errors: errors.slice(0, 8) };
  } catch (error) {
    autoDiscoveryState.lastError = [error.message];
    saveAutoDiscoveryState(autoDiscoveryState);
    return { ok: false, error: error.message, countries, newIps: 0 };
  } finally {
    autoDiscoveryRunning = false;
  }
}
async function warmupAutoDiscoveryIfEmpty(){if(!isAutoDiscoveryEnabled())return;resetAutoDiscoveryDay();if(persistedWorldResults.length||autoDiscoveryState.initialWarmupDone){autoDiscoveryState.initialWarmupDone=true;saveAutoDiscoveryState(autoDiscoveryState);return}await runAutoDiscoveryCycle('initial-warmup').catch(()=>null);autoDiscoveryState.initialWarmupDone=true;saveAutoDiscoveryState(autoDiscoveryState)}
function startAutoDiscoveryScheduler(){if(!isAutoDiscoveryEnabled()||autoDiscoveryTimer)return;resetAutoDiscoveryDay();saveAutoDiscoveryState(autoDiscoveryState);const scheduleNext=(delay)=>{autoDiscoveryNextAt=new Date(Date.now()+delay).toISOString();autoDiscoveryTimer=setTimeout(async()=>{autoDiscoveryTimer=null;try{resetAutoDiscoveryDay();if(Number(autoDiscoveryState.runsToday||0)<AUTO_DISCOVERY_RUNS_PER_DAY)await runAutoDiscoveryCycle('schedule')}catch(_){}if(isAutoDiscoveryEnabled()&&Number(autoDiscoveryState.runsToday||0)<AUTO_DISCOVERY_RUNS_PER_DAY){const sinceLast=autoDiscoveryState.lastRunAt?Date.now()-Date.parse(autoDiscoveryState.lastRunAt):0;scheduleNext(Math.max(30000,Number.isFinite(sinceLast)?autoDiscoveryIntervalMs-sinceLast:autoDiscoveryIntervalMs))}else autoDiscoveryNextAt=null},Math.max(30000,delay));autoDiscoveryTimer.unref?.()};const last=autoDiscoveryState.lastRunAt?Date.parse(autoDiscoveryState.lastRunAt):0;const elapsed=last?Date.now()-last:Infinity;if(Number(autoDiscoveryState.runsToday||0)<AUTO_DISCOVERY_RUNS_PER_DAY&&elapsed>=autoDiscoveryIntervalMs){autoDiscoveryNextAt=new Date(Date.now()+10000).toISOString();autoDiscoveryTimer=setTimeout(async()=>{autoDiscoveryTimer=null;try{await runAutoDiscoveryCycle('startup')}catch(_){}if(Number(autoDiscoveryState.runsToday||0)<AUTO_DISCOVERY_RUNS_PER_DAY)scheduleNext(autoDiscoveryIntervalMs);else autoDiscoveryNextAt=null},10000);autoDiscoveryTimer.unref?.()}else if(Number(autoDiscoveryState.runsToday||0)<AUTO_DISCOVERY_RUNS_PER_DAY){scheduleNext(Math.max(30000,autoDiscoveryIntervalMs-Math.max(0,elapsed)))}}

async function discoverWorldDatacenters(countryCode, ports, providerQuery = '', limit = WORLD_DISCOVERY_PER_COUNTRY, probeCountries = WORLD_COUNTRY_CODES) {
  const cc = safeWorldCountryCode(countryCode);
  if (!cc) throw Object.assign(new Error('Unsupported country.'), { statusCode: 400 });
  if (!TAVILY_API_KEY) throw Object.assign(new Error('Tavily is required for World Discovery. Configure TAVILY_API_KEY in the server environment, then retry.'), { statusCode: 503 });
  const usePorts = normaliseWorldServicePorts(ports).slice(0, 4);
  const wantedLimit = Math.min(Math.max(Number(limit || WORLD_DISCOVERY_PER_COUNTRY), 1), WORLD_DISCOVERY_PER_COUNTRY);
  const probeCodes = [...new Set((probeCountries || WORLD_COUNTRY_CODES).map(safeWorldCountryCode).filter(Boolean))];
  const cacheKey = `${cc}|${usePorts.join(',')}|${providerQuery.trim().toLowerCase()}|${wantedLimit}|${probeCodes.join(',')}`;
  const cached = worldDiscoveryCache.get(cacheKey);
  // Reuse an identical recent result (including Tavily) so repeat clicks do not
  // spend API credits repeatedly. New filters/queries still trigger a fresh search.
  if (cached && Date.now() - cached.at < WORLD_DISCOVERY_CACHE_TTL) return cached.data;

  const [shodan, netlas, zoomEye, censys] = await Promise.all([
    shodanWorldDiscovery(cc, usePorts, providerQuery, wantedLimit),
    netlasWorldDiscovery(cc, usePorts, providerQuery, wantedLimit),
    zoomEyeWorldDiscovery(cc, usePorts, providerQuery, wantedLimit),
    censysWorldDiscovery(cc, usePorts, providerQuery, wantedLimit)
  ]);
  const candidates = new Map();
  for (const row of shodan.candidates.values()) addWorldCandidate(candidates, row);
  for (const row of netlas.candidates.values()) addWorldCandidate(candidates, row);
  for (const row of zoomEye.candidates.values()) addWorldCandidate(candidates, row);
  for (const row of censys.candidates.values()) addWorldCandidate(candidates, row);

  // Tavily is a required source for every selected country when its API key is configured.
  // Structured providers still run in parallel, and all returned IPs are validated before saving.
  let tavily = { enabled: false, ran: false, ips: [], asns: [], sources: [], errors: [] };
  if (TAVILY_API_KEY) {
    const tavilyResult = await tavilyWorldDiscovery(SUPPORTED_WORLD_COUNTRIES[cc].name, cc, usePorts, providerQuery);
    tavily = { ...tavilyResult, enabled: true, ran: true };
    for (const ip of tavily.ips || []) addWorldCandidate(candidates, {
      ip, sources: ['Tavily Search']
    });
    if (tavily.asns?.length && CHECK_HOST_API_KEY) {
      for (const asn of tavily.asns.slice(0, 2)) {
        try {
          const data = await checkHostApi(`/as/${asn}`, { timeout: 9000 });
          for (const sample of (data?.data?.pingable_top || []).slice(0, 2)) addWorldCandidate(candidates, {
            ip: sample?.ip, asn, provider: data?.data?.as_name || `AS${asn}`,
            asName: data?.data?.as_name || `AS${asn}`, sources: ['Check-Host ASN enrichment']
          });
        } catch (error) { (tavily.errors ||= []).push(`Check-Host ASN enrichment: ${error.message}`); }
      }
    }
  } else {
    tavily.errors.push('TAVILY_API_KEY is not configured; Tavily search was not run.');
  }

  // Verify geographic country independently before ranking, enrichment, and saving.
  // This removes Tavily/search snippets that mention IPs located in a different country.
  await verifyWorldCandidateCountries(candidates, cc, usePorts, 20);
  const all = finalizeWorldCandidates(candidates, usePorts, wantedLimit);
  // Enrich only the top few rows. This keeps token usage low while still showing
  // provider, ASN, observed ports and service details for the best candidates.
  const top = all.filter(row => !row.provider || !row.asn || !row.city || row.lat == null || row.lon == null || !(row.observedPorts || []).length).slice(0, WORLD_ENRICH_PER_COUNTRY);
  const shodanUsable = Boolean(SHODAN_API_KEY);
  const enriched = await runLimited(top, 2, async row => {
    let host = null, net = null, ipinfo = null;
    if (shodanUsable && (!row.provider || !row.asn || !row.city || row.lat == null || row.lon == null)) host = await shodanHostDetails(row.ip);
    if (NETLAS_API_KEY && (!row.provider || !row.asn || !row.city || row.lat == null || row.lon == null || !(row.observedPorts || []).length || !(row.prefix || ''))) net = await netlasHostDetails(row.ip);
    if (IPINFO_TOKEN && (!row.countryCode || !row.asn || !row.provider || row.lat == null || row.lon == null)) ipinfo = await ipinfoLiteLookup(row.ip);
    return { row, host, net, ipinfo };
  });
  for (const item of enriched) {
    const r = item.row;
    const host = item.host;
    const net = item.net;
    const ipinfo = item.ipinfo;
    if (host && String(host.countryCode || '').toUpperCase() === cc) addWorldCandidate(candidates, {
      ip: r.ip, asn: host.asn, asName: host.asName, provider: host.provider,
      countryCode: cc, country: SUPPORTED_WORLD_COUNTRIES[cc].name, city: host.city, lat: host.lat, lon: host.lon,
      observedPorts: host.ports, confirmedPorts: host.ports.filter(p => usePorts.includes(p)),
      lastSeen: host.lastSeen, services: host.services, sources: ['Shodan host details']
    });
    if (net && (!net.countryCode || net.countryCode === cc)) addWorldCandidate(candidates, {
      ip: r.ip, asn: net.asn, asName: net.asName, provider: net.provider,
      countryCode: cc, country: SUPPORTED_WORLD_COUNTRIES[cc].name, city: net.city, lat: net.lat, lon: net.lon,
      prefix: net.prefix, observedPorts: net.ports, confirmedPorts: net.ports.filter(p => usePorts.includes(p)),
      lastSeen: net.lastSeen, services: net.services, sources: ['Netlas host details']
    });
    if (ipinfo && (!r.countryCode || String(ipinfo.country || '').toUpperCase() === cc)) addWorldCandidate(candidates, {
      ip: r.ip, countryCode: cc, country: SUPPORTED_WORLD_COUNTRIES[cc].name,
      asn: netlasAsnNumber(ipinfo.asn), provider: ipinfo.org || '', asName: ipinfo.asn || '', sources: ['IPinfo Lite']
    });
  }

  const finalResults = finalizeWorldCandidates(candidates, usePorts, wantedLimit);
  let pinged = 0;
  // One representative IP per country keeps Check-Host usage low while still showing
  // latency from the selected global probe countries. Additional discovered IPs retain
  // their passive service/port intelligence without triggering extra ping jobs.
  const pingTargets = finalResults.slice(0, WORLD_PING_PER_COUNTRY);
  const pingRegions = probeCodes.length ? probeCodes : ['DE','FR'];
  const pingedRows = await Promise.all(pingTargets.map(async row => ({ row, ping: await globalWorldPing(row.ip, pingRegions) })));
  for (const item of pingedRows) {
    const row = candidates.get(item.row.ip);
    if (row) { row.ping = item.ping; if (item.ping?.ok) pinged++; }
  }

  const result = {
    ok: finalResults.length > 0,
    country: cc,
    countryName: SUPPORTED_WORLD_COUNTRIES[cc].name,
    results: finalizeWorldCandidates(candidates, usePorts, wantedLimit),
    summary: {
      candidateCount: candidates.size,
      providers: new Set(finalResults.map(x => x.provider || x.asName).filter(Boolean)).size,
      confirmedPortHits: finalResults.reduce((n, x) => n + usePorts.filter(p => x.confirmedPorts.includes(p)).length, 0),
      pinged,
      avgPingMs: (() => {
        const values = finalizeWorldCandidates(candidates, usePorts, wantedLimit).map(x => x.ping?.avgMs).filter(Number.isFinite);
        return values.length ? Math.round(values.reduce((a,b)=>a+b,0)/values.length) : null;
      })()
    },
    sources: {
      shodan: Boolean(SHODAN_API_KEY), netlas: Boolean(NETLAS_API_KEY),
      zoomeye: Boolean(ZOOMEYE_API_KEY), censys: Boolean(CENSYS_API_TOKEN), ipinfo: Boolean(IPINFO_TOKEN), tavily: Boolean(tavily.enabled), tavilyRan: Boolean(tavily.ran), checkHost: true
    },
    tavily: { configured: Boolean(TAVILY_API_KEY), ran: Boolean(tavily.ran), foundIPs: (tavily.ips || []).length, sources: tavily.sources || [] },
    errors: [...(shodan.errors || []), ...(netlas.errors || []), ...(zoomEye.errors || []), ...(censys.errors || []), ...(tavily.errors || []), ...takeNetlasQuotaNotice()]
  };
  worldDiscoveryCache.set(cacheKey, { at: Date.now(), data: result });
  return result;
}

async function discoverWorldCountries(countries, ports, providerQueryByCountry = {}, limit = WORLD_DISCOVERY_PER_COUNTRY) {
  const requested = [...new Set((countries || []).map(safeWorldCountryCode).filter(Boolean))];
  if (!requested.length) throw Object.assign(new Error('Choose at least one enabled country.'), { statusCode: 400 });
  const groups = await runLimited(requested, WORLD_DISCOVERY_CONCURRENCY, async cc => {
    try { return await discoverWorldDatacenters(cc, ports, String(providerQueryByCountry[cc] || ''), limit, requested); }
    catch (e) { return { ok: false, country: cc, countryName: SUPPORTED_WORLD_COUNTRIES[cc].name, results: [], summary: { candidateCount: 0 }, sources: {}, errors: [e.message] }; }
  });
  const found = groups.filter(g => (g.results || []).length > 0);
  const tavilyGroups = groups.filter(g => g.tavily?.ran);
  return {
    ok: true,
    searchedCountries: requested,
    foundCountries: found.map(g => g.country),
    countries: found,
    tavily: {
      configured: Boolean(TAVILY_API_KEY),
      ran: tavilyGroups.length > 0,
      countriesQueried: tavilyGroups.length,
      foundIPs: tavilyGroups.reduce((n, g) => n + Number(g.tavily?.foundIPs || 0), 0),
      sources: tavilyGroups.flatMap(g => g.tavily?.sources || []).slice(0, 20)
    },
    errors: groups.flatMap(g => (g.errors || []).map(error => `${g.country}: ${error}`)).slice(0, 40),
    summary: {
      searched: requested.length,
      found: found.length,
      candidates: found.reduce((n, g) => n + (g.results || []).length, 0),
      pinged: found.reduce((n, g) => n + (g.summary?.pinged || 0), 0)
    }
  };
}

function loadTelegramConfig() {
  try {
    const data = JSON.parse(fs.readFileSync(TELEGRAM_CONFIG_FILE, 'utf8'));
    return (data && typeof data === 'object') ? data : {};
  } catch (_) { return {}; }
}
function saveTelegramConfig(data) {
  ensureDataDir();
  fs.writeFileSync(TELEGRAM_CONFIG_FILE, JSON.stringify(data, null, 2), { mode: 0o600 });
  try { fs.chmodSync(TELEGRAM_CONFIG_FILE, 0o600); } catch (_) {}
}
function getTelegramToken() { return String(TELEGRAM_BOT_TOKEN || loadTelegramConfig().botToken || '').trim(); }
function telegramAppUrl(req) {
  const cfg = loadTelegramConfig();
  const configured = APP_PUBLIC_URL || String(req.body?.appUrl || req.query?.appUrl || cfg.appUrl || '').trim();
  if (!configured) return '';
  try { const u = new URL(configured); return u.toString(); } catch (_) { return ''; }
}
async function telegramCall(method, body = {}, timeout = 12000) {
  const token = getTelegramToken();
  if (!token) throw new Error('Telegram bot token is not configured.');
  return fetchJsonUrl(`${TELEGRAM_API_BASE}/bot${encodeURIComponent(token)}/${method}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body
  }, timeout);
}
function telegramWebAppMarkup(url) {
  return { inline_keyboard: [[{ text: '🚀 ورود به سامانه مهدیار اسکنر', web_app: { url } }]] };
}
async function sendTelegramWelcome(chatId, req) {
  const url = telegramAppUrl(req);
  if (!url || !/^https:|^http:\/\/localhost(?::\d+)?\/?$/i.test(url)) throw new Error('Set APP_PUBLIC_URL to your HTTPS Mini App URL.');
  return telegramCall('sendMessage', { chat_id: chatId, text: 'وارد سامانه مهدیار اسکنر بشو 🚀', reply_markup: telegramWebAppMarkup(url) });
}

let telegramPolling = false;
let telegramOffset = Number(loadTelegramConfig().offset || 0);
let telegramGeneration = 0;
async function processTelegramUpdate(update) {
  const message = update?.message;
  if (!message) return;
  const text = String(message.text || '').trim();
  if (text === '/start' || text.startsWith('/start ')) {
    try { await sendTelegramWelcome(message.chat.id, {}); } catch (e) { saveEvent('telegram', String(message.chat.id), false, e.message); }
  }
}
async function telegramPollingLoop(generation) {
  if (telegramPolling) return;
  const token = getTelegramToken();
  if (!token) return;
  telegramPolling = true;
  while (telegramPolling && generation === telegramGeneration) {
    try {
      const data = await telegramCall('getUpdates', { offset: telegramOffset || undefined, timeout: 25, allowed_updates: ['message'] }, 32000);
      const updates = Array.isArray(data?.result) ? data.result : [];
      for (const update of updates) {
        telegramOffset = Number(update?.update_id || 0) + 1;
        await processTelegramUpdate(update);
      }
      const saved = loadTelegramConfig();
      saved.offset = telegramOffset; delete saved.botToken; saveTelegramConfig(saved);
    } catch (e) {
      saveEvent('telegram-poll', 'getUpdates', false, e.message);
      await new Promise(r => setTimeout(r, 2500));
    }
  }
  telegramPolling = false;
}
function restartTelegramPolling() {
  telegramGeneration++;
  telegramPolling = false;
  const generation = telegramGeneration;
  setTimeout(() => telegramPollingLoop(generation).catch(() => {}), 250);
}
function startTelegramPolling() { restartTelegramPolling(); }
async function bootstrapTelegramBot() {
  refreshProviderSecrets();
  const token = getTelegramToken();
  if (!token) return false;
  try {
    await telegramCall('deleteWebhook', { drop_pending_updates: false }, 10000);
    const me = await telegramCall('getMe', {}, 10000);
    const cfg = loadTelegramConfig();
    cfg.botUsername = me?.result?.username || cfg.botUsername || 'Mahdiarscanner_Bot';
    if (APP_PUBLIC_URL) cfg.appUrl = APP_PUBLIC_URL;
    delete cfg.botToken;
    saveTelegramConfig(cfg);
    await telegramCall('setMyCommands', { commands: [{ command:'start', description:'ورود به سامانه مهدیار اسکنر' }, { command:'help', description:'راهنمای سامانه' }] }, 10000).catch(()=>{});
    const appUrl = APP_PUBLIC_URL;
    if (appUrl && /^https:\/\//i.test(appUrl)) await telegramCall('setChatMenuButton', { menu_button: { type:'web_app', text:'مهدیار اسکنر', web_app:{url:appUrl} } }, 10000).catch(()=>{});
    saveEvent('telegram-bootstrap', cfg.botUsername, true, 'Telegram bot initialized from runtime token.');
    startTelegramPolling();
    return true;
  } catch (e) {
    saveEvent('telegram-bootstrap', 'startup', false, e.message);
    return false;
  }
}


function verifyTelegramInitData(initData, botToken) {
  const params = new URLSearchParams(String(initData || ''));
  const hash = params.get('hash');
  if (!hash) return { ok: false, error: 'Missing Telegram initData hash.' };
  params.delete('hash');
  const dataCheckString = [...params.entries()].sort(([a],[b]) => a.localeCompare(b)).map(([k,v]) => `${k}=${v}`).join('\\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const expected = crypto.createHmac('sha256', secret).update(dataCheckString).digest('hex');
  if (!crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(expected, 'hex'))) return { ok: false, error: 'Invalid Telegram initData signature.' };
  const authDate = Number(params.get('auth_date') || 0);
  if (!authDate || Math.floor(Date.now()/1000) - authDate > 86400) return { ok: false, error: 'Telegram initData has expired.' };
  let user = null; try { user = JSON.parse(params.get('user') || 'null'); } catch (_) {}
  return { ok: true, user, authDate };
}

app.get('/api/telegram/status', (req, res) => {
  const token = getTelegramToken();
  const config = loadTelegramConfig();
  res.json({ ok: true, configured: Boolean(token), polling: telegramPolling, botUsername: config.botUsername || null, appUrl: APP_PUBLIC_URL || config.appUrl || null, setupKeyConfigured: Boolean(TELEGRAM_SETUP_KEY) });
});
app.post('/api/telegram/config', async (req, res) => {
  if (!TELEGRAM_SETUP_KEY || String(req.headers['x-setup-key'] || req.body?.setupKey || '') !== TELEGRAM_SETUP_KEY) return jsonError(res, 'Telegram setup key is required.', 403);
  const botToken = String(req.body?.botToken || '').trim();
  const appUrl = String(req.body?.appUrl || '').trim();
  if (!botToken) return jsonError(res, 'Bot token is required.');
  try { const me = await (async()=>{ const previous = loadTelegramConfig(); saveTelegramConfig({ ...previous, botToken, appUrl, offset: 0 }); await telegramCall('deleteWebhook', { drop_pending_updates: false }); const x = await telegramCall('getMe', {}); return x; })();
    const cfg = loadTelegramConfig(); cfg.botUsername = me?.result?.username || null; cfg.appUrl = appUrl; saveTelegramConfig(cfg); restartTelegramPolling();
    res.json({ ok: true, bot: me?.result || null, appUrl, polling: true });
  } catch (e) { const cfg=loadTelegramConfig(); cfg.botToken=''; saveTelegramConfig(cfg); jsonError(res, `Telegram configuration failed: ${e.message}`, 502); }
});
app.post('/api/telegram/test', async (req, res) => {
  if (!TELEGRAM_SETUP_KEY || String(req.headers['x-setup-key'] || req.body?.setupKey || '') !== TELEGRAM_SETUP_KEY) return jsonError(res, 'Telegram setup key is required.', 403);
  const chatId = String(req.body?.chatId || '').trim(); if (!chatId) return jsonError(res, 'chatId is required.');
  try { await sendTelegramWelcome(chatId, req); res.json({ ok: true, sent: true }); }
  catch (e) { jsonError(res, `Telegram test failed: ${e.message}`, 502); }
});
app.post('/api/telegram/auth', async (req, res) => {
  const token = getTelegramToken(); if (!token) return jsonError(res, 'Telegram bot token is not configured.', 503);
  const result = verifyTelegramInitData(req.body?.initData, token); if (!result.ok) return jsonError(res, result.error, 401);
  res.json({ ok: true, user: result.user, authDate: result.authDate });
});

app.get('/api/multi-ping', async (req, res) => {
  refreshProviderSecrets();
  const requested = String(req.query.countries || WORLD_COUNTRY_CODES.join(',')).split(',').map(safeWorldCountryCode).filter(Boolean);
  const countries = [...new Set(requested)].slice(0, WORLD_COUNTRY_CODES.length);
  const target = String(req.query.target || '').trim();
  try {
    if (target) {
      const data = await globalpingMeasure(target, countries, Number(req.query.packets || 3));
      saveEvent('globalping', target, data.ok, `${data.results.length} probe results`);
      return res.json({ ...data, countries: data.results, searchedCountries: countries, source: 'Globalping' });
    }
    return jsonError(res, 'Enter an IP or hostname to run multi-point ping.', 400);
  } catch (e) {
    saveEvent('globalping', target || 'empty', false, e.message);
    jsonError(res, e.message, e.statusCode || 502);
  }
});

app.get('/api/world-discovery', async (req, res) => {
  try {
    const raw=String(req.query.countries||req.query.country||'').trim();
    const countries=raw?raw.split(',').map(proxyCountryCode).filter(Boolean):[];
    const limit=Math.min(Math.max(Number(req.query.limit||12),1),12);
    const offset=Math.min(Math.max(Number(req.query.offset||0),0),1000000);
    const data=await scanProxiflyBatch({
      countries,
      protocol:String(req.query.protocol||''),
      family:String(req.query.family||'all'),
      query:String(req.query.q||req.query.provider||''),
      offset,limit,
      probeCountry:String(req.query.probeCountry||'DE')
    });
    recordWorldDiscovery(data);
    res.setHeader('cache-control','no-store');
    res.json(data);
  } catch(e) {
    recordServerProblem('Proxifly',String(e?.message||e),'warning');
    jsonError(res,`Proxifly proxy scan failed: ${e.message}`,e.statusCode||502);
  }
});


function normaliseGlobalpingProbe(row) {
  const stats=row?.result?.stats || row?.stats || {};
  const probe=row?.probe || {};
  const loc=probe?.location || {};
  const country=String(probe.country || loc.country || '').toUpperCase();
  const city=probe.city || loc.city || loc.name || null;
  const asn=probe.asn || loc.asn || null;
  const network=probe.network || loc.network || null;
  const lat=finiteGeo(probe.latitude ?? probe.lat ?? loc.latitude ?? loc.lat);
  const lon=finiteGeo(probe.longitude ?? probe.lon ?? probe.lng ?? loc.longitude ?? loc.lon ?? loc.lng);
  return {
    country:country||null,
    countryName:COUNTRY_CODES[country] || String(probe.countryName || loc.countryName || country || ''),
    city, asn, network, lat, lon,
    status:row?.result?.status || row?.status || null,
    minMs:stats.min != null && stats.min !== '' && Number.isFinite(Number(stats.min))?Number(stats.min):null,
    avgMs:stats.avg != null && stats.avg !== '' && Number.isFinite(Number(stats.avg))?Number(stats.avg):null,
    maxMs:stats.max != null && stats.max !== '' && Number.isFinite(Number(stats.max))?Number(stats.max):null,
    loss:stats.loss != null && stats.loss !== '' && Number.isFinite(Number(stats.loss))?Number(stats.loss):null,
    raw:row
  };
}

async function globalpingMeasure(target, countryCodes, packets = 3) {
  const cleanTarget = String(target || '').trim();
  if (!cleanTarget || cleanTarget.length > MAX_TARGET_LENGTH) throw Object.assign(new Error('Enter a valid public IP or hostname.'), { statusCode: 400 });
  const selected = [...new Set((countryCodes || WORLD_COUNTRY_CODES).map(safeWorldCountryCode).filter(Boolean))].slice(0, WORLD_COUNTRY_CODES.length);
  if (!selected.length) throw Object.assign(new Error('Choose at least one enabled country.'), { statusCode: 400 });
  if (!isValidIP(cleanTarget)) {
    if (isBlockedHost(cleanTarget)) throw Object.assign(new Error('Private/local targets are blocked.'), { statusCode: 400 });
    await safeResolvedExternalHost(cleanTarget);
  } else if (!isPublicClientAddress(cleanTarget)) {
    throw Object.assign(new Error('Target IP must be public.'), { statusCode: 400 });
  }
  const cacheKey=`${cleanTarget}|${selected.join(',')}|${packets}`;
  const cached=globalPingCache.get(cacheKey);
  if(cached && Date.now()-cached.at<30000) return cached.data;
  const headers={'content-type':'application/json',accept:'application/json'};
  if(GLOBALPING_API_KEY) headers.authorization=`Bearer ${GLOBALPING_API_KEY}`;
  const locations=selected.map(code=>({country:code}));
  const created=await fetchJsonUrl(`${GLOBALPING_BASE}/measurements`,{method:'POST',headers,body:JSON.stringify({target:cleanTarget,type:'ping',locations,measurementOptions:{packets:Math.min(Math.max(Number(packets)||3,1),5)}})},12000);
  const measurementId=created?.id || created?.measurementId;
  if(!measurementId) throw new Error('Globalping did not return a measurement id.');
  const deadline=Date.now()+GLOBALPING_TIMEOUT_MS;
  let measurement=null;
  while(Date.now()<deadline){
    await new Promise(r=>setTimeout(r,1400));
    measurement=await fetchJsonUrl(`${GLOBALPING_BASE}/measurements/${encodeURIComponent(measurementId)}`,{headers:{accept:'application/json'}},12000);
    const status=String(measurement?.status||'').toLowerCase();
    if(status==='finished'||status==='failed'||status==='stopped') break;
    if(Array.isArray(measurement?.results) && measurement.results.length>=selected.length) break;
  }
  const results=(Array.isArray(measurement?.results)?measurement.results:[]).map(normaliseGlobalpingProbe);
  const data={ok:results.length>0,target:cleanTarget,measurementId,status:measurement?.status||null,results,source:'Globalping'};
  globalPingCache.set(cacheKey,{at:Date.now(),data});
  return data;
}

async function globalpingHttpMeasure(rawUrl, countryCode) {
  const parsed = new URL(String(rawUrl || '').trim());
  if (!['http:', 'https:'].includes(parsed.protocol)) throw Object.assign(new Error('Only HTTP and HTTPS URLs are supported.'), { statusCode: 400 });
  if (parsed.username || parsed.password) throw Object.assign(new Error('URLs containing embedded credentials are not allowed.'), { statusCode: 400 });
  if (parsed.href.length > 500) throw Object.assign(new Error('URL is too long (maximum 500 characters).'), { statusCode: 400 });
  if (isBlockedHost(parsed.hostname)) throw Object.assign(new Error('Private, local, or reserved destinations are blocked.'), { statusCode: 400 });
  const cc = String(countryCode || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(cc) || !SUPPORTED_WORLD_COUNTRIES[cc]) throw Object.assign(new Error('Choose a supported Globalping probe country.'), { statusCode: 400 });
  const normalizedUrl = parsed.href;
  const cacheKey = `${cc}|${normalizedUrl}`;
  const cached = connectivityHttpCache.get(cacheKey);
  if (cached && Date.now() - cached.at < CONNECTIVITY_HTTP_CACHE_TTL_MS) {
    return { ...cached.data, cached: true, cacheAgeMs: Date.now() - cached.at };
  }
  if (connectivityHttpInFlight.has(cacheKey)) {
    const pending = await connectivityHttpInFlight.get(cacheKey);
    return { ...pending, cached: true, joinedInFlight: true };
  }
  const work = (async () => {
    // Validate DNS before sending a public host to Globalping. The final test itself runs only on Globalping.
    await safeResolvedExternalHost(parsed.hostname);
    const now = Date.now();
    while (connectivityHttpRateTimes.length && connectivityHttpRateTimes[0] < now - 3600000) connectivityHttpRateTimes.shift();
    if (connectivityHttpRateTimes.length >= CONNECTIVITY_UPSTREAM_MAX_PER_HOUR) {
      throw Object.assign(new Error(`Globalping safety limit reached (${CONNECTIVITY_UPSTREAM_MAX_PER_HOUR} live website tests/hour). Try again later.`), { statusCode: 429 });
    }
    connectivityHttpRateTimes.push(now);
    const headers = { 'content-type': 'application/json', accept: 'application/json', 'user-agent': 'Mahdiar-Scanner/6.7.4 (Globalping network connectivity)' };
    if (GLOBALPING_API_KEY) headers.authorization = `Bearer ${GLOBALPING_API_KEY}`;
    const useHttps = parsed.protocol === 'https:';
    const requestPath = parsed.pathname || '/';
    const requestQuery = parsed.search ? parsed.search.slice(1) : undefined;
    const created = await fetchJsonUrl(`${GLOBALPING_BASE}/measurements`, {
      method: 'POST', headers,
      body: JSON.stringify({
        type: 'http', target: parsed.hostname,
        locations: [{ country: cc }], limit: 1, inProgressUpdates: true, timeout: 10,
        measurementOptions: {
          protocol: useHttps ? 'HTTPS' : 'HTTP',
          port: Number(parsed.port) || (useHttps ? 443 : 80),
          request: { method: 'GET', path: requestPath, ...(requestQuery ? { query: requestQuery } : {}) }
        }
      })
    }, 15000);
    const measurementId = created?.id || created?.measurementId;
    if (!measurementId) throw new Error('Globalping did not return a measurement ID.');
    let measurement = created;
    const deadline = Date.now() + 18000;
    while (Date.now() < deadline) {
      const finishedResult = (Array.isArray(measurement?.results) ? measurement.results : []).some(item => {
        const status = String(item?.result?.status || '').toLowerCase();
        return status === 'finished' || status === 'failed' || status === 'offline';
      });
      const measurementStatus = String(measurement?.status || '').toLowerCase();
      if (measurementStatus && measurementStatus !== 'in-progress') break;
      if (finishedResult) break;
      // Globalping advises spacing reads of an individual measurement by at least 500 ms.
      await new Promise(resolve => setTimeout(resolve, 850));
      measurement = await fetchJsonUrl(`${GLOBALPING_BASE}/measurements/${encodeURIComponent(measurementId)}`, { headers: { accept: 'application/json', 'user-agent': 'Mahdiar-Scanner/6.7.4 (Globalping network connectivity)', ...(GLOBALPING_API_KEY ? { authorization: `Bearer ${GLOBALPING_API_KEY}` } : {}) } }, 12000);
    }
    const items = Array.isArray(measurement?.results) ? measurement.results : [];
    const item = items.find(entry => Number.isFinite(Number(entry?.result?.statusCode))) || items[0] || null;
    const result = item?.result || null;
    const statusCodeValue = result?.statusCode;
    const statusCode = statusCodeValue !== null && statusCodeValue !== undefined && Number.isFinite(Number(statusCodeValue)) ? Number(statusCodeValue) : null;
    const totalTiming = result?.timings?.total;
    const latencyMs = totalTiming !== null && totalTiming !== undefined && Number.isFinite(Number(totalTiming)) ? Number(totalTiming) : null;
    const state = statusCode == null ? 'unknown' : statusCode >= 500 ? 'degraded' : 'online';
    const data = {
      ok: statusCode != null,
      reachable: statusCode != null ? statusCode >= 200 && statusCode < 500 : null,
      state,
      url: normalizedUrl,
      hostname: parsed.hostname,
      country: cc,
      latencyMs,
      statusCode,
      statusCodeName: result?.statusCodeName || null,
      probe: item?.probe ? { country: item.probe.country || null, city: item.probe.city || null, network: item.probe.network || null } : null,
      resolvedAddress: result?.resolvedAddress || null,
      error: statusCode == null ? String(result?.rawOutput || measurement?.error || `Globalping result unavailable (status: ${measurement?.status || 'unknown'}).`).slice(0, 500) : null,
      measurementId,
      source: 'Globalping',
      checkedAt: new Date().toISOString(),
      cacheTtlMs: CONNECTIVITY_HTTP_CACHE_TTL_MS,
      cached: false
    };
    // Bound memory as users may add custom URLs.
    if (connectivityHttpCache.size > 600) {
      const firstKey = connectivityHttpCache.keys().next().value;
      if (firstKey) connectivityHttpCache.delete(firstKey);
    }
    connectivityHttpCache.set(cacheKey, { at: Date.now(), data });
    return data;
  })();
  connectivityHttpInFlight.set(cacheKey, work);
  try { return await work; }
  finally { connectivityHttpInFlight.delete(cacheKey); }
}

function parseProxyRows(data, rawText='', sourceName='ProxyScrape') {
  const rows=[];
  const add=(x)=>{
    if(!x || typeof x!=='object') return;
    const geo = x.geolocation || x.geo || x.location || {};
    let ip=String(x.ip||x.ip_address||x.address||x.addr||x.host||'').trim();
    let port=Number(x.port||x.proxy_port||x.proxyPort||0);
    if ((!ip || !port) && x.proxy) {
      const m=String(x.proxy).trim().match(/^(https?|socks4a?|socks5h?):\/\/(?:\[([^\]]+)\]|([^:/]+)):(\d{1,5})$/i);
      if (m) { if (!ip) ip=m[2]||m[3]||''; if (!port) port=Number(m[4]); }
    }
    const bracketed=ip.match(/^\[([0-9a-f:]+)\]:(\d{1,5})$/i);
    if(bracketed){ip=bracketed[1];if(!port)port=Number(bracketed[2]);}
    ip=ip.replace(/^\[|\]$/g,'');
    if(!isIPv4(ip) && net.isIP(ip)!==6) return;
    if(!Number.isInteger(port)||port<1||port>65535) return;
    const listedProtocols=Array.isArray(x.protocols)?x.protocols.map(v=>String(v||'').toLowerCase().trim()).filter(Boolean):[];
    const singleProtocol=String(x.protocol||x.type||x.scheme||x.proxy_type||'').toLowerCase().trim();
    const protocols=[...new Set(listedProtocols.length?listedProtocols:[singleProtocol||'unknown'])].filter(p=>/^(https?|socks4a?|socks5h?)$/.test(p));
    const usableProtocols=protocols.length?protocols:['unknown'];
    let country=String(x.country_code||x.countryCode||geo.country_code||geo.countryCode||geo.country||x.country||x.code||'').trim().toUpperCase();
    if(country.length>2) {
      const countryEntry=Object.entries(COUNTRY_CODES).find(([,name])=>String(name).toUpperCase()===country);
      country=countryEntry?countryEntry[0]:'';
    }
    const latency=Number(x.latency_ms ?? x.latency ?? x.response_time_ms ?? x.timeout_ms ?? x.timeout);
    const anonymity=typeof x.anonymity==='object'?(x.anonymity?.level||null):(x.anonymity||x.anonymity_level||null);
    const asnValue=x.asn ?? x.autonomous_system?.asn ?? geo.asn ?? null;
    const asn=asnValue==null?'':String(asnValue).replace(/^AS/i,'');
    const provider=x.asn_org||x.isp||x.organization||x.org||x.provider||geo.organization||geo.isp||geo.org||null;
    for(const protocol of usableProtocols) rows.push({
      ip,port,protocol,country,
      anonymity,
      https:Boolean(x.https ?? x.ssl ?? x.https_enabled ?? (usableProtocols.includes('https'))),
      latencyMs:Number.isFinite(latency)?latency:null,
      lastChecked:x.last_checked_at||x.last_checked||x.lastChecked||x.last_check||x.last_check_at||null,
      provider,
      asName: provider || '',
      asn,
      score:Number.isFinite(Number(x.score))?Number(x.score):null,
      city:x.city||geo.city||null,
      lat:finiteGeo(x.latitude ?? x.lat ?? geo.latitude ?? geo.lat),
      lon:finiteGeo(x.longitude ?? x.lon ?? x.lng ?? geo.longitude ?? geo.lon ?? geo.lng),
      tier:x.tier||x.status||x.level||null,
      uptimeRatio:Number.isFinite(Number(x.uptime_pct ?? x.uptime_24h))?Number(x.uptime_pct ?? x.uptime_24h):null,
      family:Number(x.family)||net.isIP(ip),
      source:sourceName
    });
  };
  if(Array.isArray(data)) data.forEach(add);
  else if(data && typeof data==='object') {
    const candidates=data.proxies||data.results||data.data||data.items||data.rows||[];
    if(Array.isArray(candidates)) candidates.forEach(add);
  }
  if(!rows.length && rawText){
    const text=String(rawText).replace(/^\uFEFF/,'').trim();
    // JSON documents are common in public mirrors.
    if((text.startsWith('{')||text.startsWith('['))){
      try{
        const parsed=JSON.parse(text);
        if(Array.isArray(parsed)) parsed.forEach(add);
        else add(parsed);
        if(parsed?.proxies && Array.isArray(parsed.proxies)) parsed.proxies.forEach(add);
        if(parsed?.data && Array.isArray(parsed.data)) parsed.data.forEach(add);
      }catch(_){ }
    }
    // CSV/TSV mirrors: identify columns by header names, then parse rows safely.
    if(!rows.length && /(^|\n)\s*(ip|ip_address).*[,\t]/i.test(text)){
      const lines=text.split(/\r?\n/).filter(Boolean);
      const delim=lines[0].includes('\t')?'\t':',';
      const headers=lines[0].split(delim).map(h=>h.trim().toLowerCase().replace(/^['\"]|['\"]$/g,''));
      const idx=(names)=>{for(const n of names){const i=headers.indexOf(n);if(i>=0)return i;}return -1;};
      const ii=idx(['ip','ip_address','host','address']), pi=idx(['port','proxy_port']), pro=idx(['protocol','type','scheme']), ci=idx(['country','country_code','code']), li=idx(['latency','latency_ms','timeout','timeout_ms']);
      for(const line of lines.slice(1)){
        const parts=line.split(delim).map(v=>v.trim().replace(/^['\"]|['\"]$/g,''));
        add({ip:parts[ii],port:parts[pi],protocol:pro>=0?parts[pro]:'',country:ci>=0?parts[ci]:'',latency_ms:li>=0?parts[li]:null});
      }
    }
    // Plain ip:port / protocol://ip:port lists.
    if(!rows.length){
      for(const line of text.split(/\r?\n/)){
        const value=line.trim();
        const bracketed=value.match(/^(?:(https?|socks4|socks5):\/\/)?\[([0-9a-f:]+)\]:([0-9]{1,5})$/i);
        if(bracketed && net.isIP(bracketed[2])===6 && Number(bracketed[3])>=1 && Number(bracketed[3])<=65535){add({protocol:bracketed[1]||'',ip:bracketed[2],port:Number(bracketed[3])});continue;}
        const m=value.match(/^(?:(https?|socks4|socks5):\/\/)?((?:\d{1,3}\.){3}\d{1,3}|[0-9a-f:]+):([0-9]{1,5})$/i);
        if(m && net.isIP(m[2]) && Number(m[3])>=1 && Number(m[3])<=65535) add({protocol:m[1]||'',ip:m[2],port:Number(m[3])});
      }
    }
    // Minimal HTML table support for public proxy list pages whose rows expose IP and port in separate cells.
    if(!rows.length && /<(?:table|tr|td)\b/i.test(text)){
      const cleanCell=value=>String(value||'').replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;|&#160;/gi,' ').replace(/&amp;/gi,'&').replace(/&#x([0-9a-f]+);/gi,(_,h)=>String.fromCodePoint(parseInt(h,16))).replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n))).trim();
      const trRe=/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi; let tr;
      while((tr=trRe.exec(text))){
        const cells=[...tr[1].matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m=>cleanCell(m[1])).filter(Boolean);
        if(!cells.length) continue;
        let ip='',port=0;
        for(const cell of cells){
          const pair=cell.match(/^(?:\[([0-9a-f:]+)\]|((?:\d{1,3}\.){3}\d{1,3}|[0-9a-f:]+))(?::(\d{1,5}))?$/i);
          if(pair){const candidate=pair[1]||pair[2];if(net.isIP(candidate)){ip=candidate;if(pair[3])port=Number(pair[3]);break;}}
        }
        if(!ip) continue;
        if(!port){const pi=cells.find(v=>/^\d{1,5}$/.test(v)&&Number(v)>=1&&Number(v)<=65535);if(pi)port=Number(pi);}
        if(!port) continue;
        const protocol=cells.find(v=>/^(https?|socks4a?|socks5h?)$/i.test(v))||'';
        const country=cells.find(v=>/^[A-Z]{2}$/i.test(v)&&v.toUpperCase()!==protocol.toUpperCase())||'';
        add({ip,port,protocol,country});
      }
    }
  }
  return rows;
}

function proxyCountryCode(value) {
  const raw=String(value||'').trim();
  if (/^[A-Za-z]{2}$/.test(raw)) return raw.toUpperCase();
  const hit=Object.entries(COUNTRY_CODES).find(([,name])=>String(name).toLowerCase()===raw.toLowerCase());
  return hit?hit[0]:'';
}

function normalizeProxiflyJson(raw, label='Proxifly JSON') {
  if (typeof raw !== 'string' || !raw.trim()) throw new Error(`${label} is empty.`);
  if (Buffer.byteLength(raw, 'utf8') > PROXIFLY_JSON_MAX_BYTES) throw new Error(`${label} exceeded the 25 MB safety limit.`);
  let data;
  try { data=JSON.parse(raw); } catch (_) { throw new Error(`${label} is not valid JSON.`); }
  const rows=parseProxyRows(data,'','Proxifly');
  const dedup=new Map();
  for (const row of rows) {
    if (!row.ip || !isPublicClientAddress(row.ip) || !Number.isInteger(row.port) || row.port<1 || row.port>65535) continue;
    const protocol=PROXIFLY_PROTOCOLS.has(row.protocol)?row.protocol:'unknown';
    const cc=proxyCountryCode(row.country);
    const normalized={...row,protocol,country:cc,latencyMs:null,source:'Proxifly'};
    const key=`${normalized.ip}|${normalized.port}|${normalized.protocol}`;
    if (!dedup.has(key)) dedup.set(key,normalized);
  }
  const clean=[...dedup.values()];
  if (!clean.length) throw new Error(`${label} contained no valid public proxy entries; refusing to replace the last-known-good snapshot.`);
  return clean;
}

async function persistProxiflySnapshot(raw) {
  const tempFile=`${PROXIFLY_LOCAL_JSON_FILE}.${process.pid}.tmp`;
  try {
    await fs.promises.mkdir(path.dirname(PROXIFLY_LOCAL_JSON_FILE), {recursive:true});
    let existing='';
    try { existing=await fs.promises.readFile(PROXIFLY_LOCAL_JSON_FILE,'utf8'); } catch (_) { /* first successful fetch */ }
    if (existing === raw) return true;
    await fs.promises.writeFile(tempFile, raw, {encoding:'utf8', mode:0o600});
    await fs.promises.rename(tempFile, PROXIFLY_LOCAL_JSON_FILE);
    return true;
  } catch (error) {
    try { await fs.promises.unlink(tempFile); } catch (_) { /* ignore temp cleanup errors */ }
    console.warn(`[proxifly] downloaded live list but could not save local fallback: ${String(error?.message||error).slice(0,200)}`);
    return false;
  }
}

async function loadProxiflyJsonRows() {
  const now=Date.now();
  if (proxiflyJsonCache.rows.length && now-proxiflyJsonCache.at<PROXIFLY_JSON_CACHE_TTL) {
    if (proxiflyJsonCache.sourceMode === 'online') clearServerProblem('Proxifly');
    return proxiflyJsonCache;
  }
  if (proxiflyJsonInFlight) return proxiflyJsonInFlight;
  proxiflyJsonInFlight=(async()=>{
    let onlineError=null;
    try {
      // Priority 1: fetch the live list. Never use the snapshot before attempting the URL.
      try {
        const response=await fetchText(PROXIFLY_JSON_URL,{headers:{accept:'application/json','user-agent':'Mahdiar-Scanner/6.7.4 (Proxifly proxy inventory)'}},PROXIFLY_FETCH_TIMEOUT_MS);
        const raw=await response.text();
        if (!response.ok) throw Object.assign(new Error(`Proxifly JSON returned HTTP ${response.status}`),{statusCode:502});
        const clean=normalizeProxiflyJson(raw,'Proxifly online JSON');
        const snapshotSaved=await persistProxiflySnapshot(raw);
        const snapshotExists=snapshotSaved || await fs.promises.access(PROXIFLY_LOCAL_JSON_FILE).then(()=>true).catch(()=>false);
        proxiflyJsonCache={at:Date.now(),fetchedAt:new Date().toISOString(),rows:clean,sourceMode:'online',localSnapshotAvailable:snapshotExists};
        clearServerProblem('Proxifly');
        return proxiflyJsonCache;
      } catch(error) {
        onlineError=error;
        recordServerProblem('Proxifly',`${PROXIFLY_JSON_URL} — ${String(error?.message||error).slice(0,300)}`,'warning');
      }

      // Priority 2: if the URL fails, read the most recent valid JSON saved on disk.
      try {
        const raw=await fs.promises.readFile(PROXIFLY_LOCAL_JSON_FILE,'utf8');
        const clean=normalizeProxiflyJson(raw,'Local Proxifly fallback JSON');
        const stat=await fs.promises.stat(PROXIFLY_LOCAL_JSON_FILE);
        proxiflyJsonCache={
          at:Date.now(),
          fetchedAt:stat.mtime.toISOString(),
          rows:clean,
          sourceMode:'local-fallback',
          localSnapshotAvailable:true,
          onlineError:String(onlineError?.message||onlineError||'Online source unavailable').slice(0,300)
        };
        console.warn(`[proxifly] online source unavailable; serving ${clean.length} saved proxies from ${PROXIFLY_LOCAL_JSON_FILE}`);
        return proxiflyJsonCache;
      } catch(localError) {
        const message=`Proxifly online source failed (${String(onlineError?.message||onlineError).slice(0,180)}); local JSON fallback is not available or invalid (${String(localError?.message||localError).slice(0,180)}). The local fallback is created automatically after the first successful online fetch.`;
        throw Object.assign(new Error(message),{statusCode:502});
      }
    } finally {
      proxiflyJsonInFlight=null;
    }
  })();
  return proxiflyJsonInFlight;
}

async function scanProxiflyBatch({countries=[],protocol='',family='all',query='',offset=0,limit=12,probeCountry='DE'}={}) {
  const source=await loadProxiflyJsonRows();
  const selected=new Set((countries||[]).map(proxyCountryCode).filter(Boolean));
  const proto=PROXIFLY_PROTOCOLS.has(String(protocol||'').toLowerCase())?String(protocol).toLowerCase():'';
  const fam=String(family||'all').toLowerCase();
  const q=String(query||'').trim().toLowerCase().slice(0,100);
  const filtered=source.rows.filter(row=>{
    if(selected.size&&!selected.has(row.country)) return false;
    if(proto&&row.protocol!==proto) return false;
    if(fam==='v4'&&net.isIP(row.ip)!==4) return false;
    if(fam==='v6'&&net.isIP(row.ip)!==6) return false;
    if(q&&!`${row.ip} ${row.port} ${row.protocol} ${row.country} ${COUNTRY_CODES[row.country]||''} ${row.city||''} ${row.provider||''} ${row.asn||''}`.toLowerCase().includes(q)) return false;
    return true;
  });
  const safeOffset=Math.min(Math.max(0,Math.floor(Number(offset)||0)),filtered.length);
  const safeLimit=Math.min(Math.max(1,Math.floor(Number(limit)||12)),12);
  const batch=filtered.slice(safeOffset,safeOffset+safeLimit);
  const probe=proxyCountryCode(probeCountry)&&WORLD_COUNTRY_CODES.includes(proxyCountryCode(probeCountry))?proxyCountryCode(probeCountry):'DE';
  const enriched=await runLimited(batch,2,async base=>{
    const cacheKey=`${base.ip}|${probe}`;
    const mergeEndpoint=(measured)=>{
      const trustedGeo=measured.metadataSource==='IPWho.is';
      const cc=trustedGeo?(measured.countryCode||measured.country||''):(base.country||measured.countryCode||measured.country||'');
      const provider=trustedGeo?(measured.provider||measured.asName||base.provider||base.asName||''):(base.provider||base.asName||measured.provider||measured.asName||'');
      const asn=trustedGeo?(measured.asn||base.asn||''):(base.asn||measured.asn||'');
      return {
        ...base,
        ...measured,
        country:cc,
        countryCode:cc,
        countryName:trustedGeo?(measured.countryName||COUNTRY_CODES[cc]||cc||'Unknown'):(COUNTRY_CODES[cc]||measured.countryName||cc||'Unknown'),
        city:trustedGeo?(measured.city||base.city||''):(base.city||measured.city||''),
        provider,
        asName:trustedGeo?(measured.asName||provider):(base.asName||measured.asName||provider),
        asn,
        datacenterName:base.datacenterName||provider||'',
        ping:measured.ping,
        pingSource:'Globalping',
        confirmedPorts:[],
        observedPorts:[base.port],
        services:[],
        sources:['Proxifly'],
        lastSeen:new Date().toISOString()
      };
    };
    const cached=proxiflyScanCache.get(cacheKey);
    if(cached&&Date.now()-cached.at<PROXIFLY_PING_CACHE_TTL) return mergeEndpoint(cached.row);
    let pending=proxiflyScanInFlight.get(cacheKey);
    if(!pending){
      pending=(async()=>{
        const [geo,pingRaw]=await Promise.allSettled([
          // IPWho.is is the canonical metadata source for every IP actually scanned;
          // Proxifly metadata is retained only when the geolocation lookup is unavailable.
          ipGeolocation(base.ip),
          globalpingMeasure(base.ip,[probe],2)
        ]);
        const meta=geo.status==='fulfilled'?geo.value:null;
        const g=meta||{};
        const results=pingRaw.status==='fulfilled'&&Array.isArray(pingRaw.value?.results)?pingRaw.value.results:[];
        const usable=results.filter(x=>x.avgMs!=null&&x.avgMs!==''&&Number.isFinite(Number(x.avgMs))&&Number(x.avgMs)>=0);
        const avgMs=usable.length?Math.round(usable.reduce((sum,x)=>sum+Number(x.avgMs),0)/usable.length):null;
        const loss=usable.length&&usable.every(x=>x.loss!=null)?Math.round(usable.reduce((sum,x)=>sum+Number(x.loss),0)/usable.length):null;
        const ping={
          ok:avgMs!=null&&(loss==null||loss<100),source:'Globalping',avgMs,
          minMs:(()=>{const a=usable.map(x=>Number(x.minMs)).filter(Number.isFinite);return a.length?Math.round(Math.min(...a)):null})(),
          maxMs:(()=>{const a=usable.map(x=>Number(x.maxMs)).filter(Number.isFinite);return a.length?Math.round(Math.max(...a)):null})(),
          loss,probeCountry:probe,measurementId:pingRaw.status==='fulfilled'?pingRaw.value?.measurementId||null:null,
          error:pingRaw.status==='rejected'?String(pingRaw.reason?.message||pingRaw.reason).slice(0,220):avgMs==null?'Globalping returned no usable latency result.':null
        };
        const country=g.countryCode||base.country||'';
        const provider=g.provider||g.org||base.provider||base.asName||'';
        const asn=g.asn||base.asn||'';
        const row={
          ...base,
          country,
          countryCode:country,
          countryName:g.country||COUNTRY_CODES[country]||country||'Unknown',
          city:g.city||base.city||'',
          lat:g.lat??base.lat??null,
          lon:g.lon??base.lon??null,
          provider,
          asName:g.provider||base.asName||provider,
          asn,
          datacenterName:base.datacenterName||provider||'',
          metadataSource:g.source==='IPWho.is'?'IPWho.is':'Proxifly (fallback)',
          metadataStatus:g.source==='IPWho.is'?'verified-by-IPWho.is':'IPWho.is-unavailable',
          ping,
          confirmedPorts:[],
          observedPorts:[base.port],
          services:[],
          sources:['Proxifly'],
          pingSource:'Globalping',
          lastSeen:new Date().toISOString()
        };
        // An ASN/organization label is not guaranteed to be the physical datacenter name.
        proxiflyScanCache.set(cacheKey,{at:Date.now(),row});
        while(proxiflyScanCache.size>50000) proxiflyScanCache.delete(proxiflyScanCache.keys().next().value);
        return row;
      })();
      proxiflyScanInFlight.set(cacheKey,pending);
    }
    try { return mergeEndpoint(await pending); }
    finally { if(proxiflyScanInFlight.get(cacheKey)===pending) proxiflyScanInFlight.delete(cacheKey); }
  });
  const groupsMap=new Map();
  for(const row of enriched){
    const cc=row.countryCode||'ZZ';
    if(!groupsMap.has(cc))groupsMap.set(cc,[]);
    groupsMap.get(cc).push(row);
  }
  const groups=[...groupsMap.entries()].map(([cc,results])=>({country:cc,countryName:COUNTRY_CODES[cc]||'Unknown',results}));
  const validPings=enriched.map(r=>r.ping?.avgMs).filter(v=>v!=null&&v!==''&&Number.isFinite(Number(v))).map(Number);
  return {
    ok:true,
    fetchedAt:source.fetchedAt,
    source:{proxifly:true,globalping:true,otherDiscoveryProviders:[],inventoryMode:source.sourceMode||'online',localSnapshotAvailable:Boolean(source.localSnapshotAvailable)},
    countries:groups,
    foundCountries:groups.filter(g=>g.results.length).map(g=>g.country),
    summary:{searched:selected.size||'all',found:groups.length,candidates:filtered.length,batchCount:enriched.length,pinged:enriched.length,successfulPings:enriched.filter(r=>r.ping?.ok).length,avgPingMs:validPings.length?Math.round(validPings.reduce((a,b)=>a+b,0)/validPings.length):null,sourceCount:filtered.length},
    pagination:{offset:safeOffset,limit:safeLimit,total:filtered.length,returned:enriched.length,nextOffset:safeOffset+enriched.length,hasNext:safeOffset+enriched.length<filtered.length},
    probeCountry:probe,
    errors:enriched.filter(r=>r.ping?.error).map(r=>`${r.ip}: ${r.ping.error}`).slice(0,10)
  };
}

async function proxyList({mode='best',country='',protocol='',limit=50,format='json'}={}){
  const cc=proxyCountryCode(country);
  const proto=String(protocol||'').toLowerCase();
  const safeLimit=Math.min(Math.max(Number(limit)||50,1),200);
  const key=`proxifly|${mode}|${cc}|${proto}|${safeLimit}|${format}`;
  const cached=proxyCache.get(key);
  if(cached&&Date.now()-cached.at<PROXY_CACHE_TTL)return cached.data;
  const source=await loadProxiflyJsonRows();
  let rows=source.rows.filter(row=>{
    if(cc&&row.country!==cc)return false;
    if(proto&&row.protocol!==proto)return false;
    if(mode==='v4'&&net.isIP(row.ip)!==4)return false;
    if(mode==='v6'&&net.isIP(row.ip)!==6)return false;
    return true;
  });
  // Do not label source-reported latency as ping; ping is provided by the Globalping scanner batch.
  if(mode==='best')rows=rows.slice().sort((a,b)=>(Number(b.score??-1)-Number(a.score??-1))||a.ip.localeCompare(b.ip));
  rows=rows.slice(0,safeLimit).map(row=>({...row,latencyMs:null,source:'Proxifly'}));
  const data={ok:true,mode,country:cc||null,protocol:proto||null,count:rows.length,totalMatches:source.rows.filter(r=>(!cc||r.country===cc)&&(!proto||r.protocol===proto)&&(mode!=='v4'||net.isIP(r.ip)===4)&&(mode!=='v6'||net.isIP(r.ip)===6)).length,rows,source:'Proxifly JSON',sourceMode:source.sourceMode||'online',localSnapshotAvailable:Boolean(source.localSnapshotAvailable),rawAvailable:true,fetchedAt:source.fetchedAt,error:rows.length?null:'No Proxifly proxy rows matched the selected filter.'};
  proxyCache.set(key,{at:Date.now(),data});
  return data;
}

async function githubLiveList(repo,pathValue=''){
  const repoMatch=String(repo||GITHUB_LIVE_REPO).trim().match(/^([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)$/);
  if(!repoMatch) throw Object.assign(new Error('GitHub repository must be owner/repo.'),{statusCode:400});
  const owner=repoMatch[1], name=repoMatch[2];
  const cleanPath=String(pathValue||'').replace(/^\/+/, '').slice(0,300);
  const headers={accept:'application/vnd.github+json','x-github-api-version':'2026-03-10'};
  if(GITHUB_TOKEN) headers.authorization=`Bearer ${GITHUB_TOKEN}`;
  const data=await fetchJsonUrl(`${GITHUB_API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/contents/${cleanPath}`,{headers},12000);
  if(Array.isArray(data)) return {ok:true,type:'directory',repo:`${owner}/${name}`,path:cleanPath,items:data.slice(0,150).map(x=>({name:x.name,type:x.type,path:x.path,size:x.size||0,download_url:x.download_url||null}))};
  let textBody='';
  if(typeof data?.download_url==='string'){
    const r=await fetchText(data.download_url,{headers:{accept:'text/plain'}},12000);
    if(!r.ok) throw Object.assign(new Error(`GitHub raw content HTTP ${r.status}`),{statusCode:r.status});
    textBody=await r.text();
  } else if(typeof data?.content==='string') textBody=Buffer.from(data.content.replace(/\n/g,''),'base64').toString('utf8');
  const proxies=parseProxyRows(null,textBody,'GitHub mirror');
  return {ok:true,type:'file',repo:`${owner}/${name}`,path:cleanPath,file:{name:data.name,path:data.path,size:data.size||0,html_url:data.html_url||null,download_url:data.download_url||null},count:proxies.length,proxies:proxies.slice(0,2000)};
}


app.get('/api/proxy/list', async (req,res)=>{
  refreshProviderSecrets();
  try{const data=await proxyList({mode:String(req.query.mode||'best'),country:String(req.query.country||''),protocol:String(req.query.protocol||''),limit:req.query.limit});res.setHeader('cache-control','no-store');res.json(data);}catch(e){jsonError(res,`Proxy list failed: ${e.message}`,e.statusCode||502);}
});
app.get('/api/isp/list', (req,res)=>{
  const cc=proxyCountryCode(req.query.country)||'';
  const live=storedResults(cc);
  const byOrg=new Map();
  for(const row of live){const name=String(row.provider||row.asName||'Unknown organization').trim()||'Unknown organization';if(!byOrg.has(name))byOrg.set(name,[]);byOrg.get(name).push(row);}
  const providers=[...byOrg.entries()].map(([name,items])=>({name,searchTerms:[name],liveIpCount:items.length,ips:items.slice(0,50)})).sort((a,b)=>b.liveIpCount-a.liveIpCount);
  res.json({ok:true,country:cc||null,countryName:cc?(SUPPORTED_WORLD_COUNTRIES[cc]?.name||COUNTRY_CODES[cc]||cc):'All countries',providers,note:'Organizations are shown only when observed in saved Proxifly scanner results; organization names do not necessarily mean physical datacenter names.'});
});
app.get('/api/github/live', async (req,res)=>{try{const source=await loadProxiflyJsonRows();res.setHeader('cache-control','no-store');res.json({ok:true,type:'file',repo:'proxifly/free-proxy-list',path:'proxies/all/data.json',count:source.rows.length,proxies:source.rows.slice(0,2000),fetchedAt:source.fetchedAt,source:'Proxifly',sourceMode:source.sourceMode||'online',localSnapshotAvailable:source.localSnapshotAvailable||fs.existsSync(PROXIFLY_LOCAL_JSON_FILE)});}catch(e){jsonError(res,`Proxifly source failed: ${e.message}`,e.statusCode||502);}});
app.get('/api/proxifly/summary', async (req, res) => {
  try {
    const source = await loadProxiflyJsonRows();
    const rows = source.rows || [];
    const uniqueIpCount = new Set(rows.map(row => row.ip).filter(Boolean)).size;
    const countrySet = new Set(rows.map(row => proxyCountryCode(row.country)).filter(Boolean));
    const protocolCounts = {};
    for (const row of rows) protocolCounts[row.protocol || 'unknown'] = (protocolCounts[row.protocol || 'unknown'] || 0) + 1;
    res.setHeader('cache-control', 'no-store');
    res.json({
      ok: true, source: 'Proxifly JSON', sourceUrl: PROXIFLY_JSON_URL,
      totalEntries: rows.length, uniqueIpCount, countryCount: countrySet.size,
      protocolCounts, countries: [...countrySet].sort(),
      sourceMode: source.sourceMode || 'online', fetchedAt: source.fetchedAt || null,
      localSnapshotAvailable: Boolean(source.localSnapshotAvailable || fs.existsSync(PROXIFLY_LOCAL_JSON_FILE)),
      localFallbackFile: path.relative(__dirname, PROXIFLY_LOCAL_JSON_FILE).replace(/\\/g, '/')
    });
  } catch (error) {
    jsonError(res, `Proxifly summary failed: ${error.message}`, error.statusCode || 502);
  }
});

app.post('/api/connectivity/check', async (req, res) => {
  const url = String(req.body?.url || '').trim();
  const country = String(req.body?.country || 'DE').trim().toUpperCase();
  if (!url) return jsonError(res, 'Enter a website URL.', 400);
  if (url.length > 500) return jsonError(res, 'URL is too long (maximum 500 characters).', 400);
  try {
    const result = await globalpingHttpMeasure(url, country);
    res.setHeader('cache-control', 'no-store');
    res.json(result);
  } catch (error) {
    if (/globalping/i.test(String(error?.message || ''))) recordServerProblem('Globalping', String(error.message).slice(0, 300), 'warning');
    jsonError(res, error.message || 'Globalping connectivity test failed.', error.statusCode || 502);
  }
});

app.get('/api/guide', (req,res)=>res.json({ok:true,version:APP_VERSION,tools:['proxy-best','proxy-v4','proxy-v6','global','guide','ip-info','github-live','countries','isps','ip-db','speed','country-ip','port','http'],sources:{proxifly:'https://github.com/proxifly/free-proxy-list',globalping:'https://globalping.io/',geoMetadata:'https://ipwho.is/'},notes:['The public proxy inventory is sourced only from Proxifly JSON.','All ping measurements are run only through Globalping.','Country, city and organization metadata are best-effort enrichment; organization is not guaranteed to identify a physical datacenter.','Public proxies can be unreliable or unsafe; active scanning remains allowlist-protected.']}));


function allStoredIpRows() {
  const byIp = new Map();
  for (const row of persistedWorldResults) {
    if (!isValidIP(row?.ip)) continue;
    byIp.set(row.ip, {
      ...row,
      database: 'Datacenter IP Database',
      databases: ['Datacenter IP Database'],
      sourceNames: Array.isArray(row.sources) ? [...row.sources] : []
    });
  }
  for (const row of persistedManualScanResults) {
    if (!isValidIP(row?.ip)) continue;
    const previous = byIp.get(row.ip);
    const databaseNames = [...new Set([...(previous?.databases || []), 'Authorized Scan Database'])];
    byIp.set(row.ip, {
      ...(previous || {}), ...row,
      country: row.country || previous?.country || '',
      countryCode: row.countryCode || previous?.countryCode || '',
      provider: row.provider || previous?.provider || '',
      asn: row.asn || previous?.asn || null,
      ping: row.ping || previous?.ping || null,
      confirmedPorts: previous?.confirmedPorts || [],
      observedPorts: previous?.observedPorts || [],
      sources: [...new Set([...(previous?.sources || []), row.source || 'Authorized manual scan'])],
      database: databaseNames.join(' + '),
      databases: databaseNames,
      sourceNames: [...new Set([...(previous?.sourceNames || []), row.source || 'Authorized manual scan'])]
    });
  }
  return [...byIp.values()].sort((a, b) => String(b.lastSeen || b.discoveredAt || '').localeCompare(String(a.lastSeen || a.discoveredAt || '')));
}

app.get('/api/ip-db/all', (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit || 300), 1), 1000);
  const rows = allStoredIpRows();
  res.json({ ok: true, totalInDatabase: rows.length, results: rows.slice(0, limit) });
});

app.get('/api/ip-db/ping', async (req, res) => {
  const ip = String(req.query.ip || '').trim();
  if (!isValidIP(ip)) return jsonError(res, 'Enter a valid IP address.', 400);
  if (isBlockedIP(ip)) return jsonError(res, 'Live ping is limited to public IP addresses.', 400);
  const worldRow = persistedWorldResults.find(row => row.ip === ip);
  const manualRow = persistedManualScanResults.find(row => row.ip === ip);
  const storedPing = worldRow?.ping || manualRow?.ping || null;
  if (storedPing && ((storedPing.avgMs != null && Number.isFinite(Number(storedPing.avgMs))) || (storedPing.latencyMs != null && Number.isFinite(Number(storedPing.latencyMs))))) {
    return res.json({ ok: true, ip, ping: storedPing, cached: true, databases: [...new Set([...(worldRow ? ['Datacenter IP Database'] : []), ...(manualRow ? ['Authorized Scan Database'] : [])])] });
  }
  const ping = await globalWorldPing(ip, ['DE', 'FR']);
  if (worldRow) {
    worldRow.ping = ping;
    worldRow.lastSeen = new Date().toISOString();
    writeWorldResults(persistedWorldResults);
  } else if (manualRow) {
    manualRow.ping = ping;
    manualRow.lastSeen = new Date().toISOString();
    writeManualScanResults(persistedManualScanResults);
  }
  res.setHeader('cache-control', 'no-store');
  res.json({ ok: true, ip, ping, cached: false, databases: [...new Set([...(worldRow ? ['Datacenter IP Database'] : []), ...(manualRow ? ['Authorized Scan Database'] : [])])] });
});

app.get('/api/ip-db/summary', (req, res) => {
  const rows = storedResults();
  const combined = allStoredIpRows();
  const catalog = [...new Set(rows.map(r => r.provider || r.asName).filter(Boolean))];
  const providers = catalog.map(provider => {
    const matches = rows.filter(r => providerMatches(r, provider));
    const ms = matches.map(latencyValue).filter(Number.isFinite);
    const countries = [...new Set(matches.map(r => r.countryCode).filter(Boolean))];
    const datacenters = [...new Set(matches.map(r => `${r.provider || r.asName || provider}|${r.countryCode || ''}|${r.city || ''}|${r.asn || ''}`))];
    return { provider, ipCount: matches.length, serverCount: matches.length, datacenterCount: datacenters.length, avgMs: ms.length ? Math.round(ms.reduce((a, b) => a + b, 0) / ms.length) : null, countries };
  }).sort((a, b) => b.ipCount - a.ipCount || a.provider.localeCompare(b.provider));
  const activeDatacenters = [...new Set(rows.map(r => `${r.provider || r.asName || ''}|${r.countryCode || ''}|${r.city || ''}|${r.asn || ''}`).filter(x => x !== '|||'))];
  const localDatabases = [
    { id: 'datacenter', name: 'Proxifly Scan Results', file: 'data/world-results.json', ipCount: rows.length, serverCount: rows.length, datacenterCount: activeDatacenters.length, configured: true, ready: true },
    { id: 'manual-scan', name: 'Authorized Scan Database', file: 'data/manual-scan-results.json', ipCount: persistedManualScanResults.length, serverCount: persistedManualScanResults.length, datacenterCount: 0, configured: true, ready: true }
  ];
  const sources = [
    { id: 'proxifly', name: 'Proxifly JSON', category: 'Proxy inventory (only)', configured: true, ready: !currentServerProblems().some(p => /proxifly/i.test(p.source)), storedIPs: rows.filter(r => (r.sources || []).some(x => /proxifly/i.test(x))).length },
    { id: 'globalping', name: 'Globalping', category: 'Ping (only)', configured: true, ready: true, storedIPs: rows.filter(r => r.ping?.source === 'Globalping' || r.pingSource === 'Globalping').length },
    { id: 'geo-metadata', name: 'IP location / ASN metadata', category: 'Best-effort enrichment, not discovery or ping', configured: true, ready: true, storedIPs: rows.filter(r => r.provider || r.asName || r.asn).length }
  ];
  res.json({
    ok: true,
    databases: [...localDatabases, ...sources],
    localDatabases,
    sources,
    totals: {
      ipCount: rows.length,
      datacenterIpCount: rows.length,
      manualIpCount: persistedManualScanResults.length,
      allStoredIpCount: combined.length,
      serverCount: combined.length,
      datacenterCount: activeDatacenters.length,
      providersConfigured: providers.length,
      providersWithIPs: providers.filter(x => x.ipCount > 0).length,
      countriesWithIPs: [...new Set(rows.map(r => r.countryCode).filter(Boolean))].length,
      activeSourceCount: sources.filter(x => x.ready).length,
      totalSourceCount: sources.length
    },
    providers
  });
});
app.get('/api/ip-db/provider',(req,res)=>{const provider=String(req.query.provider||'').trim();if(!provider)return jsonError(res,'Provider is required.',400);const cc=normaliseWorldCountryCode(req.query.country)||'';const limit=Math.min(Math.max(Number(req.query.limit||300),1),500);const all=storedResults(cc).filter(r=>providerMatches(r,provider));const ordered=all.slice().sort((a,b)=>(latencyValue(a)??999999)-(latencyValue(b)??999999));res.json({ok:true,provider,country:cc||null,serverCount:all.length,ipCount:Math.min(limit,all.length),totalInDatabase:all.length,results:ordered.slice(0,limit).map(r=>({...r,latencyMs:latencyValue(r)}))})});
app.get('/api/ip-db/manual',(req,res)=>{const limit=Math.min(Math.max(Number(req.query.limit||200),1),500);res.json({ok:true,ipCount:persistedManualScanResults.length,results:persistedManualScanResults.slice(-limit).reverse()})});
app.post('/api/ip-db/globalping',async(req,res)=>{const ips=[...new Set((Array.isArray(req.body?.ips)?req.body.ips:String(req.body?.ips||'').split(',')).map(x=>String(x||'').trim()).filter(isValidIP))].slice(0,20);if(!ips.length)return jsonError(res,'No valid IPs selected.',400);const countries=[...new Set((Array.isArray(req.body?.countries)?req.body.countries:String(req.body?.countries||'')).split(',').map(safeWorldCountryCode).filter(Boolean))].slice(0,12);const pingCountries=countries.length?countries:DEFAULT_SELECTED_WORLD_COUNTRIES.slice(0,4);const results=[];for(const ip of ips){let ping;try{ping=await globalWorldPing(ip,pingCountries)}catch(e){ping={ok:false,error:e.message,source:'Globalping'}}const matching=persistedWorldResults.filter(x=>x.ip===ip);for(const row of matching){row.ping=ping;row.pingSource='Globalping';row.lastSeen=new Date().toISOString()}results.push({ip,ping})}writeWorldResults(persistedWorldResults);res.json({ok:true,source:'Globalping',requested:ips.length,results})});
app.get('/api/provider-status', (req, res) => {
  const problems = currentServerProblems();
  const sourceProblem = problems.find(p => /proxifly/i.test(p.source));
  const pingProblem = problems.find(p => /globalping/i.test(p.source));
  const checks = {
    proxifly: { configured: true, ok: proxiflyJsonCache.rows.length > 0 || !sourceProblem, onlineOk: !sourceProblem, servingFromFallback: proxiflyJsonCache.sourceMode === 'local-fallback', sourceUrl: PROXIFLY_JSON_URL, role: 'sole proxy inventory source with persistent local JSON fallback', cacheMode: proxiflyJsonCache.sourceMode || null, cachedEntries: proxiflyJsonCache.rows.length, fetchedAt: proxiflyJsonCache.fetchedAt || null, localFallbackFile: path.relative(__dirname, PROXIFLY_LOCAL_JSON_FILE).replace(/\\/g,'/'), localSnapshotAvailable: proxiflyJsonCache.localSnapshotAvailable || fs.existsSync(PROXIFLY_LOCAL_JSON_FILE), error: sourceProblem?.message || null },
    globalping: { configured: true, ok: !pingProblem, authenticated: Boolean(GLOBALPING_API_KEY), role: 'sole ping measurement provider', error: pingProblem?.message || null },
    geoMetadata: { configured: true, ok: true, role: 'best-effort country/city/ASN organization metadata; not a proxy source or ping service' },
    proxiflyInventory: { configured: true, ok: true, cachedEntries: proxiflyJsonCache.rows.length },
    autoDiscovery: { enabled: false, role: 'manual, quota-aware Proxifly batches' }
  };
  res.setHeader('cache-control', 'no-store');
  res.json({ ok: true, version: APP_VERSION, checks, proxyInventory: { source: 'Proxifly JSON', url: PROXIFLY_JSON_URL, cacheMode: proxiflyJsonCache.sourceMode || null, localFallbackFile: 'data/proxifly-data.json', localSnapshotAvailable: proxiflyJsonCache.localSnapshotAvailable || fs.existsSync(PROXIFLY_LOCAL_JSON_FILE) }, pingProvider: 'Globalping', worldCountries: WORLD_COUNTRY_CODES, speedtest: { enabled: true, provider: 'Mahdiar server transfer + Globalping latency' }, telegram: { configured: Boolean(getTelegramToken()), setupKeyConfigured: Boolean(TELEGRAM_SETUP_KEY), polling: telegramPolling } });
});

app.get('/api/auto-discovery/status', (req,res)=>{resetAutoDiscoveryDay();const now=Date.now();const rows=storedResults();const nextAt=autoDiscoveryNextAt || (isAutoDiscoveryEnabled() && Number(autoDiscoveryState.runsToday||0)<AUTO_DISCOVERY_RUNS_PER_DAY ? new Date(now+autoDiscoveryIntervalMs).toISOString() : null);res.json({ok:true,enabled:isAutoDiscoveryEnabled(),runsPerDay:AUTO_DISCOVERY_RUNS_PER_DAY,runsToday:Number(autoDiscoveryState.runsToday||0),countries:DEFAULT_SELECTED_WORLD_COUNTRIES,lastRunAt:autoDiscoveryState.lastRunAt||null,lastCountries:autoDiscoveryState.lastCountries||[],lastNewIps:Number(autoDiscoveryState.lastNewIps||0),storedIPs:rows.length,datacenters:new Set(rows.map(r=>`${r.provider||r.asName||''}|${r.countryCode||''}|${r.city||''}|${r.asn||''}`)).size,running:autoDiscoveryRunning,nextRunAt:nextAt});});
app.post('/api/auto-discovery/settings',(req,res)=>{setAutoDiscoveryEnabled(false);res.status(410).json({ok:false,enabled:false,error:'Legacy provider-based automatic discovery is disabled. Use the Proxifly scanner; each requested ping is measured by Globalping.'});});
app.post('/api/auto-discovery/run', async (req,res)=>res.status(410).json({ok:false,error:'Legacy provider-based discovery was removed. Use /api/world-discovery (Proxifly + Globalping).'}));

app.get('/api/debug/world', async (req, res) => {
  try {
    const source=await loadProxiflyJsonRows();
    const countries=String(req.query.countries||'').split(',').map(proxyCountryCode).filter(Boolean);
    const rows=source.rows.filter(r=>!countries.length||countries.includes(r.country)).slice(0,20);
    res.setHeader('cache-control','no-store');
    res.json({ok:true,version:APP_VERSION,source:'Proxifly JSON',total:source.rows.length,countries,results:rows});
  } catch(e) { jsonError(res,`Proxifly source diagnostic failed: ${e.message}`,e.statusCode||502); }
});

app.get('/health', (req, res) => res.status(200).json({ ok: true, status: 'ok', uptimeSec: Math.floor(process.uptime()), service: 'mahdiar-network-tools' }));

app.get('/api/health', (req, res) => res.json({
  ok: true,
  service: 'Mahdiar scanner',
  uptime: Math.floor(process.uptime()),
  time: new Date().toISOString(),
  platform: process.platform,
  node: process.version
}));
app.get('/api/dashboard', (req, res) => {
  const history = readHistory();
  const avg = requestTimes.length ? Math.round(requestTimes.reduce((a, b) => a + b, 0) / requestTimes.length) : 0;
  const activeScans = activeJobCount();
  res.json({
    ok: true,
    server: {
      hostname: os.hostname(), platform: process.platform, arch: process.arch, node: process.version,
      uptimeSeconds: Math.floor(process.uptime()), memory: { rss: process.memoryUsage().rss, heapUsed: process.memoryUsage().heapUsed },
      cpus: os.cpus().length, load: os.loadavg(), startedAt: new Date(startedAt).toISOString()
    },
    metrics: { ...counters, avgResponseMs: avg, historyCount: history.length, activeScans },
    scanner: { enabled: SCAN_ALLOWED_TARGETS.length > 0, allowedRules: SCAN_ALLOWED_TARGETS.length, maxHosts: MAX_SCAN_HOSTS, maxPorts: MAX_SCAN_PORTS, profiles: Object.keys(SCAN_PROFILES), activeJobs: activeScans },
    recent: recentEvents.slice(0, 12)
  });
});
app.get('/api/history', (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit || 50), 1), 200);
  res.json({ ok: true, items: readHistory().slice(-limit).reverse() });
});
app.delete('/api/history', (req, res) => { writeHistory([]); res.json({ ok: true }); });

app.get('/api/ip/countries', (req, res) => {
  res.json({ ok: true, countries: Object.entries(SUPPORTED_WORLD_COUNTRIES).map(([code, row]) => ({ code, name: row.name, fa: row.fa, lat: row.lat, lon: row.lon })) });
});
app.get('/api/world/countries', (req, res) => {
  res.json({ ok: true, countries: Object.entries(SUPPORTED_WORLD_COUNTRIES).map(([code, row]) => ({ code, ...row })) });
});

function ipv4CidrSize(cidr) {
  const bounds = ipv4CidrBounds(cidr);
  return bounds ? bounds.end - bounds.start + 1 : 0;
}

function cidrFromBigInt(network, bits) {
  const parts = [24n, 16n, 8n, 0n].map(shift => Number((network >> shift) & 255n));
  return `${parts.join('.')}/${bits}`;
}

function normaliseIpv4Cidr(cidr) {
  const parts = String(cidr || '').trim().split('/');
  if (parts.length !== 2 || !isIPv4(parts[0])) return null;
  const bits = Number(parts[1]);
  if (!Number.isInteger(bits) || bits < 0 || bits > 32) return null;
  const base = BigInt(ipToInt(parts[0]));
  const hostBits = BigInt(32 - bits);
  const size = 1n << hostBits;
  const network = (base / size) * size;
  return { network, bits };
}

function aggregateIpv4Cidrs(cidrs) {
  let blocks = [...new Set((cidrs || []).map(normaliseIpv4Cidr).filter(Boolean).map(x => cidrFromBigInt(x.network, x.bits)))];
  let changed = true;
  while (changed) {
    changed = false;
    const parsed = blocks.map(cidr => ({ cidr, ...normaliseIpv4Cidr(cidr) }))
      .sort((a, b) => a.bits - b.bits || (a.network < b.network ? -1 : a.network > b.network ? 1 : 0));
    const next = [];
    for (let i = 0; i < parsed.length; i++) {
      const a = parsed[i];
      const b = parsed[i + 1];
      if (b && a.bits === b.bits && a.bits > 0) {
        const parentBits = a.bits - 1;
        const parentSize = 1n << BigInt(32 - parentBits);
        const parentA = (a.network / parentSize) * parentSize;
        const parentB = (b.network / parentSize) * parentSize;
        const blockSize = 1n << BigInt(32 - a.bits);
        if (parentA === parentB && b.network === a.network + blockSize) {
          next.push(cidrFromBigInt(parentA, parentBits));
          i++;
          changed = true;
          continue;
        }
      }
      next.push(a.cidr);
    }
    blocks = [...new Set(next)];
  }
  return blocks.sort((a, b) => {
    const x = normaliseIpv4Cidr(a), y = normaliseIpv4Cidr(b);
    return x.bits - y.bits || (x.network < y.network ? -1 : x.network > y.network ? 1 : 0);
  });
}

async function fetchCountryRanges(country, aggregate = true) {
  const cc = safeWorldCountryCode(country);
  if (!cc) throw Object.assign(new Error(`Country ${String(country || '').toUpperCase()} is not enabled.`), { statusCode: 400 });
  const sourceUrl = `https://www.ipdeny.com/ipblocks/data/countries/${cc.toLowerCase()}.zone`;
  const response = await fetchText(sourceUrl, { headers: { accept: 'text/plain' } }, 12000);
  if (!response.ok) throw Object.assign(new Error(`IPdeny returned HTTP ${response.status}.`), { statusCode: 502 });
  const raw = await response.text();
  const listed = [...new Set(String(raw || '').split(/\s+/).map(x => x.trim()).filter(x => /^\d{1,3}(?:\.\d{1,3}){3}\/\d{1,2}$/.test(x)).filter(x => normaliseIpv4Cidr(x)))];
  if (!listed.length) throw Object.assign(new Error('IPdeny returned no valid IPv4 CIDR ranges.'), { statusCode: 502 });
  const ranges = aggregate ? aggregateIpv4Cidrs(listed) : listed;
  return {
    country: cc,
    countryName: SUPPORTED_WORLD_COUNTRIES[cc].name,
    ranges,
    aggregated: Boolean(aggregate),
    totalRanges: ranges.length,
    source: 'IPdeny country IPv4 zone',
    sourceUrl,
    at: Date.now()
  };
}

app.get('/api/ip/country-ranges', async (req, res) => {
  const country = String(req.query.country || '').trim().toUpperCase();
  const aggregate = String(req.query.aggregate ?? 'true').toLowerCase() !== 'false';
  const limit = Math.min(Math.max(Number(req.query.limit || 120), 1), 500);
  try {
    const data = await fetchCountryRanges(country, aggregate);
    const ranges = data.ranges.slice(0, limit).map(cidr => ({ cidr, addresses: ipv4CidrSize(cidr), firstIp: cidr.split('/')[0] }));
    res.json({ ok: true, country: data.country, countryName: data.countryName, aggregated: data.aggregated, totalRanges: data.totalRanges, returnedRanges: ranges.length, ranges, source: data.source, sourceUrl: data.sourceUrl, fetchedAt: new Date(data.at).toISOString(), truncated: ranges.length < data.totalRanges });
  } catch (e) {
    jsonError(res, `Country IP ranges failed: ${e.message}`, e.statusCode || 502);
  }
});
function publicClientIp(req) {
  const candidates = [
    req.headers['cf-connecting-ip'],
    req.headers['true-client-ip'],
    req.headers['x-real-ip'],
    req.headers['x-client-ip'],
    (() => { const f=String(req.headers['forwarded']||''); const m=f.match(/(?:^|;)\s*for=\"?([^;\"]+)\"?/i); return m ? m[1].replace(/^\[|\]$/g,'') : ''; })(),
    String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()
  ];
  for (const candidate of candidates) {
    const ip = String(candidate || '').trim().replace(/^::ffff:/, '');
    if (net.isIP(ip) === 0) continue;
    if (isIPv4(ip) && isPrivateIPv4(ip)) continue;
    const v6 = ip.toLowerCase();
    if (v6 === '::' || v6 === '::1' || v6.startsWith('fc') || v6.startsWith('fd') || v6.startsWith('fe8') || v6.startsWith('fe9') || v6.startsWith('fea') || v6.startsWith('feb')) continue;
    return ip;
  }
  return '';
}


function isPublicClientAddress(ip) {
  const value = String(ip || '').trim().replace(/^\[|\]$/g, '').replace(/^::ffff:/, '');
  if (!net.isIP(value)) return false;
  if (isIPv4(value)) return !isPrivateIPv4(value);
  const low=value.toLowerCase();
  return !(low === '::' || low === '::1' || low.startsWith('fc') || low.startsWith('fd') || low.startsWith('fe8') || low.startsWith('fe9') || low.startsWith('fea') || low.startsWith('feb'));
}

app.get('/api/ip/me', async (req, res) => {
  refreshProviderSecrets();
  const detected = publicClientIp(req);
  const valid = isPublicClientAddress(detected) ? detected : '';
  const sources = {};
  if (valid) sources.proxy = { ip: valid, source: 'reverse-proxy client headers' };
  const [ipwho, ipinfo] = await Promise.all([
    valid ? ipGeolocation(valid) : Promise.resolve(null),
    valid && IPINFO_TOKEN ? ipinfoLiteLookup(valid) : Promise.resolve(null)
  ]);
  if (ipwho) sources.ipwho = ipwho;
  if (ipinfo) sources.ipinfo = ipinfo;
  saveEvent('ip-info', valid || 'browser', Boolean(valid), valid || 'waiting for browser public-IP probe');
  res.setHeader('cache-control','no-store');
  res.json({ ok: Boolean(valid), clientIp: valid || null, publicIp: valid || null, detectedByServer: valid || null, source: valid ? 'client/proxy' : null,
    country: ipwho?.country || '', countryCode: ipwho?.countryCode || '', city: ipwho?.city || '', provider: ipwho?.provider || '', asn: ipwho?.asn || '', metadataSource: ipwho ? 'IPWho.is' : null, sources,
    diagnostic: { forwardedHeaders: ['cf-connecting-ip','x-real-ip','x-forwarded-for','forwarded'], detectedHeaderIp: detected || null, note: 'Never falls back to the scanner server public IP.' } });
});
app.get('/api/ip/lookup', async (req, res) => {
  refreshProviderSecrets();
  const ip = String(req.query.ip || '').trim();
  if (!isValidIP(ip)) return jsonError(res, 'Enter a valid IPv4 or IPv6 address.');
  const [info, rdapResult, shodan, netlas, abuse, ipwho] = await Promise.all([
    checkHostInfo(ip),
    (async () => {
      try {
        const r = await fetchText(`https://rdap.org/ip/${encodeURIComponent(ip)}`, { headers: { accept: 'application/rdap+json, application/json' } }, 8000);
        const data = await r.json();
        return r.ok ? data : null;
      } catch (_) { return null; }
    })(),
    isIPv4(ip) && SHODAN_API_KEY ? shodanHostDetails(ip) : null,
    isValidIP(ip) && NETLAS_API_KEY ? netlasHostDetails(ip) : null,
    isIPv4(ip) ? abuseIpDbCheck(ip) : null,
    ipGeolocation(ip)
  ]);
  const [ipinfo, intel] = await Promise.all([ipinfoLiteLookup(ip), checkHostIntelligence(ip)]);
  const data = info || {};
  const events = Array.isArray(rdapResult?.events) ? rdapResult.events : [];
  const entities = Array.isArray(rdapResult?.entities) ? rdapResult.entities : [];
  const org = entities.find(e => Array.isArray(e.roles) && (e.roles.includes('registrant') || e.roles.includes('administrative')));
  const name = ipwho?.provider || ipwho?.org || data?.asn?.name || data?.company?.name || netlas?.provider || rdapResult?.name || rdapResult?.handle || shodan?.provider || '';
  const country = ipwho?.country || data?.country || data?.countryName || rdapResult?.country || netlas?.country || shodan?.country || ipinfo?.country || '';
  const openPorts = (intel?.data?.open_ports || []).map(x => Number(x?.port)).filter(Boolean);
  saveEvent('ip-lookup', ip, Boolean(info || rdapResult || ipwho || ipinfo || shodan || intel), `${name} ${country}`.trim());
  res.json({
    ok: Boolean(info || rdapResult || ipwho || ipinfo || shodan || intel),
    ip,
    name,
    country,
    countryCode: ipwho?.countryCode || data?.countryCode || data?.country_code || netlas?.countryCode || shodan?.countryCode || '',
    city: ipwho?.city || data?.city || netlas?.city || shodan?.city || '',
    latitude: ipwho?.lat ?? null,
    longitude: ipwho?.lon ?? null,
    metadataSource: ipwho ? 'IPWho.is' : 'Fallback sources',
    startAddress: rdapResult?.startAddress || '',
    endAddress: rdapResult?.endAddress || '',
    cidrs: rdapResult?.cidr0_cidrs || [],
    type: rdapResult?.type || '',
    status: rdapResult?.status || [],
    events,
    entity: org || null,
    asn: ipwho?.asn || data?.asn || netlas?.asn || shodan?.asn || ipinfo?.asn || null,
    company: data?.company || null,
    privacy: data?.privacy || null,
    hosting: data?.hosting || null,
    reverse: data?.reverse || null,
    openPorts: [...new Set([...(netlas?.ports || []), ...(shodan?.ports || []), ...openPorts])].sort((a,b)=>a-b),
    shodan: shodan ? { provider: shodan.provider, lastSeen: shodan.lastSeen, services: shodan.services } : null,
    netlas: netlas ? { provider: netlas.provider, lastSeen: netlas.lastSeen, services: netlas.services, prefix: netlas.prefix } : null,
    abuse: abuse ? { abuseConfidenceScore: abuse.abuseConfidenceScore, totalReports: abuse.totalReports, lastReportedAt: abuse.lastReportedAt, isWhitelisted: abuse.isWhitelisted, usageType: abuse.usageType } : null,
    raw: { ipwho, info: info, rdap: rdapResult, ipinfo, intelligence: intel, shodan, netlas }
  });
});
async function dnsOverHttpsLookup(host, type) {
  const providers = [
    ['Google', 'https://dns.google/resolve'],
    ['Cloudflare', 'https://cloudflare-dns.com/dns-query']
  ];
  for (const [name, base] of providers) {
    try {
      const u = new URL(base);
      u.searchParams.set('name', host);
      u.searchParams.set('type', type);
      const r = await fetchText(u.href, { headers: { accept: 'application/dns-json' } }, 7000);
      const data = await r.json();
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return { provider: name, data };
    } catch (_) {}
  }
  return null;
}

app.get('/api/dns', async (req, res) => {
  const host = normalizedTarget(req.query.host);
  const type = String(req.query.type || 'A').toUpperCase();
  if (!host || !SAFE_DNS_TYPES.has(type)) return jsonError(res, 'Invalid domain or DNS record type.');
  try {
    let records;
    if (type === 'PTR') records = await dns.reverse(host);
    else if (type === 'TXT') records = await dns.resolveTxt(host);
    else if (type === 'CNAME') records = await dns.resolveCname(host);
    else if (type === 'MX') records = await dns.resolveMx(host);
    else if (type === 'NS') records = await dns.resolveNs(host);
    else if (type === 'SOA') records = await dns.resolveSoa(host);
    else if (type === 'SRV') records = await dns.resolveSrv(host);
    else if (type === 'CAA') records = await dns.resolveCaa(host);
    else records = await dns.resolve(host, type);
    saveEvent('dns', `${host} ${type}`, true, `${Array.isArray(records) ? records.length : 1} record(s)`);
    res.json({ ok: true, host, type, provider: 'Node DNS resolver', records, fallback: false });
  } catch (e) {
    const fallback = await dnsOverHttpsLookup(host, type);
    if (!fallback) {
      saveEvent('dns', `${host} ${type}`, false, e.message);
      return jsonError(res, `DNS lookup failed: ${e.message}`, 502);
    }
    const answers = Array.isArray(fallback.data?.Answer) ? fallback.data.Answer : [];
    const records = answers.map(a => a?.data).filter(Boolean);
    saveEvent('dns', `${host} ${type}`, true, `${records.length} record(s) via ${fallback.provider}`);
    res.json({ ok: true, host, type, provider: `${fallback.provider} DNS-over-HTTPS`, records, raw: fallback.data, fallback: true });
  }
});
app.get('/api/scan/config', (req, res) => res.json({
  ok: true,
  enabled: true,
  worldDiscovery: true,
  proxyInventorySource: 'Proxifly JSON',
  proxyInventoryUrl: PROXIFLY_JSON_URL,
  pingProvider: 'Globalping',
  metadataEnrichment: 'Best effort country/city/ASN organization metadata',
  authorizedScanEnabled: SCAN_ALLOWED_TARGETS.length > 0,
  allowedRulesCount: SCAN_ALLOWED_TARGETS.length,
  defaultProfiles: Object.fromEntries(Object.entries(SCAN_PROFILES).map(([k, v]) => [k, { label: v.label, description: v.description, ports: v.ports }])),
  portGroups: PORT_GROUPS,
  maxHosts: MAX_SCAN_HOSTS,
  maxPorts: MAX_SCAN_PORTS,
  maxConcurrentJobs: MAX_SCAN_JOBS
}));
app.get('/api/scan/resolve', async (req, res) => {
  const host = normalizedTarget(req.query.host);
  if (!host) return jsonError(res, 'Enter a domain or IP.');
  try {
    const addresses = await resolveAllAddresses(host);
    saveEvent('resolve', host, true, `${addresses.length} address(es)`);
    res.json({ ok: true, host, addresses });
  } catch (e) { saveEvent('resolve', host, false, e.message); jsonError(res, `Resolve failed: ${e.message}`, 502); }
});
app.get('/api/scan/preview', async (req, res) => {
  const target = normalizedTarget(req.query.target);
  if (!target) return jsonError(res, 'Enter a target.');
  if (!SCAN_ALLOWED_TARGETS.length) return jsonError(res, 'Active target scan is optional; configure SCAN_ALLOWED_TARGETS only when you want to scan assets you are authorized to test.', 503);
  try {
    const resolved = await resolveScanTargets(target);
    res.json({ ok: true, target, kind: resolved.kind, count: resolved.addresses.length, sample: resolved.addresses.slice(0, 12), authorized: true });
  } catch (e) { jsonError(res, e.message, e.statusCode || 400); }
});
app.post('/api/scan/jobs', async (req, res) => {
  if (activeJobCount() >= MAX_SCAN_JOBS) return jsonError(res, 'Too many active scans. Wait for a current scan to finish.', 429);
  const target = normalizedTarget(req.body?.target);
  const profile = String(req.body?.profile || 'common').toLowerCase();
  const pingOnly = Boolean(req.body?.pingOnly);
  const ports = parsePorts(req.body?.ports, profile);
  if (!target) return jsonError(res, 'Enter an IP, IPv4 CIDR/range, or an authorized hostname.');
  if (!SCAN_ALLOWED_TARGETS.length) return jsonError(res, 'Active target scan is optional; configure SCAN_ALLOWED_TARGETS only when you want to scan assets you are authorized to test.', 503);
  if (!ports.length && !pingOnly) return jsonError(res, 'No valid ports selected.');
  try {
    const preview = await resolveScanTargets(target);
    if (preview.addresses.length > MAX_SCAN_HOSTS) return jsonError(res, `Maximum ${MAX_SCAN_HOSTS} hosts per scan.`, 400);
  } catch (e) {
    return jsonError(res, e.message, e.statusCode || 400);
  }
  const id = crypto.randomUUID();
  const job = {
    id, createdAt: new Date().toISOString(), status: 'queued', progress: 0, phase: 'Queued', target,
    profile: SCAN_PROFILES[profile] ? profile : 'custom', ports, options: {
      pingTimeout: Math.min(Math.max(Number(req.body?.pingTimeout || 1200), 500), 2500),
      portTimeout: Math.min(Math.max(Number(req.body?.portTimeout || 2200), 800), 4000),
      pingOnly,
      onlyOpen: Boolean(req.body?.onlyOpen)
    },
    addresses: [], totalHosts: 0, completedHosts: 0, results: [], summary: null
  };
  scanJobs.set(id, job);
  setImmediate(() => executeScanJob(job));
  res.status(202).json({ ok: true, job: publicJob(job) });
});
app.get('/api/scan/jobs/:id', (req, res) => {
  const job = scanJobs.get(req.params.id);
  if (!job) return jsonError(res, 'Scan job not found or expired.', 404);
  res.json({ ok: true, job: publicJob(job) });
});
app.get('/api/scan/ports', async (req, res) => {
  const target = normalizedTarget(req.query.target);
  if (!target) return jsonError(res, 'Enter a target.');
  if (!scanAuthorized(target)) return jsonError(res, 'Target is not in the optional SCAN_ALLOWED_TARGETS allowlist.', 403);
  const ports = parsePorts(req.query.ports, 'common');
  if (!ports.length) return jsonError(res, 'No valid ports selected.');
  try {
    const resolved = await resolveAllAddresses(target);
    const ip = resolved[0]?.address;
    if (!ip || !targetMatchesAllowlist(ip) && !scanAuthorized(target)) return jsonError(res, 'Resolved address is not authorized by the optional allowlist.', 403);
    const results = await runLimited(ports, 12, p => tcpCheck(ip, p, 2500).then(r => ({ port: p, service: SERVICE_MAP[p] || 'Unknown', ...r })));
    results.sort((a, b) => a.port - b.port);
    const open = results.filter(x => x.open);
    saveEvent('authorized-port-scan', target, true, `${open.length}/${results.length} open`);
    res.json({ ok: true, target, resolvedAddress: ip, ports: results, openCount: open.length, elapsedMs: results.reduce((n, x) => n + (x.latencyMs || 0), 0), authorized: true });
  } catch (e) { saveEvent('authorized-port-scan', target, false, e.message); jsonError(res, e.message, e.statusCode || 502); }
});

async function safeResolvedExternalHost(host) {
  const addresses = await resolveAllAddresses(host);
  const publicAddresses = addresses.filter(x => !isBlockedIP(x.address));
  if (!publicAddresses.length) throw new Error('The resolved destination is private/local or otherwise blocked by the safe checker.');
  return publicAddresses[0].address;
}
async function httpFetchSafe(urlObj, maxRedirects=4){
  let current=new URL(urlObj.href);
  const redirects=[];
  for(let hop=0;hop<=maxRedirects;hop++){
    if(!['http:','https:'].includes(current.protocol)) throw new Error('Only HTTP and HTTPS are allowed.');
    if(isBlockedHost(current.hostname)) throw new Error('Redirected destination is blocked.');
    await safeResolvedExternalHost(current.hostname);
    if (current.username || current.password) throw new Error('URLs containing embedded credentials are not supported.');
    let response;
    try {
      response = await fetchText(current.href, { method: 'HEAD', redirect: 'manual', headers: { 'user-agent': 'Mahdiar-Scanner/6.7.3', 'accept': '*/*' } }, DEFAULT_HTTP_TIMEOUT);
      // Some servers reject HEAD (405/403/501) or return an unhelpful error. Retry
      // once with a tiny ranged GET, then cancel the body after headers are received.
      if (response.status >= 400) {
        try { await response.body?.cancel(); } catch (_) {}
        response = await fetchText(current.href, { method: 'GET', redirect: 'manual', headers: { 'user-agent': 'Mahdiar-Scanner/6.7.3', 'range': 'bytes=0-0', 'accept': '*/*' } }, DEFAULT_HTTP_TIMEOUT);
      }
    } catch (headError) {
      response = await fetchText(current.href, { method: 'GET', redirect: 'manual', headers: { 'user-agent': 'Mahdiar-Scanner/6.7.3', 'range': 'bytes=0-0', 'accept': '*/*' } }, DEFAULT_HTTP_TIMEOUT);
    }
    if(response.status>=300&&response.status<400&&response.headers.get('location')){
      if(hop>=maxRedirects) return {response,current,redirects};
      const next=new URL(response.headers.get('location'),current.href);
      redirects.push({from:current.href,to:next.href,status:response.status});
      current=next;
      continue;
    }
    return {response,current,redirects};
  }
  throw new Error('Redirect limit exceeded.');
}
app.get('/api/http-check', async (req, res) => {
  const raw = String(req.query.url || '').trim();
  if (!/^https?:\/\//i.test(raw)) return jsonError(res, 'URL must start with http:// or https://');
  let url;
  try { url = new URL(raw); } catch { return jsonError(res, 'Invalid URL.'); }
  if (isBlockedHost(url.hostname)) return jsonError(res, 'This target is not allowed by the safe checker.');
  const startTime = Date.now();
  try {
    const result=await httpFetchSafe(url,4);
    const response=result.response;
    const headers={};
    for(const [k,v] of response.headers){if(['server','content-type','content-length','location','strict-transport-security','content-security-policy','x-content-type-options','x-frame-options','referrer-policy','permissions-policy','cross-origin-opener-policy','cross-origin-resource-policy','cache-control'].includes(k))headers[k]=v;}
    try{await response.body?.cancel();}catch(_){ }
    const ms=Date.now()-startTime;
    const output={ok:true,url:raw,status:response.status,statusText:response.statusText,redirected:result.redirects.length>0,finalUrl:result.current.href,latencyMs:ms,headers,redirects:result.redirects};
    saveEvent('http',raw,response.status>=200&&response.status<400,`${response.status} ${ms}ms`);
    res.json(output);
  } catch(e) {
    saveEvent('http',raw,false,e.message);
    try{
      const remote=await checkHostMonitor('http',{target:raw,timeout:10000},{timeout:12000,attempts:10});
      const nodes=Object.entries(remote.data||{});
      const first=nodes.find(([,payload])=>extractCheckHostChecks(payload).some(c=>Number(c.status)===1))||nodes[0];
      if(first){const payload=first[1];const check=extractCheckHostChecks(payload)[0]||{};const status=Number(check.status||check.http_status||check.statuscode||0)||null;const ms=normaliseWorldLatency(check.connectiontime);return res.json({ok:Boolean(status),url:raw,status,statusText:null,redirected:false,finalUrl:raw,latencyMs:ms,headers:{},remote:true,node:first[0],error:null});}
    }catch(_){ }
    jsonError(res,`HTTP check failed: ${e.message}`,502);
  }
});
app.get('/api/port-check', async (req, res) => {
  const host = normalizedTarget(req.query.host);
  const port = Number(req.query.port);
  if (!host || !Number.isInteger(port) || port < 1 || port > 65535) return jsonError(res, 'Enter one host and one valid port (1-65535).');
  if (isBlockedHost(host)) return jsonError(res, 'Private/local targets are blocked by the safe checker.');
  try {
    const address = (await safeResolvedExternalHost(host));
    let result = await tcpCheck(address, port);
    let remote = null;
    if (!result.open && ['error', 'filtered'].includes(result.state)) {
      try {
        const check = await checkHostMonitor('tcp', { target: address, port, timeout: 1500 }, { timeout: 10000, attempts: 10 });
        const values = [];
        for (const payload of Object.values(check.data || {})) {
          for (const c of extractCheckHostChecks(payload)) {
            if (Number(c.status) === 1) values.push(normaliseWorldLatency(c.connectiontime));
          }
        }
        const measured = values.filter(Number.isFinite);
        if (measured.length) { result = { open: true, state: 'open', latencyMs: Math.round(Math.min(...measured)), method: 'check-host-remote', measuredNodes: measured.length }; remote = check; }
      } catch (_) {}
    }
    saveEvent('port-check', `${host}:${port}`, result.open, result.open ? 'open' : result.error);
    let globalping = null;
    const pingCountries = String(req.query.countries || '').split(',').map(safeWorldCountryCode).filter(Boolean);
    try { globalping = await globalpingMeasure(address, pingCountries.length ? pingCountries : ['DE','FR','NL'], 2); } catch (_) {}
    res.json({ ok: true, host, resolvedAddress: address, port, service: SERVICE_MAP[port] || 'Unknown', remoteChecked: Boolean(remote), globalping, ...result });
  } catch (e) { jsonError(res, e.message, 400); }
});
app.get('/api/tls', async (req, res) => {
  const host = normalizedTarget(req.query.host);
  const port = Number(req.query.port || 443);
  if (!host || !Number.isInteger(port) || ![443, 8443].includes(port)) return jsonError(res, 'TLS checker supports ports 443 and 8443.');
  if (isBlockedHost(host)) return jsonError(res, 'Private/local targets are blocked by the safe checker.');
  let address;
  try { address = await safeResolvedExternalHost(host); } catch (e) { return jsonError(res, e.message, 400); }
  const result = await tlsProbe(host, port, address);
  saveEvent('ssl', `${host}:${port}`, result.ok, result.ok ? `${result.daysLeft} days left` : result.error);
  res.json({ ok: true, host, port, ...result });
});
app.get('/api/dns-compare', async (req, res) => {
  const host = normalizedTarget(req.query.host);
  const type = String(req.query.type || 'A').toUpperCase();
  if (!host || !SAFE_DNS_TYPES.has(type) || type === 'PTR') return jsonError(res, 'Enter a valid domain and a supported DNS type.');
  const providers = { cloudflare: 'https://cloudflare-dns.com/dns-query', google: 'https://dns.google/resolve' };
  const out = {};
  await Promise.all(Object.entries(providers).map(async ([name, base]) => {
    try {
      const u = new URL(base);
      u.searchParams.set('name', host);
      u.searchParams.set('type', type);
      const r = await fetchText(u.href, { headers: { accept: 'application/dns-json' } }, 7000);
      const data = await r.json();
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      out[name] = { ok: true, status: r.status, data };
    } catch (e) {
      out[name] = { ok: false, error: e.message };
    }
  }));
  const successful = Object.values(out).filter(x => x.ok).length;
  saveEvent('dns-compare', host, successful > 0, `${successful}/${Object.keys(out).length} providers responded`);
  res.json({ ok: successful > 0, host, type, providers: out });
});
app.get('/api/mtr', async (req, res) => {
  const host = normalizedTarget(req.query.host);
  if (!host) return jsonError(res, 'Enter a hostname or IP.');
  if (isBlockedHost(host)) return jsonError(res, 'Private/local targets are blocked by the safe checker.');
  try { await safeResolvedExternalHost(host); } catch (e) { return jsonError(res, e.message, 400); }
  try {
    const result = await traceRouteHost(host);
    if (result.ok) {
      saveEvent('mtr', host, true, `${result.hops.length} hops`);
      return res.json({ ok: true, host, ...result });
    }
    try {
      const remote = await checkHostMonitor('mtr', { target: host, max_hops: 16, timeout: 1000 }, { timeout: 15000, attempts: 12 });
      const lines = [];
      for (const [node, payload] of Object.entries(remote.data || {})) lines.push(`[${node}] ${JSON.stringify(payload)}`);
      const remoteResult = { ok: lines.length > 0, host, command: 'Check-Host MTR', hops: [], raw: lines.join('\n'), remote: true, uuid: remote.uuid };
      saveEvent('mtr', host, remoteResult.ok, remoteResult.ok ? `${lines.length} nodes` : result.error);
      return res.status(remoteResult.ok ? 200 : 503).json(remoteResult);
    } catch (_) {}
    saveEvent('mtr', host, false, result.error);
    res.status(503).json({ ok: false, host, ...result });
  } catch (e) { saveEvent('mtr', host, false, e.message); jsonError(res, `MTR failed: ${e.message}`, 502); }
});
const DNSBL_RESOLVER_SERVERS = ['1.1.1.1', '8.8.8.8'];
async function dnsblLookup(query) {
  const resolver = new dns.Resolver();
  resolver.setServers(DNSBL_RESOLVER_SERVERS);
  return resolver.resolve4(query);
}
app.get('/api/blacklist', async (req, res) => {
  refreshProviderSecrets();
  const ip = String(req.query.ip || '').trim();
  if (!isIPv4(ip)) return jsonError(res, 'Blacklist check currently supports IPv4.');
  const rev = ip.split('.').reverse().join('.');
  const lists = [['SpamCop', 'bl.spamcop.net'], ['Spamhaus ZEN', 'zen.spamhaus.org']];
  const [dnsResults, abuse] = await Promise.all([
    Promise.all(lists.map(async ([name, zone]) => {
      try {
        const hits = await dnsblLookup(`${rev}.${zone}`);
        return { name, zone, listed: true, records: hits, status: 'listed' };
      } catch (e) {
        const notListed = ['ENOTFOUND', 'ENODATA', 'SERVFAIL', 'ETIME'].includes(e?.code);
        return { name, zone, listed: false, status: notListed ? 'not-listed' : 'unavailable', error: notListed ? 'not listed' : (e?.code || e?.message || 'query failed') };
      }
    })),
    abuseIpDbCheck(ip)
  ]);
  const results = [...dnsResults];
  if (abuse) results.unshift({
    name: 'AbuseIPDB',
    zone: 'api.abuseipdb.com',
    listed: Number(abuse.abuseConfidenceScore || 0) >= 90,
    status: Number(abuse.abuseConfidenceScore || 0) >= 90 ? 'listed' : 'not-listed',
    abuseConfidenceScore: abuse.abuseConfidenceScore,
    totalReports: abuse.totalReports,
    lastReportedAt: abuse.lastReportedAt,
    usageType: abuse.usageType,
    isWhitelisted: abuse.isWhitelisted
  });
  const listed = results.filter(x => x.listed);
  const unavailable = results.filter(x => x.status === 'unavailable');
  const configuredSources = ['SpamCop', 'Spamhaus ZEN'].concat(abuse ? ['AbuseIPDB'] : []);
  saveEvent('blacklist', ip, listed.length === 0 && unavailable.length === 0, listed.map(x => x.name).join(', ') || (unavailable.length ? 'some lists unavailable' : 'clean'));
  res.json({ ok: true, ip, results, listed: listed.length > 0, unavailable: unavailable.length > 0, abuseIpDbEnabled: Boolean(ABUSEIPDB_API_KEY), sources: configuredSources, note: 'An unavailable DNSBL is not treated as clean. AbuseIPDB score is passive reputation data.' });
});
app.get('/api/mac', async (req, res) => {
  const mac = String(req.query.mac || '').trim();
  const compact = mac.replace(/[^a-fA-F0-9]/g, '');
  if (compact.length !== 12) return jsonError(res, 'Enter a valid MAC address.');
  try { const r = await fetchText(`https://api.macvendors.com/${encodeURIComponent(mac)}`, {}, 6000); const vendor = r.ok ? await r.text() : ''; saveEvent('mac', mac, r.ok, vendor || `HTTP ${r.status}`); res.status(r.ok ? 200 : 404).json({ ok: r.ok, mac, vendor: vendor || null, status: r.status }); }
  catch (e) { jsonError(res, `MAC vendor lookup failed: ${e.message}`, 502); }
});
async function readTextFile(file) {
  try { return (await fs.promises.readFile(file, 'utf8')).trim(); } catch (_) { return ''; }
}
async function readContainerTelemetry() {
  const candidates = {
    memoryCurrent: ['/sys/fs/cgroup/memory.current', '/sys/fs/cgroup/memory/memory.usage_in_bytes'],
    memoryMax: ['/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory/memory.limit_in_bytes']
  };
  const readFirst = async paths => {
    for (const file of paths) {
      const value = await readTextFile(file);
      if (value) return value;
    }
    return '';
  };
  let memoryCurrent = Number(await readFirst(candidates.memoryCurrent));
  let memoryMaxRaw = await readFirst(candidates.memoryMax);
  let memoryMax = memoryMaxRaw === 'max' ? null : Number(memoryMaxRaw);
  if (!Number.isFinite(memoryCurrent)) memoryCurrent = null;
  if (!Number.isFinite(memoryMax) || memoryMax <= 0 || memoryMax > 1e15) memoryMax = null;
  return {
    memory: { currentBytes: memoryCurrent, limitBytes: memoryMax, percent: memoryCurrent != null && memoryMax ? Math.round(memoryCurrent / memoryMax * 1000) / 10 : null },
    source: memoryCurrent != null ? 'cgroup' : 'process'
  };
}

app.get('/api/server-info', async (req, res) => {
  const interfaces = os.networkInterfaces();
  const all = [];
  for (const [name, items] of Object.entries(interfaces)) {
    for (const item of items || []) all.push({ interface: name, address: item.address, family: item.family, internal: item.internal, mac: item.mac, cidr: item.cidr });
  }
  const container = await readContainerTelemetry();
  const memory = process.memoryUsage();
  res.json({
    ok: true, hostname: os.hostname(), platform: process.platform, arch: process.arch, node: process.version,
    uptimeSeconds: process.uptime(), load: os.loadavg(), cpus: os.cpus().length, memory, container, interfaces: all,
    problems: currentServerProblems(),
    process: { pid: process.pid, rss: memory.rss, heapUsed: memory.heapUsed, heapTotal: memory.heapTotal, external: memory.external }
  });
});

app.get('/api/telemetry', async (req, res) => {
  const container = await readContainerTelemetry();
  const memory = process.memoryUsage();
  const avg = requestTimes.length ? Math.round(requestTimes.reduce((a, b) => a + b, 0) / requestTimes.length) : 0;
  res.json({
    ok: true, service: 'Mahdiar Network Tools', hostname: os.hostname(), node: process.version, platform: process.platform, arch: process.arch,
    uptimeSeconds: process.uptime(), cpus: os.cpus().length, load: os.loadavg(),
    memory, container, metrics: { ...counters, avgResponseMs: avg, activeScans: activeJobCount() },
    at: new Date().toISOString()
  });
});

app.get('/api/speed/ping', async (req,res)=>{
  res.setHeader('cache-control','no-store, no-cache, must-revalidate');
  res.setHeader('content-type','application/json; charset=utf-8');
  try {
    const host = String(req.get('x-forwarded-host') || req.get('host') || '').split(',')[0].trim().split(':')[0];
    if (!host || isBlockedHost(host)) return res.status(400).json({ok:false,source:'Globalping',error:'A public hostname is required for Globalping.'});
    const data = await globalpingMeasure(host, ['DE','FR','NL'], 3);
    const values = (data.results || []).map(x => Number(x.avgMs)).filter(Number.isFinite);
    const avgMs = values.length ? Math.round(values.reduce((a,b)=>a+b,0)/values.length) : null;
    const jitterMs = values.length > 1 ? Math.round(Math.sqrt(values.reduce((sum,v)=>sum+(v-avgMs)**2,0)/values.length)) : null;
    res.json({ok:values.length>0,source:'Globalping',at:Date.now(),avgMs,jitterMs,results:data.results||[],error:values.length?null:'No usable Globalping results.'});
  } catch (error) {
    res.status(502).json({ok:false,source:'Globalping',at:Date.now(),error:String(error?.message||error)});
  }
});
app.post('/api/speed/session', (req, res) => {
  const requested = Math.min(Math.max(Number(req.body?.bytes || 8000000), 500000), 16000000);
  const direction = String(req.body?.direction || 'download').toLowerCase() === 'upload' ? 'upload' : 'download';
  const id = crypto.randomBytes(16).toString('hex');
  speedSessions.set(id, { bytes: requested, at: Date.now(), ip: clientIp(req), direction });
  res.setHeader('cache-control', 'no-store, no-cache, must-revalidate');
  res.json({ ok: true, id, bytes: requested, direction, downloadUrl: `/api/speed/download/${id}?bytes=${requested}`, uploadUrl: `/api/speed/upload/${id}` });
});
app.get('/api/speed/download/:id', (req, res) => {
  const session = speedSessions.get(req.params.id);
  if (!session || Date.now() - session.at > 10 * 60 * 1000) return jsonError(res, 'Speed-test session expired. Start a new test.', 410);
  const requested = Math.max(200000, Number(req.query.bytes || session.bytes));
  const bytes = Math.min(requested, session.bytes, 16000000);
  speedSessions.delete(req.params.id);
  res.statusCode = 200;
  res.setHeader('content-type', 'application/octet-stream');
  res.setHeader('content-length', String(bytes));
  res.setHeader('cache-control', 'no-store, no-cache, must-revalidate');
  res.setHeader('content-encoding', 'identity');
  res.setHeader('x-content-type-options', 'nosniff');
  res.setHeader('x-accel-buffering', 'no');
  const chunk = Buffer.alloc(64 * 1024, 90); let sent = 0;
  const write = () => {
    while (sent < bytes) {
      const n = Math.min(chunk.length, bytes - sent);
      if (!res.write(chunk.subarray(0, n))) return res.once('drain', write);
      sent += n;
    }
    res.end();
  };
  req.on('close', () => { if (!res.writableEnded) return; });
  write();
});
app.post('/api/speed/upload/:id', express.raw({ type: 'application/octet-stream', limit: '8mb' }), (req, res) => {
  const session = speedSessions.get(req.params.id);
  if (!session || session.direction !== 'upload' || Date.now() - session.at > 10 * 60 * 1000) return jsonError(res, 'Speed-test upload session expired. Start a new test.', 410);
  const received = Buffer.isBuffer(req.body) ? req.body.length : 0;
  const max = Math.min(session.bytes, 8 * 1024 * 1024);
  speedSessions.delete(req.params.id);
  res.setHeader('cache-control', 'no-store, no-cache, must-revalidate');
  if (received <= 0) return jsonError(res, 'No upload bytes were received. Send an application/octet-stream request body.', 400);
  res.json({ ok: true, bytes: Math.min(received, max) });
});
setInterval(() => {
  const cutoff = Date.now() - 10 * 60 * 1000;
  for (const [id, value] of speedSessions) if (value.at < cutoff) speedSessions.delete(id);
}, 60 * 1000).unref();

app.get('/api/robots.txt', (req, res) => res.type('text').send('User-agent: *\nDisallow: /api/\n'));
app.use(express.static(path.join(__dirname, 'public'), { etag: false, maxAge: 0 }));
app.get('/{*splat}', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`[startup] version=${APP_VERSION} node=${process.version} port=${PORT}`);
  console.log(`[startup] proxy-inventory=Proxifly-JSON ping=Globalping geo-metadata=best-effort legacy-discovery=disabled`);
  console.log(`Mahdiar Network Tools listening on 0.0.0.0:${PORT}`);
  setTimeout(() => {
    loadProxiflyJsonRows()
      .then(source => console.log(`[proxifly] startup inventory loaded: ${source.rows.length} entries; mode=${source.sourceMode}; localSnapshot=${Boolean(source.localSnapshotAvailable)}`))
      .catch(error => console.warn(`[proxifly] startup inventory unavailable: ${String(error?.message||error).slice(0,350)}`));
  }, 600).unref?.();
  setTimeout(() => bootstrapTelegramBot(), 1200).unref?.();
  setTimeout(() => { warmupAutoDiscoveryIfEmpty().catch(()=>{}).finally(() => startAutoDiscoveryScheduler()); }, 2500).unref?.();
});

server.on('error', (err) => {
  console.error(`[startup-error] ${err && err.message ? err.message : err}`);
  process.exitCode = 1;
});
